package at.bookworm;

public final class R
{
  public static final class attr
  {
    public static final int lineColor = 2130771970;
    public static final int lineHeightSelected = 2130771972;
    public static final int lineHeightUnselected = 2130771971;
    public static final int segmentedControlButtonStyle = 2130771968;
    public static final int tabControlButtonStyle = 2130771973;
    public static final int textAllCaps = 2130771969;
  }

  public static final class color
  {
    public static final int dark = 2131034114;
    public static final int highlight = 2131034115;
    public static final int holo_checked = 2131034118;
    public static final int holo_focused = 2131034117;
    public static final int holo_pressed = 2131034116;
    public static final int light = 2131034113;
    public static final int normal = 2131034112;
    public static final int segmented_control_text = 2131034175;
    public static final int tab_control_text = 2131034176;
  }

  public static final class dimen
  {
    public static final int segmented_control_default_height = 2131099649;
    public static final int tab_bar_default_height = 2131099648;
  }

  public static final class drawable
  {
    public static final int segmented_control_background = 2130837805;
    public static final int tab_control_background = 2130837833;
  }

  public static final class string
  {
    public static final int app_name = 2131165185;
    public static final int hello = 2131165184;
  }

  public static final class style
  {
    public static final int Widget = 2131230720;
    public static final int Widget_Holo = 2131230721;
    public static final int Widget_Holo_SegmentedControl = 2131230722;
    public static final int Widget_Holo_TabControl = 2131230724;
    public static final int Widget_Holo_TabWidget = 2131230723;
  }

  public static final class styleable
  {
    public static final int[] SegmentedControlButton = { 2130771968, 2130771969, 2130771970, 2130771971, 2130771972 };
    public static final int SegmentedControlButton_lineColor = 2;
    public static final int SegmentedControlButton_lineHeightSelected = 4;
    public static final int SegmentedControlButton_lineHeightUnselected = 3;
    public static final int SegmentedControlButton_segmentedControlButtonStyle = 0;
    public static final int SegmentedControlButton_textAllCaps = 1;
    public static final int[] TabControlButton = { 2130771973 };
    public static final int TabControlButton_tabControlButtonStyle;
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     at.bookworm.R
 * JD-Core Version:    0.6.2
 */