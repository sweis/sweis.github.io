package at.bookworm.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.widget.RadioButton;
import at.bookworm.R.attr;
import at.bookworm.R.style;
import at.bookworm.R.styleable;

public class SegmentedControlButton extends RadioButton
{
  private int mLineHeightSelected;
  private int mLineHeightUnselected;
  private Paint mLinePaint;
  private boolean mTextAllCaps;

  public SegmentedControlButton(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, R.attr.segmentedControlButtonStyle);
  }

  public SegmentedControlButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    init(paramAttributeSet, paramInt);
  }

  public int getLineColor()
  {
    return this.mLinePaint.getColor();
  }

  public int getLineHeightUnselected()
  {
    return this.mLineHeightUnselected;
  }

  public void init(AttributeSet paramAttributeSet, int paramInt)
  {
    if (paramAttributeSet != null)
    {
      TypedArray localTypedArray = getContext().obtainStyledAttributes(paramAttributeSet, R.styleable.SegmentedControlButton, paramInt, R.style.Widget_Holo_SegmentedControl);
      this.mTextAllCaps = localTypedArray.getBoolean(1, false);
      setTextCompat(getText());
      int i = localTypedArray.getColor(2, 0);
      this.mLineHeightUnselected = localTypedArray.getDimensionPixelSize(3, 0);
      this.mLineHeightSelected = localTypedArray.getDimensionPixelSize(4, 0);
      this.mLinePaint = new Paint();
      this.mLinePaint.setColor(i);
      this.mLinePaint.setStyle(Paint.Style.FILL);
      localTypedArray.recycle();
    }
  }

  public void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    if ((this.mLinePaint.getColor() != 0) && ((this.mLineHeightSelected > 0) || (this.mLineHeightUnselected > 0)))
      if (!isChecked())
        break label76;
    label76: for (int i = this.mLineHeightSelected; ; i = this.mLineHeightUnselected)
    {
      if (i > 0)
        paramCanvas.drawRect(new Rect(0, getHeight() - i, getWidth(), getHeight()), this.mLinePaint);
      return;
    }
  }

  public void setLineColor(int paramInt)
  {
    this.mLinePaint.setColor(paramInt);
  }

  public void setTextCompat(CharSequence paramCharSequence)
  {
    if (this.mTextAllCaps)
    {
      setText(paramCharSequence.toString().toUpperCase());
      return;
    }
    setText(paramCharSequence);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     at.bookworm.widget.SegmentedControlButton
 * JD-Core Version:    0.6.2
 */