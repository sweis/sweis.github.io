package com.commonsware.cwac.camera;

import android.hardware.Camera.Parameters;
import android.hardware.Camera.Size;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class CameraUtils
{
  private static final double ASPECT_TOLERANCE = 0.1D;

  public static String findBestFlashModeMatch(Camera.Parameters paramParameters, String[] paramArrayOfString)
  {
    List localList = paramParameters.getSupportedFlashModes();
    int i;
    if (localList != null)
      i = paramArrayOfString.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return null;
      String str = paramArrayOfString[j];
      if (localList.contains(str))
        return str;
    }
  }

  public static Camera.Size getBestAspectPreviewSize(int paramInt1, int paramInt2, int paramInt3, Camera.Parameters paramParameters)
  {
    return getBestAspectPreviewSize(paramInt1, paramInt2, paramInt3, paramParameters, 0.0D);
  }

  public static Camera.Size getBestAspectPreviewSize(int paramInt1, int paramInt2, int paramInt3, Camera.Parameters paramParameters, double paramDouble)
  {
    double d1 = paramInt2 / paramInt3;
    Object localObject = null;
    double d2 = 1.7976931348623157E+308D;
    if ((paramInt1 == 90) || (paramInt1 == 270))
      d1 = paramInt3 / paramInt2;
    List localList = paramParameters.getSupportedPreviewSizes();
    Collections.sort(localList, Collections.reverseOrder(new SizeComparator(null)));
    Iterator localIterator = localList.iterator();
    do
    {
      if (!localIterator.hasNext())
        return localObject;
      Camera.Size localSize = (Camera.Size)localIterator.next();
      double d3 = localSize.width / localSize.height;
      if (Math.abs(d3 - d1) < d2)
      {
        localObject = localSize;
        d2 = Math.abs(d3 - d1);
      }
    }
    while (d2 >= paramDouble);
    return localObject;
  }

  public static Camera.Size getLargestPictureSize(CameraHost paramCameraHost, Camera.Parameters paramParameters)
  {
    Object localObject = null;
    Iterator localIterator = paramParameters.getSupportedPictureSizes().iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return localObject;
      Camera.Size localSize = (Camera.Size)localIterator.next();
      if ((localSize.height <= paramCameraHost.getDeviceProfile().getMaxPictureHeight()) && (localSize.height >= paramCameraHost.getDeviceProfile().getMinPictureHeight()))
        if (localObject == null)
        {
          localObject = localSize;
        }
        else
        {
          int i = ((Camera.Size)localObject).width * ((Camera.Size)localObject).height;
          if (localSize.width * localSize.height > i)
            localObject = localSize;
        }
    }
  }

  public static Camera.Size getOptimalPreviewSize(int paramInt1, int paramInt2, int paramInt3, Camera.Parameters paramParameters)
  {
    double d1 = paramInt2 / paramInt3;
    List localList = paramParameters.getSupportedPreviewSizes();
    Object localObject = null;
    double d2 = 1.7976931348623157E+308D;
    if ((paramInt1 == 90) || (paramInt1 == 270))
      d1 = paramInt3 / paramInt2;
    Iterator localIterator1 = localList.iterator();
    double d3;
    Iterator localIterator2;
    if (!localIterator1.hasNext())
      if (localObject == null)
      {
        d3 = 1.7976931348623157E+308D;
        localIterator2 = localList.iterator();
      }
    while (true)
    {
      if (!localIterator2.hasNext())
      {
        return localObject;
        Camera.Size localSize1 = (Camera.Size)localIterator1.next();
        if ((Math.abs(localSize1.width / localSize1.height - d1) > 0.1D) || (Math.abs(localSize1.height - paramInt3) >= d2))
          break;
        localObject = localSize1;
        d2 = Math.abs(localSize1.height - paramInt3);
        break;
      }
      Camera.Size localSize2 = (Camera.Size)localIterator2.next();
      if (Math.abs(localSize2.height - paramInt3) < d3)
      {
        localObject = localSize2;
        d3 = Math.abs(localSize2.height - paramInt3);
      }
    }
  }

  public static Camera.Size getSmallestPictureSize(Camera.Parameters paramParameters)
  {
    Object localObject = null;
    Iterator localIterator = paramParameters.getSupportedPictureSizes().iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return localObject;
      Camera.Size localSize = (Camera.Size)localIterator.next();
      if (localObject == null)
      {
        localObject = localSize;
      }
      else
      {
        int i = ((Camera.Size)localObject).width * ((Camera.Size)localObject).height;
        if (localSize.width * localSize.height < i)
          localObject = localSize;
      }
    }
  }

  private static class SizeComparator
    implements Comparator<Camera.Size>
  {
    public int compare(Camera.Size paramSize1, Camera.Size paramSize2)
    {
      int i = paramSize1.width * paramSize1.height;
      int j = paramSize2.width * paramSize2.height;
      if (i < j)
        return -1;
      if (i > j)
        return 1;
      return 0;
    }
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.commonsware.cwac.camera.CameraUtils
 * JD-Core Version:    0.6.2
 */