package com.commonsware.cwac.camera;

import android.hardware.Camera.ShutterCallback;

public class PictureTransaction
  implements Camera.ShutterCallback
{
  CameraView cameraView = null;
  int displayOrientation = 0;
  String flashMode = null;
  CameraHost host = null;
  boolean mirrorFFC = false;
  boolean needBitmap = false;
  boolean needByteArray = true;
  private Object tag = null;
  boolean useSingleShotMode = false;

  public PictureTransaction(CameraHost paramCameraHost)
  {
    this.host = paramCameraHost;
  }

  PictureTransaction displayOrientation(int paramInt)
  {
    this.displayOrientation = paramInt;
    return this;
  }

  public PictureTransaction flashMode(String paramString)
  {
    this.flashMode = paramString;
    return this;
  }

  public Object getTag()
  {
    return this.tag;
  }

  public PictureTransaction mirrorFFC(boolean paramBoolean)
  {
    this.mirrorFFC = paramBoolean;
    return this;
  }

  boolean mirrorFFC()
  {
    return (this.mirrorFFC) || (this.host.mirrorFFC());
  }

  public PictureTransaction needBitmap(boolean paramBoolean)
  {
    this.needBitmap = paramBoolean;
    return this;
  }

  public PictureTransaction needByteArray(boolean paramBoolean)
  {
    this.needByteArray = paramBoolean;
    return this;
  }

  public void onShutter()
  {
    Camera.ShutterCallback localShutterCallback = this.host.getShutterCallback();
    if (localShutterCallback != null)
      localShutterCallback.onShutter();
  }

  public PictureTransaction tag(Object paramObject)
  {
    this.tag = paramObject;
    return this;
  }

  public PictureTransaction useSingleShotMode(boolean paramBoolean)
  {
    this.useSingleShotMode = paramBoolean;
    return this;
  }

  boolean useSingleShotMode()
  {
    return (this.useSingleShotMode) || (this.host.useSingleShotMode());
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.commonsware.cwac.camera.PictureTransaction
 * JD-Core Version:    0.6.2
 */