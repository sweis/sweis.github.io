package com.commonsware.cwac.camera;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.hardware.Camera;
import android.hardware.Camera.AutoFocusCallback;
import android.hardware.Camera.CameraInfo;
import android.hardware.Camera.FaceDetectionListener;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.Size;
import android.media.MediaRecorder;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.OrientationEventListener;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import java.io.IOException;

public class CameraView extends ViewGroup
  implements Camera.AutoFocusCallback
{
  static final String TAG = "CWAC-Camera";
  private Camera camera = null;
  private int cameraId = -1;
  private int displayOrientation = -1;
  private CameraHost host = null;
  private boolean inPreview = false;
  private boolean isAutoFocusing = false;
  private boolean isDetectingFaces = false;
  private int lastPictureOrientation = -1;
  private OnOrientationChange onOrientationChange = null;
  private int outputOrientation = -1;
  private Camera.Parameters previewParams = null;
  private Camera.Size previewSize;
  private PreviewStrategy previewStrategy;
  private MediaRecorder recorder = null;

  public CameraView(Context paramContext)
  {
    super(paramContext);
    this.onOrientationChange = new OnOrientationChange(paramContext);
  }

  public CameraView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public CameraView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.onOrientationChange = new OnOrientationChange(paramContext);
    if ((paramContext instanceof CameraHostProvider))
    {
      setHost(((CameraHostProvider)paramContext).getCameraHost());
      return;
    }
    throw new IllegalArgumentException("To use the two- or three-parameter constructors on CameraView, your activity needs to implement the CameraHostProvider interface");
  }

  private int getCameraPictureRotation(int paramInt)
  {
    Camera.CameraInfo localCameraInfo = new Camera.CameraInfo();
    Camera.getCameraInfo(this.cameraId, localCameraInfo);
    int i = 90 * ((paramInt + 45) / 90);
    if (localCameraInfo.facing == 1)
      return (360 + (localCameraInfo.orientation - i)) % 360;
    return (i + localCameraInfo.orientation) % 360;
  }

  private void previewStopped()
  {
    if (this.inPreview)
      stopPreview();
  }

  private void setCameraDisplayOrientation()
  {
    Camera.CameraInfo localCameraInfo = new Camera.CameraInfo();
    int i = getActivity().getWindowManager().getDefaultDisplay().getRotation();
    DisplayMetrics localDisplayMetrics = new DisplayMetrics();
    Camera.getCameraInfo(this.cameraId, localCameraInfo);
    getActivity().getWindowManager().getDefaultDisplay().getMetrics(localDisplayMetrics);
    int j = 0;
    switch (i)
    {
    default:
      if (localCameraInfo.facing == 1)
        this.displayOrientation = ((j + localCameraInfo.orientation) % 360);
      break;
    case 0:
    case 1:
    case 2:
    case 3:
    }
    for (this.displayOrientation = ((360 - this.displayOrientation) % 360); ; this.displayOrientation = ((360 + (localCameraInfo.orientation - j)) % 360))
    {
      boolean bool = this.inPreview;
      if (this.inPreview)
        stopPreview();
      this.camera.setDisplayOrientation(this.displayOrientation);
      if (bool)
        startPreview();
      return;
      j = 0;
      break;
      j = 90;
      break;
      j = 180;
      break;
      j = 270;
      break;
    }
  }

  private void setCameraPictureOrientation(Camera.Parameters paramParameters)
  {
    Camera.CameraInfo localCameraInfo = new Camera.CameraInfo();
    Camera.getCameraInfo(this.cameraId, localCameraInfo);
    if (getActivity().getRequestedOrientation() != -1)
      this.outputOrientation = getCameraPictureRotation(getActivity().getWindowManager().getDefaultDisplay().getOrientation());
    while (true)
    {
      if (this.lastPictureOrientation != this.outputOrientation)
      {
        paramParameters.setRotation(this.outputOrientation);
        this.lastPictureOrientation = this.outputOrientation;
      }
      return;
      if (localCameraInfo.facing == 1)
        this.outputOrientation = ((360 - this.displayOrientation) % 360);
      else
        this.outputOrientation = this.displayOrientation;
    }
  }

  private void startPreview()
  {
    this.camera.startPreview();
    this.inPreview = true;
    getHost().autoFocusAvailable();
  }

  private void stopPreview()
  {
    this.inPreview = false;
    getHost().autoFocusUnavailable();
    this.camera.stopPreview();
  }

  public void autoFocus()
  {
    if (this.inPreview)
    {
      this.camera.autoFocus(this);
      this.isAutoFocusing = true;
    }
  }

  public void cancelAutoFocus()
  {
    this.camera.cancelAutoFocus();
  }

  public boolean doesZoomReallyWork()
  {
    int i = 1;
    Camera.CameraInfo localCameraInfo = new Camera.CameraInfo();
    Camera.getCameraInfo(getHost().getCameraId(), localCameraInfo);
    DeviceProfile localDeviceProfile = getHost().getDeviceProfile();
    if (localCameraInfo.facing == i);
    while (true)
    {
      return localDeviceProfile.doesZoomActuallyWork(i);
      int j = 0;
    }
  }

  Activity getActivity()
  {
    return (Activity)getContext();
  }

  public int getDisplayOrientation()
  {
    return this.displayOrientation;
  }

  public String getFlashMode()
  {
    return this.camera.getParameters().getFlashMode();
  }

  public CameraHost getHost()
  {
    return this.host;
  }

  public void initPreview(int paramInt1, int paramInt2)
  {
    initPreview(paramInt1, paramInt2, true);
  }

  @TargetApi(14)
  public void initPreview(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    Camera.Parameters localParameters;
    if (this.camera != null)
    {
      localParameters = this.camera.getParameters();
      localParameters.setPreviewSize(this.previewSize.width, this.previewSize.height);
      if (Build.VERSION.SDK_INT >= 14)
        if (getHost().getRecordingHint() == CameraHost.RecordingHint.STILL_ONLY)
          break label95;
    }
    label95: for (boolean bool = true; ; bool = false)
    {
      localParameters.setRecordingHint(bool);
      requestLayout();
      this.camera.setParameters(getHost().adjustPreviewParameters(localParameters));
      startPreview();
      return;
    }
  }

  public boolean isAutoFocusAvailable()
  {
    return this.inPreview;
  }

  public boolean isRecording()
  {
    return this.recorder != null;
  }

  public void lockToLandscape(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      getActivity().setRequestedOrientation(6);
      this.onOrientationChange.enable();
    }
    while (true)
    {
      post(new Runnable()
      {
        public void run()
        {
          CameraView.this.setCameraDisplayOrientation();
        }
      });
      return;
      getActivity().setRequestedOrientation(-1);
      this.onOrientationChange.disable();
    }
  }

  public void onAutoFocus(boolean paramBoolean, Camera paramCamera)
  {
    this.isAutoFocusing = false;
    if ((getHost() instanceof Camera.AutoFocusCallback))
      getHost().onAutoFocus(paramBoolean, paramCamera);
  }

  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    View localView;
    int i;
    int j;
    int k;
    int m;
    if ((paramBoolean) && (getChildCount() > 0))
    {
      localView = getChildAt(0);
      i = paramInt3 - paramInt1;
      j = paramInt4 - paramInt2;
      k = i;
      m = j;
      if (this.previewSize != null)
      {
        if ((getDisplayOrientation() != 90) && (getDisplayOrientation() != 270))
          break label162;
        k = this.previewSize.height;
        m = this.previewSize.width;
      }
      if (i * m <= j * k)
        break label183;
    }
    label162: label183: for (int n = 1; ; n = 0)
    {
      boolean bool = getHost().useFullBleedPreview();
      if (((n == 0) || (bool)) && ((n != 0) || (!bool)))
        break label189;
      int i2 = k * j / m;
      localView.layout((i - i2) / 2, 0, (i + i2) / 2, j);
      return;
      k = this.previewSize.width;
      m = this.previewSize.height;
      break;
    }
    label189: int i1 = m * i / k;
    localView.layout(0, (j - i1) / 2, i, (j + i1) / 2);
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int i = resolveSize(getSuggestedMinimumWidth(), paramInt1);
    int j = resolveSize(getSuggestedMinimumHeight(), paramInt2);
    setMeasuredDimension(i, j);
    Object localObject;
    if ((i > 0) && (j > 0) && (this.camera != null))
      localObject = null;
    try
    {
      CameraHost.RecordingHint localRecordingHint1 = getHost().getRecordingHint();
      CameraHost.RecordingHint localRecordingHint2 = CameraHost.RecordingHint.STILL_ONLY;
      localObject = null;
      if (localRecordingHint1 != localRecordingHint2)
        localObject = getHost().getPreferredPreviewSizeForVideo(getDisplayOrientation(), i, j, this.camera.getParameters(), null);
      if ((localObject == null) || (((Camera.Size)localObject).width * ((Camera.Size)localObject).height < 65536))
      {
        Camera.Size localSize = getHost().getPreviewSize(getDisplayOrientation(), i, j, this.camera.getParameters());
        localObject = localSize;
      }
      if (localObject != null)
      {
        if (this.previewSize == null)
          this.previewSize = ((Camera.Size)localObject);
      }
      else
        return;
    }
    catch (Exception localException)
    {
      do
        while (true)
          Log.e(getClass().getSimpleName(), "Could not work with camera parameters?", localException);
      while ((this.previewSize.width == ((Camera.Size)localObject).width) && (this.previewSize.height == ((Camera.Size)localObject).height));
      if (this.inPreview)
        stopPreview();
      this.previewSize = ((Camera.Size)localObject);
      initPreview(i, j, false);
    }
  }

  public void onPause()
  {
    if (this.camera != null)
    {
      previewDestroyed();
      removeView(this.previewStrategy.getWidget());
    }
  }

  @TargetApi(14)
  public void onResume()
  {
    addView(this.previewStrategy.getWidget());
    if (this.camera == null)
    {
      this.cameraId = getHost().getCameraId();
      if (this.cameraId < 0);
    }
    else
    {
      try
      {
        this.camera = Camera.open(this.cameraId);
        if (getActivity().getRequestedOrientation() != -1)
          this.onOrientationChange.enable();
        setCameraDisplayOrientation();
        if ((Build.VERSION.SDK_INT >= 14) && ((getHost() instanceof Camera.FaceDetectionListener)))
          this.camera.setFaceDetectionListener((Camera.FaceDetectionListener)getHost());
        return;
      }
      catch (Exception localException)
      {
        getHost().onCameraFail(CameraHost.FailureReason.UNKNOWN);
        return;
      }
    }
    getHost().onCameraFail(CameraHost.FailureReason.NO_CAMERAS_REPORTED);
  }

  void previewCreated()
  {
    if (this.camera != null);
    try
    {
      this.previewStrategy.attach(this.camera);
      return;
    }
    catch (IOException localIOException)
    {
      getHost().handleException(localIOException);
    }
  }

  void previewDestroyed()
  {
    if (this.camera != null)
    {
      previewStopped();
      this.camera.release();
      this.camera = null;
    }
  }

  void previewReset(int paramInt1, int paramInt2)
  {
    previewStopped();
    initPreview(paramInt1, paramInt2);
  }

  public void record()
    throws Exception
  {
    if (Build.VERSION.SDK_INT < 11)
      throw new UnsupportedOperationException("Video recording supported only on API Level 11+");
    Camera.Parameters localParameters = this.camera.getParameters();
    setCameraPictureOrientation(localParameters);
    this.camera.setParameters(localParameters);
    stopPreview();
    this.camera.unlock();
    try
    {
      this.recorder = new MediaRecorder();
      this.recorder.setCamera(this.camera);
      getHost().configureRecorderAudio(this.cameraId, this.recorder);
      this.recorder.setVideoSource(1);
      getHost().configureRecorderProfile(this.cameraId, this.recorder);
      getHost().configureRecorderOutput(this.cameraId, this.recorder);
      this.recorder.setOrientationHint(this.outputOrientation);
      this.previewStrategy.attach(this.recorder);
      this.recorder.prepare();
      this.recorder.start();
      return;
    }
    catch (IOException localIOException)
    {
      this.recorder.release();
      this.recorder = null;
      throw localIOException;
    }
  }

  public void restartPreview()
  {
    if (!this.inPreview)
      startPreview();
  }

  public void setFlashMode(String paramString)
  {
    if (this.camera != null)
    {
      Camera.Parameters localParameters = this.camera.getParameters();
      localParameters.setFlashMode(paramString);
      this.camera.setParameters(localParameters);
    }
  }

  public void setHost(CameraHost paramCameraHost)
  {
    this.host = paramCameraHost;
    if (paramCameraHost.getDeviceProfile().useTextureView())
    {
      this.previewStrategy = new TexturePreviewStrategy(this);
      return;
    }
    this.previewStrategy = new SurfacePreviewStrategy(this);
  }

  @TargetApi(14)
  public void startFaceDetection()
  {
    if ((Build.VERSION.SDK_INT >= 14) && (this.camera != null) && (!this.isDetectingFaces) && (this.camera.getParameters().getMaxNumDetectedFaces() > 0))
    {
      this.camera.startFaceDetection();
      this.isDetectingFaces = true;
    }
  }

  public void stopFaceDetection()
  {
    if ((Build.VERSION.SDK_INT >= 14) && (this.camera != null) && (this.isDetectingFaces))
    {
      this.camera.stopFaceDetection();
      this.isDetectingFaces = false;
    }
  }

  public void stopRecording()
    throws IOException
  {
    if (Build.VERSION.SDK_INT < 11)
      throw new UnsupportedOperationException("Video recording supported only on API Level 11+");
    MediaRecorder localMediaRecorder = this.recorder;
    this.recorder = null;
    localMediaRecorder.stop();
    localMediaRecorder.release();
    this.camera.reconnect();
  }

  public void takePicture(final PictureTransaction paramPictureTransaction)
  {
    if (this.inPreview)
    {
      if (this.isAutoFocusing)
        throw new IllegalStateException("Camera cannot take a picture while auto-focusing");
      this.previewParams = this.camera.getParameters();
      Camera.Parameters localParameters = this.camera.getParameters();
      Camera.Size localSize = paramPictureTransaction.host.getPictureSize(paramPictureTransaction, localParameters);
      localParameters.setPictureSize(localSize.width, localSize.height);
      localParameters.setPictureFormat(256);
      if (paramPictureTransaction.flashMode != null)
        localParameters.setFlashMode(paramPictureTransaction.flashMode);
      setCameraPictureOrientation(localParameters);
      this.camera.setParameters(paramPictureTransaction.host.adjustPictureParameters(paramPictureTransaction, localParameters));
      paramPictureTransaction.cameraView = this;
      postDelayed(new Runnable()
      {
        public void run()
        {
          CameraView.this.camera.takePicture(paramPictureTransaction, null, new CameraView.PictureTransactionCallback(CameraView.this, paramPictureTransaction));
        }
      }
      , paramPictureTransaction.host.getDeviceProfile().getPictureDelay());
      this.inPreview = false;
      return;
    }
    throw new IllegalStateException("Preview mode must have started before you can take a picture");
  }

  public void takePicture(boolean paramBoolean1, boolean paramBoolean2)
  {
    takePicture(new PictureTransaction(getHost()).needBitmap(paramBoolean1).needByteArray(paramBoolean2));
  }

  public ZoomTransaction zoomTo(int paramInt)
  {
    if (this.camera == null)
      throw new IllegalStateException("Yes, we have no camera, we have no camera today");
    Camera.Parameters localParameters = this.camera.getParameters();
    if ((paramInt >= 0) && (paramInt <= localParameters.getMaxZoom()))
      return new ZoomTransaction(this.camera, paramInt);
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = Integer.valueOf(paramInt);
    throw new IllegalArgumentException(String.format("Invalid zoom level: %d", arrayOfObject));
  }

  private class OnOrientationChange extends OrientationEventListener
  {
    public OnOrientationChange(Context arg2)
    {
      super();
      disable();
    }

    public void onOrientationChanged(int paramInt)
    {
      if ((CameraView.this.camera != null) && (paramInt != -1))
      {
        int i = CameraView.this.getCameraPictureRotation(paramInt);
        if (i != CameraView.this.outputOrientation)
        {
          CameraView.this.outputOrientation = i;
          Camera.Parameters localParameters = CameraView.this.camera.getParameters();
          localParameters.setRotation(CameraView.this.outputOrientation);
          CameraView.this.camera.setParameters(localParameters);
          CameraView.this.lastPictureOrientation = CameraView.this.outputOrientation;
        }
      }
    }
  }

  private class PictureTransactionCallback
    implements Camera.PictureCallback
  {
    PictureTransaction xact = null;

    PictureTransactionCallback(PictureTransaction arg2)
    {
      Object localObject;
      this.xact = localObject;
    }

    public void onPictureTaken(byte[] paramArrayOfByte, Camera paramCamera)
    {
      paramCamera.setParameters(CameraView.this.previewParams);
      if (paramArrayOfByte != null)
        new ImageCleanupTask(CameraView.this.getContext(), paramArrayOfByte, CameraView.this.cameraId, this.xact).start();
      if (!this.xact.useSingleShotMode())
        CameraView.this.startPreview();
    }
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.commonsware.cwac.camera.CameraView
 * JD-Core Version:    0.6.2
 */