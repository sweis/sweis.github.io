package com.commonsware.cwac.camera;

import android.annotation.TargetApi;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

@TargetApi(11)
public class CameraFragment extends Fragment
{
  private CameraView cameraView = null;
  private CameraHost host = null;

  public void autoFocus()
  {
    this.cameraView.autoFocus();
  }

  public void cancelAutoFocus()
  {
    this.cameraView.cancelAutoFocus();
  }

  public boolean doesZoomReallyWork()
  {
    return this.cameraView.doesZoomReallyWork();
  }

  public int getDisplayOrientation()
  {
    return this.cameraView.getDisplayOrientation();
  }

  public String getFlashMode()
  {
    return this.cameraView.getFlashMode();
  }

  public CameraHost getHost()
  {
    if (this.host == null)
      this.host = new SimpleCameraHost(getActivity());
    return this.host;
  }

  public boolean isAutoFocusAvailable()
  {
    return this.cameraView.isAutoFocusAvailable();
  }

  public boolean isRecording()
  {
    if (this.cameraView == null)
      return false;
    return this.cameraView.isRecording();
  }

  public void lockToLandscape(boolean paramBoolean)
  {
    this.cameraView.lockToLandscape(paramBoolean);
  }

  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle)
  {
    this.cameraView = new CameraView(getActivity());
    this.cameraView.setHost(getHost());
    return this.cameraView;
  }

  public void onPause()
  {
    this.cameraView.onPause();
    super.onPause();
  }

  public void onResume()
  {
    super.onResume();
    this.cameraView.onResume();
  }

  public void record()
    throws Exception
  {
    this.cameraView.record();
  }

  public void restartPreview()
  {
    this.cameraView.restartPreview();
  }

  protected void setCameraView(CameraView paramCameraView)
  {
    this.cameraView = paramCameraView;
  }

  public void setFlashMode(String paramString)
  {
    this.cameraView.setFlashMode(paramString);
  }

  public void setHost(CameraHost paramCameraHost)
  {
    this.host = paramCameraHost;
  }

  public void startFaceDetection()
  {
    this.cameraView.startFaceDetection();
  }

  public void stopFaceDetection()
  {
    this.cameraView.stopFaceDetection();
  }

  public void stopRecording()
    throws Exception
  {
    this.cameraView.stopRecording();
  }

  public void takePicture()
  {
    takePicture(false, true);
  }

  public void takePicture(PictureTransaction paramPictureTransaction)
  {
    this.cameraView.takePicture(paramPictureTransaction);
  }

  public void takePicture(boolean paramBoolean1, boolean paramBoolean2)
  {
    this.cameraView.takePicture(paramBoolean1, paramBoolean2);
  }

  public ZoomTransaction zoomTo(int paramInt)
  {
    return this.cameraView.zoomTo(paramInt);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.commonsware.cwac.camera.CameraFragment
 * JD-Core Version:    0.6.2
 */