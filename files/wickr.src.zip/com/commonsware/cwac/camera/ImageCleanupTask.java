package com.commonsware.cwac.camera;

import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.os.Build.VERSION;
import android.util.Log;
import com.android.mms.exif.ExifInterface;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class ImageCleanupTask extends Thread
{
  private boolean applyMatrix;
  private int cameraId;
  private byte[] data;
  private PictureTransaction xact = null;

  ImageCleanupTask(Context paramContext, byte[] paramArrayOfByte, int paramInt, PictureTransaction paramPictureTransaction)
  {
    this.applyMatrix = bool;
    this.data = paramArrayOfByte;
    this.cameraId = paramInt;
    this.xact = paramPictureTransaction;
    if (paramArrayOfByte.length / calculateHeapSize(paramContext) < paramPictureTransaction.host.maxPictureCleanupHeapUsage());
    while (true)
    {
      this.applyMatrix = bool;
      return;
      bool = false;
    }
  }

  @TargetApi(11)
  private static int calculateHeapSize(Context paramContext)
  {
    ActivityManager localActivityManager = (ActivityManager)paramContext.getSystemService("activity");
    int i = localActivityManager.getMemoryClass();
    if ((Build.VERSION.SDK_INT >= 11) && ((0x100000 & paramContext.getApplicationInfo().flags) != 0))
      i = localActivityManager.getLargeMemoryClass();
    return i * 1048576;
  }

  private Matrix flip(Matrix paramMatrix)
  {
    float[] arrayOfFloat = { -1.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 1.0F };
    Matrix localMatrix = new Matrix();
    localMatrix.setValues(arrayOfFloat);
    paramMatrix.preScale(1.0F, -1.0F);
    paramMatrix.postConcat(localMatrix);
    return paramMatrix;
  }

  private Matrix mirror(Matrix paramMatrix)
  {
    float[] arrayOfFloat = { -1.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 1.0F };
    Matrix localMatrix = new Matrix();
    localMatrix.setValues(arrayOfFloat);
    paramMatrix.postConcat(localMatrix);
    return paramMatrix;
  }

  private Matrix rotate(Matrix paramMatrix, int paramInt)
  {
    paramMatrix.setRotate(paramInt);
    return paramMatrix;
  }

  public void run()
  {
    Camera.CameraInfo localCameraInfo = new Camera.CameraInfo();
    Camera.getCameraInfo(this.cameraId, localCameraInfo);
    boolean bool1 = this.applyMatrix;
    Object localObject1 = null;
    Bitmap localBitmap1 = null;
    if (bool1)
    {
      int i = localCameraInfo.facing;
      localObject1 = null;
      if (i == 1)
      {
        if ((!this.xact.host.getDeviceProfile().portraitFFCFlipped()) || ((this.xact.displayOrientation != 90) && (this.xact.displayOrientation != 270)))
          break label327;
        localObject1 = flip(new Matrix());
      }
    }
    try
    {
      if (this.xact.host.getDeviceProfile().useDeviceOrientation())
      {
        j = this.xact.displayOrientation;
        if (j != 0)
        {
          if (localObject1 != null)
            break label462;
          localObject2 = new Matrix();
          Matrix localMatrix = rotate((Matrix)localObject2, j);
          localObject1 = localMatrix;
        }
        localBitmap1 = null;
        if (localObject1 != null)
        {
          Bitmap localBitmap2 = BitmapFactory.decodeByteArray(this.data, 0, this.data.length);
          localBitmap1 = Bitmap.createBitmap(localBitmap2, 0, 0, localBitmap2.getWidth(), localBitmap2.getHeight(), (Matrix)localObject1, true);
          localBitmap2.recycle();
        }
        if (this.xact.needBitmap)
        {
          if (localBitmap1 == null)
            localBitmap1 = BitmapFactory.decodeByteArray(this.data, 0, this.data.length);
          this.xact.host.saveImage(this.xact, localBitmap1);
        }
        if (this.xact.needByteArray)
          if (localObject1 != null)
          {
            localByteArrayOutputStream = new ByteArrayOutputStream();
            localBitmap1.compress(Bitmap.CompressFormat.JPEG, 100, localByteArrayOutputStream);
            this.data = localByteArrayOutputStream.toByteArray();
          }
      }
    }
    catch (IOException localIOException1)
    {
      while (true)
        try
        {
          ByteArrayOutputStream localByteArrayOutputStream;
          localByteArrayOutputStream.close();
          this.xact.host.saveImage(this.xact, this.data);
          System.gc();
          return;
          label327: boolean bool2 = this.xact.mirrorFFC();
          localObject1 = null;
          if (bool2)
          {
            localObject1 = mirror(new Matrix());
            continue;
            localExifInterface = new ExifInterface();
          }
        }
        catch (IOException localIOException1)
        {
          try
          {
            Object localObject2;
            ExifInterface localExifInterface;
            localExifInterface.readExif(this.data);
            Integer localInteger = localExifInterface.getTagIntValue(ExifInterface.TAG_ORIENTATION);
            if (localInteger != null)
            {
              if (localInteger.intValue() == 6)
              {
                j = 90;
                continue;
              }
              if (localInteger.intValue() == 8)
              {
                j = 270;
                continue;
              }
              if (localInteger.intValue() == 3)
              {
                j = 180;
                continue;
              }
              int k = localInteger.intValue();
              if (k == 1)
              {
                j = 0;
                continue;
                label462: localObject2 = localObject1;
                continue;
                localIOException2 = localIOException2;
                Log.e("CWAC-Camera", "Exception parsing JPEG", localIOException2);
                continue;
                localIOException1 = localIOException1;
                Log.e("CWAC-Camera", "Exception in closing a BAOS???", localIOException1);
              }
            }
          }
          catch (IOException localIOException3)
          {
            continue;
            int j = 0;
          }
        }
    }
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.commonsware.cwac.camera.ImageCleanupTask
 * JD-Core Version:    0.6.2
 */