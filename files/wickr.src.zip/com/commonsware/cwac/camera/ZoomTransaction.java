package com.commonsware.cwac.camera;

import android.hardware.Camera;
import android.hardware.Camera.OnZoomChangeListener;
import android.hardware.Camera.Parameters;

public final class ZoomTransaction
  implements Camera.OnZoomChangeListener
{
  private Camera camera;
  private int level;
  private Camera.OnZoomChangeListener onChange = null;
  private Runnable onComplete = null;

  ZoomTransaction(Camera paramCamera, int paramInt)
  {
    this.camera = paramCamera;
    this.level = paramInt;
  }

  public void cancel()
  {
    this.camera.stopSmoothZoom();
  }

  public void go()
  {
    Camera.Parameters localParameters = this.camera.getParameters();
    if (localParameters.isSmoothZoomSupported())
    {
      this.camera.setZoomChangeListener(this);
      this.camera.startSmoothZoom(this.level);
      return;
    }
    localParameters.setZoom(this.level);
    this.camera.setParameters(localParameters);
    onZoomChange(this.level, true, this.camera);
  }

  public ZoomTransaction onChange(Camera.OnZoomChangeListener paramOnZoomChangeListener)
  {
    this.onChange = paramOnZoomChangeListener;
    return this;
  }

  public ZoomTransaction onComplete(Runnable paramRunnable)
  {
    this.onComplete = paramRunnable;
    return this;
  }

  public void onZoomChange(int paramInt, boolean paramBoolean, Camera paramCamera)
  {
    if (this.onChange != null)
      this.onChange.onZoomChange(paramInt, paramBoolean, paramCamera);
    if ((paramBoolean) && (this.onComplete != null))
      this.onComplete.run();
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.commonsware.cwac.camera.ZoomTransaction
 * JD-Core Version:    0.6.2
 */