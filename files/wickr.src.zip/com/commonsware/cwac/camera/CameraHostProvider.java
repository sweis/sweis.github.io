package com.commonsware.cwac.camera;

public abstract interface CameraHostProvider
{
  public abstract CameraHost getCameraHost();
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.commonsware.cwac.camera.CameraHostProvider
 * JD-Core Version:    0.6.2
 */