package com.commonsware.cwac.camera;

import android.graphics.Bitmap;
import android.hardware.Camera.AutoFocusCallback;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.ShutterCallback;
import android.hardware.Camera.Size;
import android.media.MediaRecorder;

public abstract interface CameraHost extends Camera.AutoFocusCallback
{
  public abstract Camera.Parameters adjustPictureParameters(PictureTransaction paramPictureTransaction, Camera.Parameters paramParameters);

  public abstract Camera.Parameters adjustPreviewParameters(Camera.Parameters paramParameters);

  public abstract void autoFocusAvailable();

  public abstract void autoFocusUnavailable();

  public abstract void configureRecorderAudio(int paramInt, MediaRecorder paramMediaRecorder);

  public abstract void configureRecorderOutput(int paramInt, MediaRecorder paramMediaRecorder);

  public abstract void configureRecorderProfile(int paramInt, MediaRecorder paramMediaRecorder);

  public abstract int getCameraId();

  public abstract DeviceProfile getDeviceProfile();

  public abstract Camera.Size getPictureSize(PictureTransaction paramPictureTransaction, Camera.Parameters paramParameters);

  public abstract Camera.Size getPreferredPreviewSizeForVideo(int paramInt1, int paramInt2, int paramInt3, Camera.Parameters paramParameters, Camera.Size paramSize);

  public abstract Camera.Size getPreviewSize(int paramInt1, int paramInt2, int paramInt3, Camera.Parameters paramParameters);

  public abstract RecordingHint getRecordingHint();

  public abstract Camera.ShutterCallback getShutterCallback();

  public abstract void handleException(Exception paramException);

  public abstract float maxPictureCleanupHeapUsage();

  public abstract boolean mirrorFFC();

  public abstract void onCameraFail(FailureReason paramFailureReason);

  public abstract void saveImage(PictureTransaction paramPictureTransaction, Bitmap paramBitmap);

  public abstract void saveImage(PictureTransaction paramPictureTransaction, byte[] paramArrayOfByte);

  public abstract boolean useFullBleedPreview();

  public abstract boolean useSingleShotMode();

  public static enum FailureReason
  {
    int value;

    static
    {
      FailureReason[] arrayOfFailureReason = new FailureReason[2];
      arrayOfFailureReason[0] = NO_CAMERAS_REPORTED;
      arrayOfFailureReason[1] = UNKNOWN;
    }

    private FailureReason(int arg3)
    {
      int j;
      this.value = j;
    }
  }

  public static enum RecordingHint
  {
    static
    {
      ANY = new RecordingHint("ANY", 2);
      RecordingHint[] arrayOfRecordingHint = new RecordingHint[3];
      arrayOfRecordingHint[0] = STILL_ONLY;
      arrayOfRecordingHint[1] = VIDEO_ONLY;
      arrayOfRecordingHint[2] = ANY;
    }
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.commonsware.cwac.camera.CameraHost
 * JD-Core Version:    0.6.2
 */