package com.commonsware.cwac.camera;

import android.content.Context;
import android.content.res.Resources;
import android.os.Build;
import java.util.Locale;

public abstract class DeviceProfile
{
  private static volatile DeviceProfile SINGLETON = null;

  private static String clean(String paramString)
  {
    return paramString.replaceAll("[\\W]", "_").toLowerCase(Locale.US);
  }

  private static int findResource(Context paramContext)
  {
    Resources localResources = paramContext.getResources();
    StringBuilder localStringBuilder = new StringBuilder("cwac_camera_profile_");
    localStringBuilder.append(clean(Build.MANUFACTURER));
    int i = localResources.getIdentifier(localStringBuilder.toString(), "xml", paramContext.getPackageName());
    localStringBuilder.append("_");
    localStringBuilder.append(clean(Build.PRODUCT));
    int j = localResources.getIdentifier(localStringBuilder.toString(), "xml", paramContext.getPackageName());
    if (j == 0)
      return i;
    return j;
  }

  public static DeviceProfile getInstance(Context paramContext)
  {
    while (true)
    {
      try
      {
        if (SINGLETON == null)
        {
          if (("motorola".equalsIgnoreCase(Build.MANUFACTURER)) && ("XT890_rtgb".equals(Build.PRODUCT)))
            SINGLETON = new SimpleDeviceProfile.MotorolaRazrI();
        }
        else
        {
          DeviceProfile localDeviceProfile = SINGLETON;
          return localDeviceProfile;
        }
        int i = findResource(paramContext);
        if (i != 0)
        {
          SINGLETON = new SimpleDeviceProfile().load(paramContext.getResources().getXml(i));
          continue;
        }
      }
      finally
      {
      }
      SINGLETON = new SimpleDeviceProfile();
    }
  }

  private boolean isCyanogenMod()
  {
    return (System.getProperty("os.version").contains("cyanogenmod")) || (Build.HOST.contains("cyanogenmod"));
  }

  public abstract boolean doesZoomActuallyWork(boolean paramBoolean);

  public abstract int getDefaultOrientation();

  public abstract int getMaxPictureHeight();

  public abstract int getMinPictureHeight();

  public abstract int getPictureDelay();

  public abstract boolean portraitFFCFlipped();

  public abstract boolean useDeviceOrientation();

  public abstract boolean useTextureView();
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.commonsware.cwac.camera.DeviceProfile
 * JD-Core Version:    0.6.2
 */