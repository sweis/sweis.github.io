package com.commonsware.cwac.camera;

import android.hardware.Camera;
import android.media.MediaRecorder;
import android.view.View;
import java.io.IOException;

public abstract interface PreviewStrategy
{
  public abstract void attach(Camera paramCamera)
    throws IOException;

  public abstract void attach(MediaRecorder paramMediaRecorder);

  public abstract View getWidget();
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.commonsware.cwac.camera.PreviewStrategy
 * JD-Core Version:    0.6.2
 */