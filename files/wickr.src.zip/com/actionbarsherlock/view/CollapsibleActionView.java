package com.actionbarsherlock.view;

public abstract interface CollapsibleActionView
{
  public abstract void onActionViewCollapsed();

  public abstract void onActionViewExpanded();
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.actionbarsherlock.view.CollapsibleActionView
 * JD-Core Version:    0.6.2
 */