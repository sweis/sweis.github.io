package com.actionbarsherlock;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.internal.ActionBarSherlockCompat;
import com.actionbarsherlock.internal.ActionBarSherlockNative;
import com.actionbarsherlock.view.ActionMode;
import com.actionbarsherlock.view.ActionMode.Callback;
import com.actionbarsherlock.view.MenuInflater;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public abstract class ActionBarSherlock
{
  private static final Class<?>[] CONSTRUCTOR_ARGS;
  public static final int FLAG_DELEGATE = 1;
  private static final HashMap<Implementation, Class<? extends ActionBarSherlock>> IMPLEMENTATIONS;
  protected static final String TAG = "ActionBarSherlock";
  protected final Activity mActivity;
  protected final boolean mIsDelegate;
  protected MenuInflater mMenuInflater;

  static
  {
    Class[] arrayOfClass = new Class[2];
    arrayOfClass[0] = Activity.class;
    arrayOfClass[1] = Integer.TYPE;
    CONSTRUCTOR_ARGS = arrayOfClass;
    IMPLEMENTATIONS = new HashMap();
    registerImplementation(ActionBarSherlockCompat.class);
    registerImplementation(ActionBarSherlockNative.class);
  }

  protected ActionBarSherlock(Activity paramActivity, int paramInt)
  {
    Log.d("ActionBarSherlock", "[<ctor>] activity: " + paramActivity + ", flags: " + paramInt);
    this.mActivity = paramActivity;
    if ((paramInt & 0x1) != 0);
    for (boolean bool = true; ; bool = false)
    {
      this.mIsDelegate = bool;
      return;
    }
  }

  public static void registerImplementation(Class<? extends ActionBarSherlock> paramClass)
  {
    if (!paramClass.isAnnotationPresent(Implementation.class))
      throw new IllegalArgumentException("Class " + paramClass.getSimpleName() + " is not annotated with @Implementation");
    if (IMPLEMENTATIONS.containsValue(paramClass))
    {
      Log.w("ActionBarSherlock", "Class " + paramClass.getSimpleName() + " already registered");
      return;
    }
    Implementation localImplementation = (Implementation)paramClass.getAnnotation(Implementation.class);
    Log.i("ActionBarSherlock", "Registering " + paramClass.getSimpleName() + " with qualifier " + localImplementation);
    IMPLEMENTATIONS.put(localImplementation, paramClass);
  }

  public static boolean unregisterImplementation(Class<? extends ActionBarSherlock> paramClass)
  {
    return IMPLEMENTATIONS.values().remove(paramClass);
  }

  public static ActionBarSherlock wrap(Activity paramActivity)
  {
    return wrap(paramActivity, 0);
  }

  public static ActionBarSherlock wrap(Activity paramActivity, int paramInt)
  {
    HashMap localHashMap = new HashMap(IMPLEMENTATIONS);
    Iterator localIterator1 = localHashMap.keySet().iterator();
    boolean bool1 = localIterator1.hasNext();
    int i = 0;
    label37: int i1;
    label61: Iterator localIterator5;
    label72: Iterator localIterator2;
    label93: int j;
    label110: int k;
    int m;
    Iterator localIterator3;
    label134: Iterator localIterator4;
    if (!bool1)
    {
      if (i != 0)
      {
        if (paramActivity.getResources().getDisplayMetrics().densityDpi != 213)
          break label209;
        i1 = 1;
        localIterator5 = localHashMap.keySet().iterator();
        if (localIterator5.hasNext())
          break label215;
      }
      localIterator2 = localHashMap.keySet().iterator();
      boolean bool2 = localIterator2.hasNext();
      j = 0;
      if (bool2)
        break label268;
      if (j != 0)
      {
        k = Build.VERSION.SDK_INT;
        m = 0;
        localIterator3 = localHashMap.keySet().iterator();
        if (localIterator3.hasNext())
          break label293;
        localIterator4 = localHashMap.keySet().iterator();
      }
    }
    while (true)
    {
      if (!localIterator4.hasNext())
      {
        if (localHashMap.size() <= 1)
          break label371;
        throw new IllegalStateException("More than one implementation matches configuration.");
        if (((Implementation)localIterator1.next()).dpi() != 213)
          break;
        i = 1;
        break label37;
        label209: i1 = 0;
        break label61;
        label215: int i2 = ((Implementation)localIterator5.next()).dpi();
        if (((i1 == 0) || (i2 == 213)) && ((i1 != 0) || (i2 != 213)))
          break label72;
        localIterator5.remove();
        break label72;
        label268: if (((Implementation)localIterator2.next()).api() == -1)
          break label93;
        j = 1;
        break label110;
        label293: int n = ((Implementation)localIterator3.next()).api();
        if (n > k)
        {
          localIterator3.remove();
          break label134;
        }
        if (n <= m)
          break label134;
        m = n;
        break label134;
      }
      if (((Implementation)localIterator4.next()).api() != m)
        localIterator4.remove();
    }
    label371: if (localHashMap.isEmpty())
      throw new IllegalStateException("No implementations match configuration.");
    Class localClass = (Class)localHashMap.values().iterator().next();
    Log.i("ActionBarSherlock", "Using implementation: " + localClass.getSimpleName());
    try
    {
      Constructor localConstructor = localClass.getConstructor(CONSTRUCTOR_ARGS);
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = paramActivity;
      arrayOfObject[1] = Integer.valueOf(paramInt);
      ActionBarSherlock localActionBarSherlock = (ActionBarSherlock)localConstructor.newInstance(arrayOfObject);
      return localActionBarSherlock;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      throw new RuntimeException(localNoSuchMethodException);
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw new RuntimeException(localIllegalArgumentException);
    }
    catch (InstantiationException localInstantiationException)
    {
      throw new RuntimeException(localInstantiationException);
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new RuntimeException(localIllegalAccessException);
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      throw new RuntimeException(localInvocationTargetException);
    }
  }

  public abstract void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams);

  protected final boolean callbackCreateOptionsMenu(com.actionbarsherlock.view.Menu paramMenu)
  {
    Log.d("ActionBarSherlock", "[callbackCreateOptionsMenu] menu: " + paramMenu);
    boolean bool = true;
    if ((this.mActivity instanceof OnCreatePanelMenuListener))
      bool = ((OnCreatePanelMenuListener)this.mActivity).onCreatePanelMenu(0, paramMenu);
    while (true)
    {
      Log.d("ActionBarSherlock", "[callbackCreateOptionsMenu] returning " + bool);
      return bool;
      if ((this.mActivity instanceof OnCreateOptionsMenuListener))
        bool = ((OnCreateOptionsMenuListener)this.mActivity).onCreateOptionsMenu(paramMenu);
    }
  }

  protected final boolean callbackOptionsItemSelected(com.actionbarsherlock.view.MenuItem paramMenuItem)
  {
    Log.d("ActionBarSherlock", "[callbackOptionsItemSelected] item: " + paramMenuItem.getTitleCondensed());
    boolean bool2;
    if ((this.mActivity instanceof OnMenuItemSelectedListener))
      bool2 = ((OnMenuItemSelectedListener)this.mActivity).onMenuItemSelected(0, paramMenuItem);
    while (true)
    {
      Log.d("ActionBarSherlock", "[callbackOptionsItemSelected] returning " + bool2);
      return bool2;
      boolean bool1 = this.mActivity instanceof OnOptionsItemSelectedListener;
      bool2 = false;
      if (bool1)
        bool2 = ((OnOptionsItemSelectedListener)this.mActivity).onOptionsItemSelected(paramMenuItem);
    }
  }

  protected final boolean callbackPrepareOptionsMenu(com.actionbarsherlock.view.Menu paramMenu)
  {
    Log.d("ActionBarSherlock", "[callbackPrepareOptionsMenu] menu: " + paramMenu);
    boolean bool = true;
    if ((this.mActivity instanceof OnPreparePanelListener))
      bool = ((OnPreparePanelListener)this.mActivity).onPreparePanel(0, null, paramMenu);
    while (true)
    {
      Log.d("ActionBarSherlock", "[callbackPrepareOptionsMenu] returning " + bool);
      return bool;
      if ((this.mActivity instanceof OnPrepareOptionsMenuListener))
        bool = ((OnPrepareOptionsMenuListener)this.mActivity).onPrepareOptionsMenu(paramMenu);
    }
  }

  public boolean dispatchCloseOptionsMenu()
  {
    return false;
  }

  public void dispatchConfigurationChanged(Configuration paramConfiguration)
  {
  }

  public abstract boolean dispatchCreateOptionsMenu(android.view.Menu paramMenu);

  public void dispatchDestroy()
  {
  }

  public abstract void dispatchInvalidateOptionsMenu();

  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent)
  {
    return false;
  }

  public boolean dispatchMenuOpened(int paramInt, android.view.Menu paramMenu)
  {
    return false;
  }

  public boolean dispatchOpenOptionsMenu()
  {
    return false;
  }

  public abstract boolean dispatchOptionsItemSelected(android.view.MenuItem paramMenuItem);

  public void dispatchPanelClosed(int paramInt, android.view.Menu paramMenu)
  {
  }

  public void dispatchPause()
  {
  }

  public void dispatchPostCreate(Bundle paramBundle)
  {
  }

  public void dispatchPostResume()
  {
  }

  public abstract boolean dispatchPrepareOptionsMenu(android.view.Menu paramMenu);

  public void dispatchRestoreInstanceState(Bundle paramBundle)
  {
  }

  public void dispatchSaveInstanceState(Bundle paramBundle)
  {
  }

  public void dispatchStop()
  {
  }

  public void dispatchTitleChanged(CharSequence paramCharSequence, int paramInt)
  {
  }

  public void ensureActionBar()
  {
  }

  public abstract ActionBar getActionBar();

  public MenuInflater getMenuInflater()
  {
    Log.d("ActionBarSherlock", "[getMenuInflater]");
    if (this.mMenuInflater == null)
      if (getActionBar() == null)
        break label47;
    label47: for (this.mMenuInflater = new MenuInflater(getThemedContext(), this.mActivity); ; this.mMenuInflater = new MenuInflater(this.mActivity))
      return this.mMenuInflater;
  }

  protected abstract Context getThemedContext();

  public abstract boolean hasFeature(int paramInt);

  public abstract boolean requestFeature(int paramInt);

  public abstract void setContentView(int paramInt);

  public void setContentView(View paramView)
  {
    Log.d("ActionBarSherlock", "[setContentView] view: " + paramView);
    setContentView(paramView, new ViewGroup.LayoutParams(-1, -1));
  }

  public abstract void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams);

  public abstract void setProgress(int paramInt);

  public abstract void setProgressBarIndeterminate(boolean paramBoolean);

  public abstract void setProgressBarIndeterminateVisibility(boolean paramBoolean);

  public abstract void setProgressBarVisibility(boolean paramBoolean);

  public abstract void setSecondaryProgress(int paramInt);

  public void setTitle(int paramInt)
  {
    Log.d("ActionBarSherlock", "[setTitle] resId: " + paramInt);
    setTitle(this.mActivity.getString(paramInt));
  }

  public abstract void setTitle(CharSequence paramCharSequence);

  public abstract void setUiOptions(int paramInt);

  public abstract void setUiOptions(int paramInt1, int paramInt2);

  public abstract ActionMode startActionMode(ActionMode.Callback paramCallback);

  @Retention(RetentionPolicy.RUNTIME)
  @Target({java.lang.annotation.ElementType.TYPE})
  public static @interface Implementation
  {
    public static final int DEFAULT_API = -1;
    public static final int DEFAULT_DPI = -1;

    public abstract int api();

    public abstract int dpi();
  }

  public static abstract interface OnActionModeFinishedListener
  {
    public abstract void onActionModeFinished(ActionMode paramActionMode);
  }

  public static abstract interface OnActionModeStartedListener
  {
    public abstract void onActionModeStarted(ActionMode paramActionMode);
  }

  public static abstract interface OnCreateOptionsMenuListener
  {
    public abstract boolean onCreateOptionsMenu(com.actionbarsherlock.view.Menu paramMenu);
  }

  public static abstract interface OnCreatePanelMenuListener
  {
    public abstract boolean onCreatePanelMenu(int paramInt, com.actionbarsherlock.view.Menu paramMenu);
  }

  public static abstract interface OnMenuItemSelectedListener
  {
    public abstract boolean onMenuItemSelected(int paramInt, com.actionbarsherlock.view.MenuItem paramMenuItem);
  }

  public static abstract interface OnOptionsItemSelectedListener
  {
    public abstract boolean onOptionsItemSelected(com.actionbarsherlock.view.MenuItem paramMenuItem);
  }

  public static abstract interface OnPrepareOptionsMenuListener
  {
    public abstract boolean onPrepareOptionsMenu(com.actionbarsherlock.view.Menu paramMenu);
  }

  public static abstract interface OnPreparePanelListener
  {
    public abstract boolean onPreparePanel(int paramInt, View paramView, com.actionbarsherlock.view.Menu paramMenu);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.actionbarsherlock.ActionBarSherlock
 * JD-Core Version:    0.6.2
 */