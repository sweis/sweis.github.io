package com.android.mms.exif;

import java.io.InputStream;
import java.nio.ByteBuffer;

class ByteBufferInputStream extends InputStream
{
  private final ByteBuffer mBuf;

  public ByteBufferInputStream(ByteBuffer paramByteBuffer)
  {
    this.mBuf = paramByteBuffer;
  }

  public int read()
  {
    if (!this.mBuf.hasRemaining())
      return -1;
    return 0xFF & this.mBuf.get();
  }

  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if (!this.mBuf.hasRemaining())
      return -1;
    int i = Math.min(paramInt2, this.mBuf.remaining());
    this.mBuf.get(paramArrayOfByte, paramInt1, i);
    return i;
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.android.mms.exif.ByteBufferInputStream
 * JD-Core Version:    0.6.2
 */