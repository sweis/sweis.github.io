package com.android.mms.exif;

import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.util.SparseIntArray;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

public class ExifInterface
{
  private static final String DATETIME_FORMAT_STR = "yyyy:MM:dd kk:mm:ss";
  public static final ByteOrder DEFAULT_BYTE_ORDER = ByteOrder.BIG_ENDIAN;
  public static final int DEFINITION_NULL = 0;
  private static final String GPS_DATE_FORMAT_STR = "yyyy:MM:dd";
  public static final int IFD_NULL = -1;
  private static final String NULL_ARGUMENT_STRING = "Argument is null";
  public static final int TAG_APERTURE_VALUE = 0;
  public static final int TAG_ARTIST = 0;
  public static final int TAG_BITS_PER_SAMPLE = 0;
  public static final int TAG_BRIGHTNESS_VALUE = 0;
  public static final int TAG_CFA_PATTERN = 0;
  public static final int TAG_COLOR_SPACE = 0;
  public static final int TAG_COMPONENTS_CONFIGURATION = 0;
  public static final int TAG_COMPRESSED_BITS_PER_PIXEL = 0;
  public static final int TAG_COMPRESSION = 0;
  public static final int TAG_CONTRAST = 0;
  public static final int TAG_COPYRIGHT = 0;
  public static final int TAG_CUSTOM_RENDERED = 0;
  public static final int TAG_DATE_TIME = 0;
  public static final int TAG_DATE_TIME_DIGITIZED = 0;
  public static final int TAG_DATE_TIME_ORIGINAL = 0;
  public static final int TAG_DEVICE_SETTING_DESCRIPTION = 0;
  public static final int TAG_DIGITAL_ZOOM_RATIO = 0;
  public static final int TAG_EXIF_IFD = 0;
  public static final int TAG_EXIF_VERSION = 0;
  public static final int TAG_EXPOSURE_BIAS_VALUE = 0;
  public static final int TAG_EXPOSURE_INDEX = 0;
  public static final int TAG_EXPOSURE_MODE = 0;
  public static final int TAG_EXPOSURE_PROGRAM = 0;
  public static final int TAG_EXPOSURE_TIME = 0;
  public static final int TAG_FILE_SOURCE = 0;
  public static final int TAG_FLASH = 0;
  public static final int TAG_FLASHPIX_VERSION = 0;
  public static final int TAG_FLASH_ENERGY = 0;
  public static final int TAG_FOCAL_LENGTH = 0;
  public static final int TAG_FOCAL_LENGTH_IN_35_MM_FILE = 0;
  public static final int TAG_FOCAL_PLANE_RESOLUTION_UNIT = 0;
  public static final int TAG_FOCAL_PLANE_X_RESOLUTION = 0;
  public static final int TAG_FOCAL_PLANE_Y_RESOLUTION = 0;
  public static final int TAG_F_NUMBER = 0;
  public static final int TAG_GAIN_CONTROL = 0;
  public static final int TAG_GPS_ALTITUDE = 0;
  public static final int TAG_GPS_ALTITUDE_REF = 0;
  public static final int TAG_GPS_AREA_INFORMATION = 0;
  public static final int TAG_GPS_DATE_STAMP = 0;
  public static final int TAG_GPS_DEST_BEARING = 0;
  public static final int TAG_GPS_DEST_BEARING_REF = 0;
  public static final int TAG_GPS_DEST_DISTANCE = 0;
  public static final int TAG_GPS_DEST_DISTANCE_REF = 0;
  public static final int TAG_GPS_DEST_LATITUDE = 0;
  public static final int TAG_GPS_DEST_LATITUDE_REF = 0;
  public static final int TAG_GPS_DEST_LONGITUDE = 0;
  public static final int TAG_GPS_DEST_LONGITUDE_REF = 0;
  public static final int TAG_GPS_DIFFERENTIAL = 0;
  public static final int TAG_GPS_DOP = 0;
  public static final int TAG_GPS_IFD = 0;
  public static final int TAG_GPS_IMG_DIRECTION = 0;
  public static final int TAG_GPS_IMG_DIRECTION_REF = 0;
  public static final int TAG_GPS_LATITUDE = 0;
  public static final int TAG_GPS_LATITUDE_REF = 0;
  public static final int TAG_GPS_LONGITUDE = 0;
  public static final int TAG_GPS_LONGITUDE_REF = 0;
  public static final int TAG_GPS_MAP_DATUM = 0;
  public static final int TAG_GPS_MEASURE_MODE = 0;
  public static final int TAG_GPS_PROCESSING_METHOD = 0;
  public static final int TAG_GPS_SATTELLITES = 0;
  public static final int TAG_GPS_SPEED = 0;
  public static final int TAG_GPS_SPEED_REF = 0;
  public static final int TAG_GPS_STATUS = 0;
  public static final int TAG_GPS_TIME_STAMP = 0;
  public static final int TAG_GPS_TRACK = 0;
  public static final int TAG_GPS_TRACK_REF = 0;
  public static final int TAG_GPS_VERSION_ID = 0;
  public static final int TAG_IMAGE_DESCRIPTION = 0;
  public static final int TAG_IMAGE_LENGTH = 0;
  public static final int TAG_IMAGE_UNIQUE_ID = 0;
  public static final int TAG_IMAGE_WIDTH = 0;
  public static final int TAG_INTEROPERABILITY_IFD = 0;
  public static final int TAG_INTEROPERABILITY_INDEX = 0;
  public static final int TAG_ISO_SPEED_RATINGS = 0;
  public static final int TAG_JPEG_INTERCHANGE_FORMAT = 0;
  public static final int TAG_JPEG_INTERCHANGE_FORMAT_LENGTH = 0;
  public static final int TAG_LIGHT_SOURCE = 0;
  public static final int TAG_MAKE = 0;
  public static final int TAG_MAKER_NOTE = 0;
  public static final int TAG_MAX_APERTURE_VALUE = 0;
  public static final int TAG_METERING_MODE = 0;
  public static final int TAG_MODEL = 0;
  public static final int TAG_NULL = -1;
  public static final int TAG_OECF;
  public static final int TAG_ORIENTATION;
  public static final int TAG_PHOTOMETRIC_INTERPRETATION;
  public static final int TAG_PIXEL_X_DIMENSION;
  public static final int TAG_PIXEL_Y_DIMENSION;
  public static final int TAG_PLANAR_CONFIGURATION;
  public static final int TAG_PRIMARY_CHROMATICITIES;
  public static final int TAG_REFERENCE_BLACK_WHITE;
  public static final int TAG_RELATED_SOUND_FILE;
  public static final int TAG_RESOLUTION_UNIT;
  public static final int TAG_ROWS_PER_STRIP;
  public static final int TAG_SAMPLES_PER_PIXEL;
  public static final int TAG_SATURATION;
  public static final int TAG_SCENE_CAPTURE_TYPE;
  public static final int TAG_SCENE_TYPE;
  public static final int TAG_SENSING_METHOD;
  public static final int TAG_SHARPNESS;
  public static final int TAG_SHUTTER_SPEED_VALUE;
  public static final int TAG_SOFTWARE;
  public static final int TAG_SPATIAL_FREQUENCY_RESPONSE;
  public static final int TAG_SPECTRAL_SENSITIVITY;
  public static final int TAG_STRIP_BYTE_COUNTS;
  public static final int TAG_STRIP_OFFSETS;
  public static final int TAG_SUBJECT_AREA;
  public static final int TAG_SUBJECT_DISTANCE;
  public static final int TAG_SUBJECT_DISTANCE_RANGE;
  public static final int TAG_SUBJECT_LOCATION;
  public static final int TAG_SUB_SEC_TIME;
  public static final int TAG_SUB_SEC_TIME_DIGITIZED;
  public static final int TAG_SUB_SEC_TIME_ORIGINAL;
  public static final int TAG_TRANSFER_FUNCTION;
  public static final int TAG_USER_COMMENT;
  public static final int TAG_WHITE_BALANCE;
  public static final int TAG_WHITE_POINT;
  public static final int TAG_X_RESOLUTION;
  public static final int TAG_Y_CB_CR_COEFFICIENTS;
  public static final int TAG_Y_CB_CR_POSITIONING;
  public static final int TAG_Y_CB_CR_SUB_SAMPLING;
  public static final int TAG_Y_RESOLUTION;
  protected static HashSet<Short> sBannedDefines;
  private static HashSet<Short> sOffsetTags;
  private ExifData mData = new ExifData(DEFAULT_BYTE_ORDER);
  private final DateFormat mDateTimeStampFormat = new SimpleDateFormat("yyyy:MM:dd kk:mm:ss");
  private final DateFormat mGPSDateStampFormat = new SimpleDateFormat("yyyy:MM:dd");
  private final Calendar mGPSTimeStampCalendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
  private SparseIntArray mTagInfo = null;

  static
  {
    TAG_IMAGE_LENGTH = defineTag(0, (short)257);
    TAG_BITS_PER_SAMPLE = defineTag(0, (short)258);
    TAG_COMPRESSION = defineTag(0, (short)259);
    TAG_PHOTOMETRIC_INTERPRETATION = defineTag(0, (short)262);
    TAG_IMAGE_DESCRIPTION = defineTag(0, (short)270);
    TAG_MAKE = defineTag(0, (short)271);
    TAG_MODEL = defineTag(0, (short)272);
    TAG_STRIP_OFFSETS = defineTag(0, (short)273);
    TAG_ORIENTATION = defineTag(0, (short)274);
    TAG_SAMPLES_PER_PIXEL = defineTag(0, (short)277);
    TAG_ROWS_PER_STRIP = defineTag(0, (short)278);
    TAG_STRIP_BYTE_COUNTS = defineTag(0, (short)279);
    TAG_X_RESOLUTION = defineTag(0, (short)282);
    TAG_Y_RESOLUTION = defineTag(0, (short)283);
    TAG_PLANAR_CONFIGURATION = defineTag(0, (short)284);
    TAG_RESOLUTION_UNIT = defineTag(0, (short)296);
    TAG_TRANSFER_FUNCTION = defineTag(0, (short)301);
    TAG_SOFTWARE = defineTag(0, (short)305);
    TAG_DATE_TIME = defineTag(0, (short)306);
    TAG_ARTIST = defineTag(0, (short)315);
    TAG_WHITE_POINT = defineTag(0, (short)318);
    TAG_PRIMARY_CHROMATICITIES = defineTag(0, (short)319);
    TAG_Y_CB_CR_COEFFICIENTS = defineTag(0, (short)529);
    TAG_Y_CB_CR_SUB_SAMPLING = defineTag(0, (short)530);
    TAG_Y_CB_CR_POSITIONING = defineTag(0, (short)531);
    TAG_REFERENCE_BLACK_WHITE = defineTag(0, (short)532);
    TAG_COPYRIGHT = defineTag(0, (short)-32104);
    TAG_EXIF_IFD = defineTag(0, (short)-30871);
    TAG_GPS_IFD = defineTag(0, (short)-30683);
    TAG_JPEG_INTERCHANGE_FORMAT = defineTag(1, (short)513);
    TAG_JPEG_INTERCHANGE_FORMAT_LENGTH = defineTag(1, (short)514);
    TAG_EXPOSURE_TIME = defineTag(2, (short)-32102);
    TAG_F_NUMBER = defineTag(2, (short)-32099);
    TAG_EXPOSURE_PROGRAM = defineTag(2, (short)-30686);
    TAG_SPECTRAL_SENSITIVITY = defineTag(2, (short)-30684);
    TAG_ISO_SPEED_RATINGS = defineTag(2, (short)-30681);
    TAG_OECF = defineTag(2, (short)-30680);
    TAG_EXIF_VERSION = defineTag(2, (short)-28672);
    TAG_DATE_TIME_ORIGINAL = defineTag(2, (short)-28669);
    TAG_DATE_TIME_DIGITIZED = defineTag(2, (short)-28668);
    TAG_COMPONENTS_CONFIGURATION = defineTag(2, (short)-28415);
    TAG_COMPRESSED_BITS_PER_PIXEL = defineTag(2, (short)-28414);
    TAG_SHUTTER_SPEED_VALUE = defineTag(2, (short)-28159);
    TAG_APERTURE_VALUE = defineTag(2, (short)-28158);
    TAG_BRIGHTNESS_VALUE = defineTag(2, (short)-28157);
    TAG_EXPOSURE_BIAS_VALUE = defineTag(2, (short)-28156);
    TAG_MAX_APERTURE_VALUE = defineTag(2, (short)-28155);
    TAG_SUBJECT_DISTANCE = defineTag(2, (short)-28154);
    TAG_METERING_MODE = defineTag(2, (short)-28153);
    TAG_LIGHT_SOURCE = defineTag(2, (short)-28152);
    TAG_FLASH = defineTag(2, (short)-28151);
    TAG_FOCAL_LENGTH = defineTag(2, (short)-28150);
    TAG_SUBJECT_AREA = defineTag(2, (short)-28140);
    TAG_MAKER_NOTE = defineTag(2, (short)-28036);
    TAG_USER_COMMENT = defineTag(2, (short)-28026);
    TAG_SUB_SEC_TIME = defineTag(2, (short)-28016);
    TAG_SUB_SEC_TIME_ORIGINAL = defineTag(2, (short)-28015);
    TAG_SUB_SEC_TIME_DIGITIZED = defineTag(2, (short)-28014);
    TAG_FLASHPIX_VERSION = defineTag(2, (short)-24576);
    TAG_COLOR_SPACE = defineTag(2, (short)-24575);
    TAG_PIXEL_X_DIMENSION = defineTag(2, (short)-24574);
    TAG_PIXEL_Y_DIMENSION = defineTag(2, (short)-24573);
    TAG_RELATED_SOUND_FILE = defineTag(2, (short)-24572);
    TAG_INTEROPERABILITY_IFD = defineTag(2, (short)-24571);
    TAG_FLASH_ENERGY = defineTag(2, (short)-24053);
    TAG_SPATIAL_FREQUENCY_RESPONSE = defineTag(2, (short)-24052);
    TAG_FOCAL_PLANE_X_RESOLUTION = defineTag(2, (short)-24050);
    TAG_FOCAL_PLANE_Y_RESOLUTION = defineTag(2, (short)-24049);
    TAG_FOCAL_PLANE_RESOLUTION_UNIT = defineTag(2, (short)-24048);
    TAG_SUBJECT_LOCATION = defineTag(2, (short)-24044);
    TAG_EXPOSURE_INDEX = defineTag(2, (short)-24043);
    TAG_SENSING_METHOD = defineTag(2, (short)-24041);
    TAG_FILE_SOURCE = defineTag(2, (short)-23808);
    TAG_SCENE_TYPE = defineTag(2, (short)-23807);
    TAG_CFA_PATTERN = defineTag(2, (short)-23806);
    TAG_CUSTOM_RENDERED = defineTag(2, (short)-23551);
    TAG_EXPOSURE_MODE = defineTag(2, (short)-23550);
    TAG_WHITE_BALANCE = defineTag(2, (short)-23549);
    TAG_DIGITAL_ZOOM_RATIO = defineTag(2, (short)-23548);
    TAG_FOCAL_LENGTH_IN_35_MM_FILE = defineTag(2, (short)-23547);
    TAG_SCENE_CAPTURE_TYPE = defineTag(2, (short)-23546);
    TAG_GAIN_CONTROL = defineTag(2, (short)-23545);
    TAG_CONTRAST = defineTag(2, (short)-23544);
    TAG_SATURATION = defineTag(2, (short)-23543);
    TAG_SHARPNESS = defineTag(2, (short)-23542);
    TAG_DEVICE_SETTING_DESCRIPTION = defineTag(2, (short)-23541);
    TAG_SUBJECT_DISTANCE_RANGE = defineTag(2, (short)-23540);
    TAG_IMAGE_UNIQUE_ID = defineTag(2, (short)-23520);
    TAG_GPS_VERSION_ID = defineTag(4, (short)0);
    TAG_GPS_LATITUDE_REF = defineTag(4, (short)1);
    TAG_GPS_LATITUDE = defineTag(4, (short)2);
    TAG_GPS_LONGITUDE_REF = defineTag(4, (short)3);
    TAG_GPS_LONGITUDE = defineTag(4, (short)4);
    TAG_GPS_ALTITUDE_REF = defineTag(4, (short)5);
    TAG_GPS_ALTITUDE = defineTag(4, (short)6);
    TAG_GPS_TIME_STAMP = defineTag(4, (short)7);
    TAG_GPS_SATTELLITES = defineTag(4, (short)8);
    TAG_GPS_STATUS = defineTag(4, (short)9);
    TAG_GPS_MEASURE_MODE = defineTag(4, (short)10);
    TAG_GPS_DOP = defineTag(4, (short)11);
    TAG_GPS_SPEED_REF = defineTag(4, (short)12);
    TAG_GPS_SPEED = defineTag(4, (short)13);
    TAG_GPS_TRACK_REF = defineTag(4, (short)14);
    TAG_GPS_TRACK = defineTag(4, (short)15);
    TAG_GPS_IMG_DIRECTION_REF = defineTag(4, (short)16);
    TAG_GPS_IMG_DIRECTION = defineTag(4, (short)17);
    TAG_GPS_MAP_DATUM = defineTag(4, (short)18);
    TAG_GPS_DEST_LATITUDE_REF = defineTag(4, (short)19);
    TAG_GPS_DEST_LATITUDE = defineTag(4, (short)20);
    TAG_GPS_DEST_LONGITUDE_REF = defineTag(4, (short)21);
    TAG_GPS_DEST_LONGITUDE = defineTag(4, (short)22);
    TAG_GPS_DEST_BEARING_REF = defineTag(4, (short)23);
    TAG_GPS_DEST_BEARING = defineTag(4, (short)24);
    TAG_GPS_DEST_DISTANCE_REF = defineTag(4, (short)25);
    TAG_GPS_DEST_DISTANCE = defineTag(4, (short)26);
    TAG_GPS_PROCESSING_METHOD = defineTag(4, (short)27);
    TAG_GPS_AREA_INFORMATION = defineTag(4, (short)28);
    TAG_GPS_DATE_STAMP = defineTag(4, (short)29);
    TAG_GPS_DIFFERENTIAL = defineTag(4, (short)30);
    TAG_INTEROPERABILITY_INDEX = defineTag(3, (short)1);
    sOffsetTags = new HashSet();
    sOffsetTags.add(Short.valueOf(getTrueTagKey(TAG_GPS_IFD)));
    sOffsetTags.add(Short.valueOf(getTrueTagKey(TAG_EXIF_IFD)));
    sOffsetTags.add(Short.valueOf(getTrueTagKey(TAG_JPEG_INTERCHANGE_FORMAT)));
    sOffsetTags.add(Short.valueOf(getTrueTagKey(TAG_INTEROPERABILITY_IFD)));
    sOffsetTags.add(Short.valueOf(getTrueTagKey(TAG_STRIP_OFFSETS)));
    sBannedDefines = new HashSet(sOffsetTags);
    sBannedDefines.add(Short.valueOf(getTrueTagKey(-1)));
    sBannedDefines.add(Short.valueOf(getTrueTagKey(TAG_JPEG_INTERCHANGE_FORMAT_LENGTH)));
    sBannedDefines.add(Short.valueOf(getTrueTagKey(TAG_STRIP_BYTE_COUNTS)));
  }

  public ExifInterface()
  {
    this.mGPSDateStampFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
  }

  protected static void closeSilently(Closeable paramCloseable)
  {
    if (paramCloseable != null);
    try
    {
      paramCloseable.close();
      return;
    }
    catch (Throwable localThrowable)
    {
    }
  }

  public static double convertLatOrLongToDouble(Rational[] paramArrayOfRational, String paramString)
  {
    try
    {
      double d1 = paramArrayOfRational[0].toDouble();
      double d2 = paramArrayOfRational[1].toDouble();
      double d3 = paramArrayOfRational[2].toDouble();
      double d4 = d1 + d2 / 60.0D + d3 / 3600.0D;
      if (!paramString.equals("S"))
      {
        boolean bool = paramString.equals("W");
        if (!bool);
      }
      else
      {
        d4 = -d4;
      }
      return d4;
    }
    catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException)
    {
    }
    throw new IllegalArgumentException();
  }

  public static int defineTag(int paramInt, short paramShort)
  {
    return 0xFFFF & paramShort | paramInt << 16;
  }

  private void doExifStreamIO(InputStream paramInputStream, OutputStream paramOutputStream)
    throws IOException
  {
    byte[] arrayOfByte = new byte[1024];
    for (int i = paramInputStream.read(arrayOfByte, 0, 1024); ; i = paramInputStream.read(arrayOfByte, 0, 1024))
    {
      if (i == -1)
        return;
      paramOutputStream.write(arrayOfByte, 0, i);
    }
  }

  protected static int getAllowedIfdFlagsFromInfo(int paramInt)
  {
    return paramInt >>> 24;
  }

  protected static int[] getAllowedIfdsFromInfo(int paramInt)
  {
    int i = getAllowedIfdFlagsFromInfo(paramInt);
    int[] arrayOfInt1 = IfdData.getIfds();
    ArrayList localArrayList = new ArrayList();
    int j = 0;
    int[] arrayOfInt2;
    if (j >= 5)
    {
      if (localArrayList.size() > 0)
        break label67;
      arrayOfInt2 = null;
    }
    while (true)
    {
      return arrayOfInt2;
      if ((0x1 & i >> j) == 1)
        localArrayList.add(Integer.valueOf(arrayOfInt1[j]));
      j++;
      break;
      label67: arrayOfInt2 = new int[localArrayList.size()];
      int k = 0;
      Iterator localIterator = localArrayList.iterator();
      while (localIterator.hasNext())
      {
        int m = ((Integer)localIterator.next()).intValue();
        int n = k + 1;
        arrayOfInt2[k] = m;
        k = n;
      }
    }
  }

  protected static int getComponentCountFromInfo(int paramInt)
  {
    return 0xFFFF & paramInt;
  }

  protected static int getFlagsFromAllowedIfds(int[] paramArrayOfInt)
  {
    if ((paramArrayOfInt == null) || (paramArrayOfInt.length == 0))
    {
      i = 0;
      return i;
    }
    int i = 0;
    int[] arrayOfInt = IfdData.getIfds();
    int j = 0;
    label21: int k;
    if (j < 5)
      k = paramArrayOfInt.length;
    label69: for (int m = 0; ; m++)
    {
      if (m >= k);
      while (true)
      {
        j++;
        break label21;
        break;
        int n = paramArrayOfInt[m];
        if (arrayOfInt[j] != n)
          break label69;
        i |= 1 << j;
      }
    }
  }

  public static short getOrientationValueForRotation(int paramInt)
  {
    int i = paramInt % 360;
    if (i < 0)
      i += 360;
    if (i < 90)
      return 1;
    if (i < 180)
      return 6;
    if (i < 270)
      return 3;
    return 8;
  }

  public static int getRotationForOrientationValue(short paramShort)
  {
    switch (paramShort)
    {
    case 1:
    case 2:
    case 4:
    case 5:
    case 7:
    default:
      return 0;
    case 6:
      return 90;
    case 3:
      return 180;
    case 8:
    }
    return 270;
  }

  public static int getTrueIfd(int paramInt)
  {
    return paramInt >>> 16;
  }

  public static short getTrueTagKey(int paramInt)
  {
    return (short)paramInt;
  }

  protected static short getTypeFromInfo(int paramInt)
  {
    return (short)(0xFF & paramInt >> 16);
  }

  private void initTagInfo()
  {
    int[] arrayOfInt = new int[2];
    arrayOfInt[1] = 1;
    int i = getFlagsFromAllowedIfds(arrayOfInt) << 24;
    this.mTagInfo.put(TAG_MAKE, 0x20000 | i);
    this.mTagInfo.put(TAG_IMAGE_WIDTH, 0x1 | (0x40000 | i));
    this.mTagInfo.put(TAG_IMAGE_LENGTH, 0x1 | (0x40000 | i));
    this.mTagInfo.put(TAG_BITS_PER_SAMPLE, 0x3 | (0x30000 | i));
    this.mTagInfo.put(TAG_COMPRESSION, 0x1 | (0x30000 | i));
    this.mTagInfo.put(TAG_PHOTOMETRIC_INTERPRETATION, 0x1 | (0x30000 | i));
    this.mTagInfo.put(TAG_ORIENTATION, 0x1 | (0x30000 | i));
    this.mTagInfo.put(TAG_SAMPLES_PER_PIXEL, 0x1 | (0x30000 | i));
    this.mTagInfo.put(TAG_PLANAR_CONFIGURATION, 0x1 | (0x30000 | i));
    this.mTagInfo.put(TAG_Y_CB_CR_SUB_SAMPLING, 0x2 | (0x30000 | i));
    this.mTagInfo.put(TAG_Y_CB_CR_POSITIONING, 0x1 | (0x30000 | i));
    this.mTagInfo.put(TAG_X_RESOLUTION, 0x1 | (0x50000 | i));
    this.mTagInfo.put(TAG_Y_RESOLUTION, 0x1 | (0x50000 | i));
    this.mTagInfo.put(TAG_RESOLUTION_UNIT, 0x1 | (0x30000 | i));
    this.mTagInfo.put(TAG_STRIP_OFFSETS, 0x40000 | i);
    this.mTagInfo.put(TAG_ROWS_PER_STRIP, 0x1 | (0x40000 | i));
    this.mTagInfo.put(TAG_STRIP_BYTE_COUNTS, 0x40000 | i);
    this.mTagInfo.put(TAG_TRANSFER_FUNCTION, 0x300 | (0x30000 | i));
    this.mTagInfo.put(TAG_WHITE_POINT, 0x2 | (0x50000 | i));
    this.mTagInfo.put(TAG_PRIMARY_CHROMATICITIES, 0x6 | (0x50000 | i));
    this.mTagInfo.put(TAG_Y_CB_CR_COEFFICIENTS, 0x3 | (0x50000 | i));
    this.mTagInfo.put(TAG_REFERENCE_BLACK_WHITE, 0x6 | (0x50000 | i));
    this.mTagInfo.put(TAG_DATE_TIME, 0x14 | (0x20000 | i));
    this.mTagInfo.put(TAG_IMAGE_DESCRIPTION, 0x20000 | i);
    this.mTagInfo.put(TAG_MAKE, 0x20000 | i);
    this.mTagInfo.put(TAG_MODEL, 0x20000 | i);
    this.mTagInfo.put(TAG_SOFTWARE, 0x20000 | i);
    this.mTagInfo.put(TAG_ARTIST, 0x20000 | i);
    this.mTagInfo.put(TAG_COPYRIGHT, 0x20000 | i);
    this.mTagInfo.put(TAG_EXIF_IFD, 0x1 | (0x40000 | i));
    this.mTagInfo.put(TAG_GPS_IFD, 0x1 | (0x40000 | i));
    int j = getFlagsFromAllowedIfds(new int[] { 1 }) << 24;
    this.mTagInfo.put(TAG_JPEG_INTERCHANGE_FORMAT, 0x1 | (0x40000 | j));
    this.mTagInfo.put(TAG_JPEG_INTERCHANGE_FORMAT_LENGTH, 0x1 | (0x40000 | j));
    int k = getFlagsFromAllowedIfds(new int[] { 2 }) << 24;
    this.mTagInfo.put(TAG_EXIF_VERSION, 0x4 | (0x70000 | k));
    this.mTagInfo.put(TAG_FLASHPIX_VERSION, 0x4 | (0x70000 | k));
    this.mTagInfo.put(TAG_COLOR_SPACE, 0x1 | (0x30000 | k));
    this.mTagInfo.put(TAG_COMPONENTS_CONFIGURATION, 0x4 | (0x70000 | k));
    this.mTagInfo.put(TAG_COMPRESSED_BITS_PER_PIXEL, 0x1 | (0x50000 | k));
    this.mTagInfo.put(TAG_PIXEL_X_DIMENSION, 0x1 | (0x40000 | k));
    this.mTagInfo.put(TAG_PIXEL_Y_DIMENSION, 0x1 | (0x40000 | k));
    this.mTagInfo.put(TAG_MAKER_NOTE, 0x70000 | k);
    this.mTagInfo.put(TAG_USER_COMMENT, 0x70000 | k);
    this.mTagInfo.put(TAG_RELATED_SOUND_FILE, 0xD | (0x20000 | k));
    this.mTagInfo.put(TAG_DATE_TIME_ORIGINAL, 0x14 | (0x20000 | k));
    this.mTagInfo.put(TAG_DATE_TIME_DIGITIZED, 0x14 | (0x20000 | k));
    this.mTagInfo.put(TAG_SUB_SEC_TIME, 0x20000 | k);
    this.mTagInfo.put(TAG_SUB_SEC_TIME_ORIGINAL, 0x20000 | k);
    this.mTagInfo.put(TAG_SUB_SEC_TIME_DIGITIZED, 0x20000 | k);
    this.mTagInfo.put(TAG_IMAGE_UNIQUE_ID, 0x21 | (0x20000 | k));
    this.mTagInfo.put(TAG_EXPOSURE_TIME, 0x1 | (0x50000 | k));
    this.mTagInfo.put(TAG_F_NUMBER, 0x1 | (0x50000 | k));
    this.mTagInfo.put(TAG_EXPOSURE_PROGRAM, 0x1 | (0x30000 | k));
    this.mTagInfo.put(TAG_SPECTRAL_SENSITIVITY, 0x20000 | k);
    this.mTagInfo.put(TAG_ISO_SPEED_RATINGS, 0x30000 | k);
    this.mTagInfo.put(TAG_OECF, 0x70000 | k);
    this.mTagInfo.put(TAG_SHUTTER_SPEED_VALUE, 0x1 | (0xA0000 | k));
    this.mTagInfo.put(TAG_APERTURE_VALUE, 0x1 | (0x50000 | k));
    this.mTagInfo.put(TAG_BRIGHTNESS_VALUE, 0x1 | (0xA0000 | k));
    this.mTagInfo.put(TAG_EXPOSURE_BIAS_VALUE, 0x1 | (0xA0000 | k));
    this.mTagInfo.put(TAG_MAX_APERTURE_VALUE, 0x1 | (0x50000 | k));
    this.mTagInfo.put(TAG_SUBJECT_DISTANCE, 0x1 | (0x50000 | k));
    this.mTagInfo.put(TAG_METERING_MODE, 0x1 | (0x30000 | k));
    this.mTagInfo.put(TAG_LIGHT_SOURCE, 0x1 | (0x30000 | k));
    this.mTagInfo.put(TAG_FLASH, 0x1 | (0x30000 | k));
    this.mTagInfo.put(TAG_FOCAL_LENGTH, 0x1 | (0x50000 | k));
    this.mTagInfo.put(TAG_SUBJECT_AREA, 0x30000 | k);
    this.mTagInfo.put(TAG_FLASH_ENERGY, 0x1 | (0x50000 | k));
    this.mTagInfo.put(TAG_SPATIAL_FREQUENCY_RESPONSE, 0x70000 | k);
    this.mTagInfo.put(TAG_FOCAL_PLANE_X_RESOLUTION, 0x1 | (0x50000 | k));
    this.mTagInfo.put(TAG_FOCAL_PLANE_Y_RESOLUTION, 0x1 | (0x50000 | k));
    this.mTagInfo.put(TAG_FOCAL_PLANE_RESOLUTION_UNIT, 0x1 | (0x30000 | k));
    this.mTagInfo.put(TAG_SUBJECT_LOCATION, 0x2 | (0x30000 | k));
    this.mTagInfo.put(TAG_EXPOSURE_INDEX, 0x1 | (0x50000 | k));
    this.mTagInfo.put(TAG_SENSING_METHOD, 0x1 | (0x30000 | k));
    this.mTagInfo.put(TAG_FILE_SOURCE, 0x1 | (0x70000 | k));
    this.mTagInfo.put(TAG_SCENE_TYPE, 0x1 | (0x70000 | k));
    this.mTagInfo.put(TAG_CFA_PATTERN, 0x70000 | k);
    this.mTagInfo.put(TAG_CUSTOM_RENDERED, 0x1 | (0x30000 | k));
    this.mTagInfo.put(TAG_EXPOSURE_MODE, 0x1 | (0x30000 | k));
    this.mTagInfo.put(TAG_WHITE_BALANCE, 0x1 | (0x30000 | k));
    this.mTagInfo.put(TAG_DIGITAL_ZOOM_RATIO, 0x1 | (0x50000 | k));
    this.mTagInfo.put(TAG_FOCAL_LENGTH_IN_35_MM_FILE, 0x1 | (0x30000 | k));
    this.mTagInfo.put(TAG_SCENE_CAPTURE_TYPE, 0x1 | (0x30000 | k));
    this.mTagInfo.put(TAG_GAIN_CONTROL, 0x1 | (0x50000 | k));
    this.mTagInfo.put(TAG_CONTRAST, 0x1 | (0x30000 | k));
    this.mTagInfo.put(TAG_SATURATION, 0x1 | (0x30000 | k));
    this.mTagInfo.put(TAG_SHARPNESS, 0x1 | (0x30000 | k));
    this.mTagInfo.put(TAG_DEVICE_SETTING_DESCRIPTION, 0x70000 | k);
    this.mTagInfo.put(TAG_SUBJECT_DISTANCE_RANGE, 0x1 | (0x30000 | k));
    this.mTagInfo.put(TAG_INTEROPERABILITY_IFD, 0x1 | (0x40000 | k));
    int m = getFlagsFromAllowedIfds(new int[] { 4 }) << 24;
    this.mTagInfo.put(TAG_GPS_VERSION_ID, 0x4 | (0x10000 | m));
    this.mTagInfo.put(TAG_GPS_LATITUDE_REF, 0x2 | (0x20000 | m));
    this.mTagInfo.put(TAG_GPS_LONGITUDE_REF, 0x2 | (0x20000 | m));
    this.mTagInfo.put(TAG_GPS_LATITUDE, 0x3 | (0xA0000 | m));
    this.mTagInfo.put(TAG_GPS_LONGITUDE, 0x3 | (0xA0000 | m));
    this.mTagInfo.put(TAG_GPS_ALTITUDE_REF, 0x1 | (0x10000 | m));
    this.mTagInfo.put(TAG_GPS_ALTITUDE, 0x1 | (0x50000 | m));
    this.mTagInfo.put(TAG_GPS_TIME_STAMP, 0x3 | (0x50000 | m));
    this.mTagInfo.put(TAG_GPS_SATTELLITES, 0x20000 | m);
    this.mTagInfo.put(TAG_GPS_STATUS, 0x2 | (0x20000 | m));
    this.mTagInfo.put(TAG_GPS_MEASURE_MODE, 0x2 | (0x20000 | m));
    this.mTagInfo.put(TAG_GPS_DOP, 0x1 | (0x50000 | m));
    this.mTagInfo.put(TAG_GPS_SPEED_REF, 0x2 | (0x20000 | m));
    this.mTagInfo.put(TAG_GPS_SPEED, 0x1 | (0x50000 | m));
    this.mTagInfo.put(TAG_GPS_TRACK_REF, 0x2 | (0x20000 | m));
    this.mTagInfo.put(TAG_GPS_TRACK, 0x1 | (0x50000 | m));
    this.mTagInfo.put(TAG_GPS_IMG_DIRECTION_REF, 0x2 | (0x20000 | m));
    this.mTagInfo.put(TAG_GPS_IMG_DIRECTION, 0x1 | (0x50000 | m));
    this.mTagInfo.put(TAG_GPS_MAP_DATUM, 0x20000 | m);
    this.mTagInfo.put(TAG_GPS_DEST_LATITUDE_REF, 0x2 | (0x20000 | m));
    this.mTagInfo.put(TAG_GPS_DEST_LATITUDE, 0x1 | (0x50000 | m));
    this.mTagInfo.put(TAG_GPS_DEST_BEARING_REF, 0x2 | (0x20000 | m));
    this.mTagInfo.put(TAG_GPS_DEST_BEARING, 0x1 | (0x50000 | m));
    this.mTagInfo.put(TAG_GPS_DEST_DISTANCE_REF, 0x2 | (0x20000 | m));
    this.mTagInfo.put(TAG_GPS_DEST_DISTANCE, 0x1 | (0x50000 | m));
    this.mTagInfo.put(TAG_GPS_PROCESSING_METHOD, 0x70000 | m);
    this.mTagInfo.put(TAG_GPS_AREA_INFORMATION, 0x70000 | m);
    this.mTagInfo.put(TAG_GPS_DATE_STAMP, 0xB | (0x20000 | m));
    this.mTagInfo.put(TAG_GPS_DIFFERENTIAL, 0xB | (0x30000 | m));
    int n = getFlagsFromAllowedIfds(new int[] { 3 }) << 24;
    this.mTagInfo.put(TAG_INTEROPERABILITY_INDEX, 0x20000 | n);
  }

  protected static boolean isIfdAllowed(int paramInt1, int paramInt2)
  {
    int i = 1;
    int[] arrayOfInt = IfdData.getIfds();
    int j = getAllowedIfdFlagsFromInfo(paramInt1);
    for (int k = 0; ; k++)
    {
      if (k >= arrayOfInt.length)
        i = 0;
      while ((paramInt2 == arrayOfInt[k]) && ((0x1 & j >> k) == i))
        return i;
    }
  }

  protected static boolean isOffsetTag(short paramShort)
  {
    return sOffsetTags.contains(Short.valueOf(paramShort));
  }

  private static Rational[] toExifLatLong(double paramDouble)
  {
    double d1 = Math.abs(paramDouble);
    int i = (int)d1;
    double d2 = 60.0D * (d1 - i);
    int j = (int)d2;
    int k = (int)(6000.0D * (d2 - j));
    Rational[] arrayOfRational = new Rational[3];
    arrayOfRational[0] = new Rational(i, 1L);
    arrayOfRational[1] = new Rational(j, 1L);
    arrayOfRational[2] = new Rational(k, 100L);
    return arrayOfRational;
  }

  public boolean addDateTimeStampTag(int paramInt, long paramLong, TimeZone paramTimeZone)
  {
    ExifTag localExifTag;
    if ((paramInt == TAG_DATE_TIME) || (paramInt == TAG_DATE_TIME_DIGITIZED) || (paramInt == TAG_DATE_TIME_ORIGINAL))
    {
      this.mDateTimeStampFormat.setTimeZone(paramTimeZone);
      localExifTag = buildTag(paramInt, this.mDateTimeStampFormat.format(Long.valueOf(paramLong)));
      if (localExifTag != null);
    }
    else
    {
      return false;
    }
    setTag(localExifTag);
    return true;
  }

  public boolean addGpsDateTimeStampTag(long paramLong)
  {
    ExifTag localExifTag1 = buildTag(TAG_GPS_DATE_STAMP, this.mGPSDateStampFormat.format(Long.valueOf(paramLong)));
    if (localExifTag1 == null);
    ExifTag localExifTag2;
    do
    {
      return false;
      setTag(localExifTag1);
      this.mGPSTimeStampCalendar.setTimeInMillis(paramLong);
      int i = TAG_GPS_TIME_STAMP;
      Rational[] arrayOfRational = new Rational[3];
      arrayOfRational[0] = new Rational(this.mGPSTimeStampCalendar.get(11), 1L);
      arrayOfRational[1] = new Rational(this.mGPSTimeStampCalendar.get(12), 1L);
      arrayOfRational[2] = new Rational(this.mGPSTimeStampCalendar.get(13), 1L);
      localExifTag2 = buildTag(i, arrayOfRational);
    }
    while (localExifTag2 == null);
    setTag(localExifTag2);
    return true;
  }

  public boolean addGpsTags(double paramDouble1, double paramDouble2)
  {
    ExifTag localExifTag1 = buildTag(TAG_GPS_LATITUDE, toExifLatLong(paramDouble1));
    ExifTag localExifTag2 = buildTag(TAG_GPS_LONGITUDE, toExifLatLong(paramDouble2));
    int i = TAG_GPS_LATITUDE_REF;
    String str1;
    ExifTag localExifTag3;
    int j;
    if (paramDouble1 >= 0.0D)
    {
      str1 = "N";
      localExifTag3 = buildTag(i, str1);
      j = TAG_GPS_LONGITUDE_REF;
      if (paramDouble2 < 0.0D)
        break label108;
    }
    ExifTag localExifTag4;
    label108: for (String str2 = "E"; ; str2 = "W")
    {
      localExifTag4 = buildTag(j, str2);
      if ((localExifTag1 != null) && (localExifTag2 != null) && (localExifTag3 != null) && (localExifTag4 != null))
        break label116;
      return false;
      str1 = "S";
      break;
    }
    label116: setTag(localExifTag1);
    setTag(localExifTag2);
    setTag(localExifTag3);
    setTag(localExifTag4);
    return true;
  }

  public ExifTag buildTag(int paramInt1, int paramInt2, Object paramObject)
  {
    int i = getTagInfo().get(paramInt1);
    ExifTag localExifTag;
    if ((i == 0) || (paramObject == null))
      localExifTag = null;
    do
    {
      return localExifTag;
      short s = getTypeFromInfo(i);
      int j = getComponentCountFromInfo(i);
      if (j != 0);
      for (boolean bool = true; !isIfdAllowed(i, paramInt2); bool = false)
        return null;
      localExifTag = new ExifTag(getTrueTagKey(paramInt1), s, j, paramInt2, bool);
    }
    while (localExifTag.setValue(paramObject));
    return null;
  }

  public ExifTag buildTag(int paramInt, Object paramObject)
  {
    return buildTag(paramInt, getTrueIfd(paramInt), paramObject);
  }

  protected ExifTag buildUninitializedTag(int paramInt)
  {
    int i = getTagInfo().get(paramInt);
    if (i == 0)
      return null;
    short s = getTypeFromInfo(i);
    int j = getComponentCountFromInfo(i);
    if (j != 0);
    for (boolean bool = true; ; bool = false)
    {
      int k = getTrueIfd(paramInt);
      return new ExifTag(getTrueTagKey(paramInt), s, j, k, bool);
    }
  }

  public void clearExif()
  {
    this.mData = new ExifData(DEFAULT_BYTE_ORDER);
  }

  public void deleteTag(int paramInt)
  {
    deleteTag(paramInt, getDefinedTagDefaultIfd(paramInt));
  }

  public void deleteTag(int paramInt1, int paramInt2)
  {
    this.mData.removeTag(getTrueTagKey(paramInt1), paramInt2);
  }

  public void forceRewriteExif(String paramString)
    throws FileNotFoundException, IOException
  {
    forceRewriteExif(paramString, getAllTags());
  }

  // ERROR //
  public void forceRewriteExif(String paramString, Collection<ExifTag> paramCollection)
    throws FileNotFoundException, IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: invokevirtual 706	com/android/mms/exif/ExifInterface:rewriteExif	(Ljava/lang/String;Ljava/util/Collection;)Z
    //   6: ifne +87 -> 93
    //   9: aload_0
    //   10: getfield 445	com/android/mms/exif/ExifInterface:mData	Lcom/android/mms/exif/ExifData;
    //   13: astore_3
    //   14: aload_0
    //   15: new 440	com/android/mms/exif/ExifData
    //   18: dup
    //   19: getstatic 437	com/android/mms/exif/ExifInterface:DEFAULT_BYTE_ORDER	Ljava/nio/ByteOrder;
    //   22: invokespecial 443	com/android/mms/exif/ExifData:<init>	(Ljava/nio/ByteOrder;)V
    //   25: putfield 445	com/android/mms/exif/ExifInterface:mData	Lcom/android/mms/exif/ExifData;
    //   28: aconst_null
    //   29: astore 4
    //   31: new 708	java/io/FileInputStream
    //   34: dup
    //   35: aload_1
    //   36: invokespecial 709	java/io/FileInputStream:<init>	(Ljava/lang/String;)V
    //   39: astore 5
    //   41: new 711	java/io/ByteArrayOutputStream
    //   44: dup
    //   45: invokespecial 712	java/io/ByteArrayOutputStream:<init>	()V
    //   48: astore 6
    //   50: aload_0
    //   51: aload 5
    //   53: aload 6
    //   55: invokespecial 714	com/android/mms/exif/ExifInterface:doExifStreamIO	(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    //   58: aload 6
    //   60: invokevirtual 718	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   63: astore 9
    //   65: aload_0
    //   66: aload 9
    //   68: invokevirtual 722	com/android/mms/exif/ExifInterface:readExif	([B)V
    //   71: aload_0
    //   72: aload_2
    //   73: invokevirtual 725	com/android/mms/exif/ExifInterface:setTags	(Ljava/util/Collection;)V
    //   76: aload_0
    //   77: aload 9
    //   79: aload_1
    //   80: invokevirtual 729	com/android/mms/exif/ExifInterface:writeExif	([BLjava/lang/String;)V
    //   83: aload 5
    //   85: invokevirtual 730	java/io/FileInputStream:close	()V
    //   88: aload_0
    //   89: aload_3
    //   90: putfield 445	com/android/mms/exif/ExifInterface:mData	Lcom/android/mms/exif/ExifData;
    //   93: return
    //   94: astore 7
    //   96: aload 4
    //   98: invokestatic 732	com/android/mms/exif/ExifInterface:closeSilently	(Ljava/io/Closeable;)V
    //   101: aload 7
    //   103: athrow
    //   104: astore 8
    //   106: aload 4
    //   108: invokevirtual 730	java/io/FileInputStream:close	()V
    //   111: aload_0
    //   112: aload_3
    //   113: putfield 445	com/android/mms/exif/ExifInterface:mData	Lcom/android/mms/exif/ExifData;
    //   116: aload 8
    //   118: athrow
    //   119: astore 8
    //   121: aload 5
    //   123: astore 4
    //   125: goto -19 -> 106
    //   128: astore 8
    //   130: aload 5
    //   132: astore 4
    //   134: goto -28 -> 106
    //   137: astore 7
    //   139: aload 5
    //   141: astore 4
    //   143: goto -47 -> 96
    //   146: astore 7
    //   148: aload 5
    //   150: astore 4
    //   152: goto -56 -> 96
    //
    // Exception table:
    //   from	to	target	type
    //   31	41	94	java/io/IOException
    //   31	41	104	finally
    //   96	104	104	finally
    //   41	50	119	finally
    //   50	83	128	finally
    //   41	50	137	java/io/IOException
    //   50	83	146	java/io/IOException
  }

  public int getActualTagCount(int paramInt1, int paramInt2)
  {
    ExifTag localExifTag = getTag(paramInt1, paramInt2);
    if (localExifTag == null)
      return 0;
    return localExifTag.getComponentCount();
  }

  public List<ExifTag> getAllTags()
  {
    return this.mData.getAllTags();
  }

  public int getDefinedTagCount(int paramInt)
  {
    int i = getTagInfo().get(paramInt);
    if (i == 0)
      return 0;
    return getComponentCountFromInfo(i);
  }

  public int getDefinedTagDefaultIfd(int paramInt)
  {
    if (getTagInfo().get(paramInt) == 0)
      return -1;
    return getTrueIfd(paramInt);
  }

  public short getDefinedTagType(int paramInt)
  {
    int i = getTagInfo().get(paramInt);
    if (i == 0)
      return -1;
    return getTypeFromInfo(i);
  }

  public OutputStream getExifWriterStream(OutputStream paramOutputStream)
  {
    if (paramOutputStream == null)
      throw new IllegalArgumentException("Argument is null");
    ExifOutputStream localExifOutputStream = new ExifOutputStream(paramOutputStream, this);
    localExifOutputStream.setExifData(this.mData);
    return localExifOutputStream;
  }

  public OutputStream getExifWriterStream(String paramString)
    throws FileNotFoundException
  {
    if (paramString == null)
      throw new IllegalArgumentException("Argument is null");
    try
    {
      FileOutputStream localFileOutputStream = new FileOutputStream(paramString);
      return getExifWriterStream(localFileOutputStream);
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      closeSilently(null);
      throw localFileNotFoundException;
    }
  }

  public double[] getLatLongAsDoubles()
  {
    Rational[] arrayOfRational1 = getTagRationalValues(TAG_GPS_LATITUDE);
    String str1 = getTagStringValue(TAG_GPS_LATITUDE_REF);
    Rational[] arrayOfRational2 = getTagRationalValues(TAG_GPS_LONGITUDE);
    String str2 = getTagStringValue(TAG_GPS_LONGITUDE_REF);
    if ((arrayOfRational1 == null) || (arrayOfRational2 == null) || (str1 == null) || (str2 == null) || (arrayOfRational1.length < 3) || (arrayOfRational2.length < 3))
      return null;
    double[] arrayOfDouble = new double[2];
    arrayOfDouble[0] = convertLatOrLongToDouble(arrayOfRational1, str1);
    arrayOfDouble[1] = convertLatOrLongToDouble(arrayOfRational2, str2);
    return arrayOfDouble;
  }

  public ExifTag getTag(int paramInt)
  {
    return getTag(paramInt, getDefinedTagDefaultIfd(paramInt));
  }

  public ExifTag getTag(int paramInt1, int paramInt2)
  {
    if (!ExifTag.isValidIfd(paramInt2))
      return null;
    return this.mData.getTag(getTrueTagKey(paramInt1), paramInt2);
  }

  public Byte getTagByteValue(int paramInt)
  {
    return getTagByteValue(paramInt, getDefinedTagDefaultIfd(paramInt));
  }

  public Byte getTagByteValue(int paramInt1, int paramInt2)
  {
    byte[] arrayOfByte = getTagByteValues(paramInt1, paramInt2);
    if ((arrayOfByte == null) || (arrayOfByte.length <= 0))
      return null;
    return new Byte(arrayOfByte[0]);
  }

  public byte[] getTagByteValues(int paramInt)
  {
    return getTagByteValues(paramInt, getDefinedTagDefaultIfd(paramInt));
  }

  public byte[] getTagByteValues(int paramInt1, int paramInt2)
  {
    ExifTag localExifTag = getTag(paramInt1, paramInt2);
    if (localExifTag == null)
      return null;
    return localExifTag.getValueAsBytes();
  }

  protected int getTagDefinition(short paramShort, int paramInt)
  {
    return getTagInfo().get(defineTag(paramInt, paramShort));
  }

  protected int getTagDefinitionForTag(ExifTag paramExifTag)
  {
    short s = paramExifTag.getDataType();
    int i = paramExifTag.getComponentCount();
    int j = paramExifTag.getIfd();
    return getTagDefinitionForTag(paramExifTag.getTagId(), s, i, j);
  }

  protected int getTagDefinitionForTag(short paramShort1, short paramShort2, int paramInt1, int paramInt2)
  {
    int[] arrayOfInt1 = getTagDefinitionsForTagId(paramShort1);
    int i;
    if (arrayOfInt1 == null)
      i = -1;
    while (true)
    {
      return i;
      SparseIntArray localSparseIntArray = getTagInfo();
      i = -1;
      int j = arrayOfInt1.length;
      label144: for (int k = 0; k < j; k++)
      {
        int m = arrayOfInt1[k];
        int n = localSparseIntArray.get(m);
        short s = getTypeFromInfo(n);
        int i1 = getComponentCountFromInfo(n);
        int[] arrayOfInt2 = getAllowedIfdsFromInfo(n);
        int i2 = arrayOfInt2.length;
        for (int i3 = 0; ; i3++)
        {
          int i4 = 0;
          if (i3 >= i2);
          while (true)
          {
            if ((i4 == 0) || (paramShort2 != s) || ((paramInt1 != i1) && (i1 != 0)))
              break label144;
            return m;
            if (arrayOfInt2[i3] != paramInt2)
              break;
            i4 = 1;
          }
        }
      }
    }
  }

  protected int[] getTagDefinitionsForTagId(short paramShort)
  {
    int[] arrayOfInt1 = IfdData.getIfds();
    int[] arrayOfInt2 = new int[arrayOfInt1.length];
    SparseIntArray localSparseIntArray = getTagInfo();
    int i = arrayOfInt1.length;
    int j = 0;
    int k = 0;
    int n;
    if (j >= i)
    {
      if (k == 0)
        return null;
    }
    else
    {
      int m = defineTag(arrayOfInt1[j], paramShort);
      if (localSparseIntArray.get(m) == 0)
        break label89;
      n = k + 1;
      arrayOfInt2[k] = m;
    }
    while (true)
    {
      j++;
      k = n;
      break;
      return Arrays.copyOfRange(arrayOfInt2, 0, k);
      label89: n = k;
    }
  }

  protected SparseIntArray getTagInfo()
  {
    if (this.mTagInfo == null)
    {
      this.mTagInfo = new SparseIntArray();
      initTagInfo();
    }
    return this.mTagInfo;
  }

  public Integer getTagIntValue(int paramInt)
  {
    return getTagIntValue(paramInt, getDefinedTagDefaultIfd(paramInt));
  }

  public Integer getTagIntValue(int paramInt1, int paramInt2)
  {
    int[] arrayOfInt = getTagIntValues(paramInt1, paramInt2);
    if ((arrayOfInt == null) || (arrayOfInt.length <= 0))
      return null;
    return new Integer(arrayOfInt[0]);
  }

  public int[] getTagIntValues(int paramInt)
  {
    return getTagIntValues(paramInt, getDefinedTagDefaultIfd(paramInt));
  }

  public int[] getTagIntValues(int paramInt1, int paramInt2)
  {
    ExifTag localExifTag = getTag(paramInt1, paramInt2);
    if (localExifTag == null)
      return null;
    return localExifTag.getValueAsInts();
  }

  public Long getTagLongValue(int paramInt)
  {
    return getTagLongValue(paramInt, getDefinedTagDefaultIfd(paramInt));
  }

  public Long getTagLongValue(int paramInt1, int paramInt2)
  {
    long[] arrayOfLong = getTagLongValues(paramInt1, paramInt2);
    if ((arrayOfLong == null) || (arrayOfLong.length <= 0))
      return null;
    return new Long(arrayOfLong[0]);
  }

  public long[] getTagLongValues(int paramInt)
  {
    return getTagLongValues(paramInt, getDefinedTagDefaultIfd(paramInt));
  }

  public long[] getTagLongValues(int paramInt1, int paramInt2)
  {
    ExifTag localExifTag = getTag(paramInt1, paramInt2);
    if (localExifTag == null)
      return null;
    return localExifTag.getValueAsLongs();
  }

  public Rational getTagRationalValue(int paramInt)
  {
    return getTagRationalValue(paramInt, getDefinedTagDefaultIfd(paramInt));
  }

  public Rational getTagRationalValue(int paramInt1, int paramInt2)
  {
    Rational[] arrayOfRational = getTagRationalValues(paramInt1, paramInt2);
    if ((arrayOfRational == null) || (arrayOfRational.length == 0))
      return null;
    return new Rational(arrayOfRational[0]);
  }

  public Rational[] getTagRationalValues(int paramInt)
  {
    return getTagRationalValues(paramInt, getDefinedTagDefaultIfd(paramInt));
  }

  public Rational[] getTagRationalValues(int paramInt1, int paramInt2)
  {
    ExifTag localExifTag = getTag(paramInt1, paramInt2);
    if (localExifTag == null)
      return null;
    return localExifTag.getValueAsRationals();
  }

  public String getTagStringValue(int paramInt)
  {
    return getTagStringValue(paramInt, getDefinedTagDefaultIfd(paramInt));
  }

  public String getTagStringValue(int paramInt1, int paramInt2)
  {
    ExifTag localExifTag = getTag(paramInt1, paramInt2);
    if (localExifTag == null)
      return null;
    return localExifTag.getValueAsString();
  }

  public Object getTagValue(int paramInt)
  {
    return getTagValue(paramInt, getDefinedTagDefaultIfd(paramInt));
  }

  public Object getTagValue(int paramInt1, int paramInt2)
  {
    ExifTag localExifTag = getTag(paramInt1, paramInt2);
    if (localExifTag == null)
      return null;
    return localExifTag.getValue();
  }

  public List<ExifTag> getTagsForIfdId(int paramInt)
  {
    return this.mData.getAllTagsForIfd(paramInt);
  }

  public List<ExifTag> getTagsForTagId(short paramShort)
  {
    return this.mData.getAllTagsForTagId(paramShort);
  }

  public byte[] getThumbnail()
  {
    return this.mData.getCompressedThumbnail();
  }

  public Bitmap getThumbnailBitmap()
  {
    if (this.mData.hasCompressedThumbnail())
    {
      byte[] arrayOfByte = this.mData.getCompressedThumbnail();
      return BitmapFactory.decodeByteArray(arrayOfByte, 0, arrayOfByte.length);
    }
    this.mData.hasUncompressedStrip();
    return null;
  }

  public byte[] getThumbnailBytes()
  {
    if (this.mData.hasCompressedThumbnail())
      return this.mData.getCompressedThumbnail();
    this.mData.hasUncompressedStrip();
    return null;
  }

  public String getUserComment()
  {
    return this.mData.getUserComment();
  }

  public boolean hasThumbnail()
  {
    return this.mData.hasCompressedThumbnail();
  }

  public boolean isTagCountDefined(int paramInt)
  {
    int i = getTagInfo().get(paramInt);
    if (i == 0);
    while (getComponentCountFromInfo(i) == 0)
      return false;
    return true;
  }

  public boolean isThumbnailCompressed()
  {
    return this.mData.hasCompressedThumbnail();
  }

  public void readExif(InputStream paramInputStream)
    throws IOException
  {
    if (paramInputStream == null)
      throw new IllegalArgumentException("Argument is null");
    try
    {
      ExifData localExifData = new ExifReader(this).read(paramInputStream);
      this.mData = localExifData;
      return;
    }
    catch (ExifInvalidFormatException localExifInvalidFormatException)
    {
      throw new IOException("Invalid exif format : " + localExifInvalidFormatException);
    }
  }

  // ERROR //
  public void readExif(String paramString)
    throws FileNotFoundException, IOException
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull +13 -> 14
    //   4: new 512	java/lang/IllegalArgumentException
    //   7: dup
    //   8: ldc 21
    //   10: invokespecial 747	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   13: athrow
    //   14: aconst_null
    //   15: astore_2
    //   16: new 951	java/io/BufferedInputStream
    //   19: dup
    //   20: new 708	java/io/FileInputStream
    //   23: dup
    //   24: aload_1
    //   25: invokespecial 709	java/io/FileInputStream:<init>	(Ljava/lang/String;)V
    //   28: invokespecial 953	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
    //   31: astore_3
    //   32: aload_0
    //   33: aload_3
    //   34: invokevirtual 955	com/android/mms/exif/ExifInterface:readExif	(Ljava/io/InputStream;)V
    //   37: aload_3
    //   38: invokevirtual 956	java/io/InputStream:close	()V
    //   41: return
    //   42: astore 4
    //   44: aload_2
    //   45: invokestatic 732	com/android/mms/exif/ExifInterface:closeSilently	(Ljava/io/Closeable;)V
    //   48: aload 4
    //   50: athrow
    //   51: astore 4
    //   53: aload_3
    //   54: astore_2
    //   55: goto -11 -> 44
    //
    // Exception table:
    //   from	to	target	type
    //   16	32	42	java/io/IOException
    //   32	37	51	java/io/IOException
  }

  public void readExif(byte[] paramArrayOfByte)
    throws IOException
  {
    readExif(new ByteArrayInputStream(paramArrayOfByte));
  }

  public void removeCompressedThumbnail()
  {
    this.mData.setCompressedThumbnail(null);
  }

  public void removeTagDefinition(int paramInt)
  {
    getTagInfo().delete(paramInt);
  }

  public void resetTagDefinitions()
  {
    this.mTagInfo = null;
  }

  // ERROR //
  public boolean rewriteExif(String paramString, Collection<ExifTag> paramCollection)
    throws FileNotFoundException, IOException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: new 971	java/io/File
    //   5: dup
    //   6: aload_1
    //   7: invokespecial 972	java/io/File:<init>	(Ljava/lang/String;)V
    //   10: astore 4
    //   12: new 951	java/io/BufferedInputStream
    //   15: dup
    //   16: new 708	java/io/FileInputStream
    //   19: dup
    //   20: aload 4
    //   22: invokespecial 975	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   25: invokespecial 953	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
    //   28: astore 5
    //   30: aload 5
    //   32: aload_0
    //   33: invokestatic 981	com/android/mms/exif/ExifParser:parse	(Ljava/io/InputStream;Lcom/android/mms/exif/ExifInterface;)Lcom/android/mms/exif/ExifParser;
    //   36: astore 10
    //   38: aload 10
    //   40: invokevirtual 984	com/android/mms/exif/ExifParser:getOffsetToExifEndFromSOF	()I
    //   43: i2l
    //   44: lstore 11
    //   46: aload 5
    //   48: invokevirtual 956	java/io/InputStream:close	()V
    //   51: aconst_null
    //   52: astore_3
    //   53: new 986	java/io/RandomAccessFile
    //   56: dup
    //   57: aload 4
    //   59: ldc_w 988
    //   62: invokespecial 991	java/io/RandomAccessFile:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   65: astore 13
    //   67: aload 13
    //   69: invokevirtual 995	java/io/RandomAccessFile:length	()J
    //   72: lload 11
    //   74: lcmp
    //   75: ifge +63 -> 138
    //   78: new 518	java/io/IOException
    //   81: dup
    //   82: ldc_w 997
    //   85: invokespecial 949	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   88: athrow
    //   89: astore 7
    //   91: aload 13
    //   93: astore 8
    //   95: aload 8
    //   97: invokestatic 732	com/android/mms/exif/ExifInterface:closeSilently	(Ljava/io/Closeable;)V
    //   100: aload 7
    //   102: athrow
    //   103: astore 6
    //   105: aload_3
    //   106: invokestatic 732	com/android/mms/exif/ExifInterface:closeSilently	(Ljava/io/Closeable;)V
    //   109: aload 6
    //   111: athrow
    //   112: astore 9
    //   114: new 518	java/io/IOException
    //   117: dup
    //   118: ldc_w 940
    //   121: aload 9
    //   123: invokespecial 1000	java/io/IOException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   126: athrow
    //   127: astore 7
    //   129: aload 5
    //   131: astore_3
    //   132: aconst_null
    //   133: astore 8
    //   135: goto -40 -> 95
    //   138: aload_0
    //   139: aload 13
    //   141: invokevirtual 1004	java/io/RandomAccessFile:getChannel	()Ljava/nio/channels/FileChannel;
    //   144: getstatic 1010	java/nio/channels/FileChannel$MapMode:READ_WRITE	Ljava/nio/channels/FileChannel$MapMode;
    //   147: lconst_0
    //   148: lload 11
    //   150: invokevirtual 1016	java/nio/channels/FileChannel:map	(Ljava/nio/channels/FileChannel$MapMode;JJ)Ljava/nio/MappedByteBuffer;
    //   153: aload_2
    //   154: invokevirtual 1019	com/android/mms/exif/ExifInterface:rewriteExif	(Ljava/nio/ByteBuffer;Ljava/util/Collection;)Z
    //   157: istore 14
    //   159: aconst_null
    //   160: invokestatic 732	com/android/mms/exif/ExifInterface:closeSilently	(Ljava/io/Closeable;)V
    //   163: aload 13
    //   165: invokevirtual 1020	java/io/RandomAccessFile:close	()V
    //   168: iload 14
    //   170: ireturn
    //   171: astore 6
    //   173: aload 5
    //   175: astore_3
    //   176: goto -71 -> 105
    //   179: astore 6
    //   181: aconst_null
    //   182: astore_3
    //   183: goto -78 -> 105
    //   186: astore 7
    //   188: aconst_null
    //   189: astore 8
    //   191: aconst_null
    //   192: astore_3
    //   193: goto -98 -> 95
    //
    // Exception table:
    //   from	to	target	type
    //   67	89	89	java/io/IOException
    //   138	159	89	java/io/IOException
    //   2	30	103	finally
    //   53	67	103	finally
    //   95	103	103	finally
    //   30	38	112	com/android/mms/exif/ExifInvalidFormatException
    //   30	38	127	java/io/IOException
    //   38	51	127	java/io/IOException
    //   114	127	127	java/io/IOException
    //   30	38	171	finally
    //   38	51	171	finally
    //   114	127	171	finally
    //   67	89	179	finally
    //   138	159	179	finally
    //   2	30	186	java/io/IOException
    //   53	67	186	java/io/IOException
  }

  public boolean rewriteExif(ByteBuffer paramByteBuffer, Collection<ExifTag> paramCollection)
    throws IOException
  {
    try
    {
      ExifModifier localExifModifier = new ExifModifier(paramByteBuffer, this);
      try
      {
        Iterator localIterator = paramCollection.iterator();
        while (true)
        {
          if (!localIterator.hasNext())
            return localExifModifier.commit();
          localExifModifier.modifyTag((ExifTag)localIterator.next());
        }
      }
      catch (ExifInvalidFormatException localExifInvalidFormatException1)
      {
      }
      label52: throw new IOException("Invalid exif format : " + localExifInvalidFormatException1);
    }
    catch (ExifInvalidFormatException localExifInvalidFormatException2)
    {
      break label52;
    }
  }

  public boolean setCompressedThumbnail(Bitmap paramBitmap)
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    if (!paramBitmap.compress(Bitmap.CompressFormat.JPEG, 90, localByteArrayOutputStream))
      return false;
    return setCompressedThumbnail(localByteArrayOutputStream.toByteArray());
  }

  public boolean setCompressedThumbnail(byte[] paramArrayOfByte)
  {
    this.mData.clearThumbnailAndStrips();
    this.mData.setCompressedThumbnail(paramArrayOfByte);
    return true;
  }

  public void setExif(Collection<ExifTag> paramCollection)
  {
    clearExif();
    setTags(paramCollection);
  }

  public ExifTag setTag(ExifTag paramExifTag)
  {
    return this.mData.addTag(paramExifTag);
  }

  public int setTagDefinition(short paramShort1, int paramInt, short paramShort2, short paramShort3, int[] paramArrayOfInt)
  {
    if (sBannedDefines.contains(Short.valueOf(paramShort1)))
      return -1;
    if ((ExifTag.isValidType(paramShort2)) && (ExifTag.isValidIfd(paramInt)))
    {
      int i = defineTag(paramInt, paramShort1);
      if (i == -1)
        return -1;
      int[] arrayOfInt = getTagDefinitionsForTagId(paramShort1);
      SparseIntArray localSparseIntArray = getTagInfo();
      int j = 0;
      int k = paramArrayOfInt.length;
      for (int m = 0; ; m++)
      {
        if (m >= k)
        {
          if (j != 0)
            break;
          return -1;
        }
        int n = paramArrayOfInt[m];
        if (paramInt == n)
          j = 1;
        if (!ExifTag.isValidIfd(n))
          return -1;
      }
      int i1 = getFlagsFromAllowedIfds(paramArrayOfInt);
      int i2;
      if (arrayOfInt != null)
        i2 = arrayOfInt.length;
      for (int i3 = 0; ; i3++)
      {
        if (i3 >= i2)
        {
          getTagInfo().put(i, paramShort3 | (i1 << 24 | paramShort2 << 16));
          return i;
        }
        if ((i1 & getAllowedIfdFlagsFromInfo(localSparseIntArray.get(arrayOfInt[i3]))) != 0)
          return -1;
      }
    }
    return -1;
  }

  public boolean setTagValue(int paramInt1, int paramInt2, Object paramObject)
  {
    ExifTag localExifTag = getTag(paramInt1, paramInt2);
    if (localExifTag == null)
      return false;
    return localExifTag.setValue(paramObject);
  }

  public boolean setTagValue(int paramInt, Object paramObject)
  {
    return setTagValue(paramInt, getDefinedTagDefaultIfd(paramInt), paramObject);
  }

  public void setTags(Collection<ExifTag> paramCollection)
  {
    Iterator localIterator = paramCollection.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return;
      setTag((ExifTag)localIterator.next());
    }
  }

  public void writeExif(Bitmap paramBitmap, OutputStream paramOutputStream)
    throws IOException
  {
    if ((paramBitmap == null) || (paramOutputStream == null))
      throw new IllegalArgumentException("Argument is null");
    OutputStream localOutputStream = getExifWriterStream(paramOutputStream);
    paramBitmap.compress(Bitmap.CompressFormat.JPEG, 90, localOutputStream);
    localOutputStream.flush();
  }

  public void writeExif(Bitmap paramBitmap, String paramString)
    throws FileNotFoundException, IOException
  {
    if ((paramBitmap == null) || (paramString == null))
      throw new IllegalArgumentException("Argument is null");
    OutputStream localOutputStream = null;
    try
    {
      localOutputStream = getExifWriterStream(paramString);
      paramBitmap.compress(Bitmap.CompressFormat.JPEG, 90, localOutputStream);
      localOutputStream.flush();
      localOutputStream.close();
      return;
    }
    catch (IOException localIOException)
    {
      closeSilently(localOutputStream);
      throw localIOException;
    }
  }

  public void writeExif(InputStream paramInputStream, OutputStream paramOutputStream)
    throws IOException
  {
    if ((paramInputStream == null) || (paramOutputStream == null))
      throw new IllegalArgumentException("Argument is null");
    OutputStream localOutputStream = getExifWriterStream(paramOutputStream);
    doExifStreamIO(paramInputStream, localOutputStream);
    localOutputStream.flush();
  }

  public void writeExif(InputStream paramInputStream, String paramString)
    throws FileNotFoundException, IOException
  {
    if ((paramInputStream == null) || (paramString == null))
      throw new IllegalArgumentException("Argument is null");
    OutputStream localOutputStream = null;
    try
    {
      localOutputStream = getExifWriterStream(paramString);
      doExifStreamIO(paramInputStream, localOutputStream);
      localOutputStream.flush();
      localOutputStream.close();
      return;
    }
    catch (IOException localIOException)
    {
      closeSilently(localOutputStream);
      throw localIOException;
    }
  }

  // ERROR //
  public void writeExif(String paramString1, String paramString2)
    throws FileNotFoundException, IOException
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnull +7 -> 8
    //   4: aload_2
    //   5: ifnonnull +13 -> 18
    //   8: new 512	java/lang/IllegalArgumentException
    //   11: dup
    //   12: ldc 21
    //   14: invokespecial 747	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   17: athrow
    //   18: aconst_null
    //   19: astore_3
    //   20: new 708	java/io/FileInputStream
    //   23: dup
    //   24: aload_1
    //   25: invokespecial 709	java/io/FileInputStream:<init>	(Ljava/lang/String;)V
    //   28: astore 4
    //   30: aload_0
    //   31: aload 4
    //   33: aload_2
    //   34: invokevirtual 1082	com/android/mms/exif/ExifInterface:writeExif	(Ljava/io/InputStream;Ljava/lang/String;)V
    //   37: aload 4
    //   39: invokevirtual 956	java/io/InputStream:close	()V
    //   42: return
    //   43: astore 5
    //   45: aload_3
    //   46: invokestatic 732	com/android/mms/exif/ExifInterface:closeSilently	(Ljava/io/Closeable;)V
    //   49: aload 5
    //   51: athrow
    //   52: astore 5
    //   54: aload 4
    //   56: astore_3
    //   57: goto -12 -> 45
    //
    // Exception table:
    //   from	to	target	type
    //   20	30	43	java/io/IOException
    //   30	37	52	java/io/IOException
  }

  public void writeExif(byte[] paramArrayOfByte, OutputStream paramOutputStream)
    throws IOException
  {
    if ((paramArrayOfByte == null) || (paramOutputStream == null))
      throw new IllegalArgumentException("Argument is null");
    OutputStream localOutputStream = getExifWriterStream(paramOutputStream);
    localOutputStream.write(paramArrayOfByte, 0, paramArrayOfByte.length);
    localOutputStream.flush();
  }

  public void writeExif(byte[] paramArrayOfByte, String paramString)
    throws FileNotFoundException, IOException
  {
    if ((paramArrayOfByte == null) || (paramString == null))
      throw new IllegalArgumentException("Argument is null");
    OutputStream localOutputStream = null;
    try
    {
      localOutputStream = getExifWriterStream(paramString);
      localOutputStream.write(paramArrayOfByte, 0, paramArrayOfByte.length);
      localOutputStream.flush();
      localOutputStream.close();
      return;
    }
    catch (IOException localIOException)
    {
      closeSilently(localOutputStream);
      throw localIOException;
    }
  }

  public static abstract interface ColorSpace
  {
    public static final short SRGB = 1;
    public static final short UNCALIBRATED = -1;
  }

  public static abstract interface ComponentsConfiguration
  {
    public static final short B = 6;
    public static final short CB = 2;
    public static final short CR = 3;
    public static final short G = 5;
    public static final short NOT_EXIST = 0;
    public static final short R = 4;
    public static final short Y = 1;
  }

  public static abstract interface Compression
  {
    public static final short JPEG = 6;
    public static final short UNCOMPRESSION = 1;
  }

  public static abstract interface Contrast
  {
    public static final short HARD = 2;
    public static final short NORMAL = 0;
    public static final short SOFT = 1;
  }

  public static abstract interface ExposureMode
  {
    public static final short AUTO_BRACKET = 2;
    public static final short AUTO_EXPOSURE = 0;
    public static final short MANUAL_EXPOSURE = 1;
  }

  public static abstract interface ExposureProgram
  {
    public static final short ACTION_PROGRAM = 6;
    public static final short APERTURE_PRIORITY = 3;
    public static final short CREATIVE_PROGRAM = 5;
    public static final short LANDSCAPE_MODE = 8;
    public static final short MANUAL = 1;
    public static final short NORMAL_PROGRAM = 2;
    public static final short NOT_DEFINED = 0;
    public static final short PROTRAIT_MODE = 7;
    public static final short SHUTTER_PRIORITY = 4;
  }

  public static abstract interface FileSource
  {
    public static final short DSC = 3;
  }

  public static abstract interface Flash
  {
    public static final short DID_NOT_FIRED = 0;
    public static final short FIRED = 1;
    public static final short FUNCTION_NO_FUNCTION = 32;
    public static final short FUNCTION_PRESENT = 0;
    public static final short MODE_AUTO_MODE = 24;
    public static final short MODE_COMPULSORY_FLASH_FIRING = 8;
    public static final short MODE_COMPULSORY_FLASH_SUPPRESSION = 16;
    public static final short MODE_UNKNOWN = 0;
    public static final short RED_EYE_REDUCTION_NO_OR_UNKNOWN = 0;
    public static final short RED_EYE_REDUCTION_SUPPORT = 64;
    public static final short RETURN_NO_STROBE_RETURN_DETECTION_FUNCTION = 0;
    public static final short RETURN_STROBE_RETURN_LIGHT_DETECTED = 6;
    public static final short RETURN_STROBE_RETURN_LIGHT_NOT_DETECTED = 4;
  }

  public static abstract interface GainControl
  {
    public static final short HIGH_DOWN = 4;
    public static final short HIGH_UP = 2;
    public static final short LOW_DOWN = 3;
    public static final short LOW_UP = 1;
    public static final short NONE;
  }

  public static abstract interface GpsAltitudeRef
  {
    public static final short SEA_LEVEL = 0;
    public static final short SEA_LEVEL_NEGATIVE = 1;
  }

  public static abstract interface GpsDifferential
  {
    public static final short DIFFERENTIAL_CORRECTION_APPLIED = 1;
    public static final short WITHOUT_DIFFERENTIAL_CORRECTION;
  }

  public static abstract interface GpsLatitudeRef
  {
    public static final String NORTH = "N";
    public static final String SOUTH = "S";
  }

  public static abstract interface GpsLongitudeRef
  {
    public static final String EAST = "E";
    public static final String WEST = "W";
  }

  public static abstract interface GpsMeasureMode
  {
    public static final String MODE_2_DIMENSIONAL = "2";
    public static final String MODE_3_DIMENSIONAL = "3";
  }

  public static abstract interface GpsSpeedRef
  {
    public static final String KILOMETERS = "K";
    public static final String KNOTS = "N";
    public static final String MILES = "M";
  }

  public static abstract interface GpsStatus
  {
    public static final String INTEROPERABILITY = "V";
    public static final String IN_PROGRESS = "A";
  }

  public static abstract interface GpsTrackRef
  {
    public static final String MAGNETIC_DIRECTION = "M";
    public static final String TRUE_DIRECTION = "T";
  }

  public static abstract interface LightSource
  {
    public static final short CLOUDY_WEATHER = 10;
    public static final short COOL_WHITE_FLUORESCENT = 14;
    public static final short D50 = 23;
    public static final short D55 = 20;
    public static final short D65 = 21;
    public static final short D75 = 22;
    public static final short DAYLIGHT = 1;
    public static final short DAYLIGHT_FLUORESCENT = 12;
    public static final short DAY_WHITE_FLUORESCENT = 13;
    public static final short FINE_WEATHER = 9;
    public static final short FLASH = 4;
    public static final short FLUORESCENT = 2;
    public static final short ISO_STUDIO_TUNGSTEN = 24;
    public static final short OTHER = 255;
    public static final short SHADE = 11;
    public static final short STANDARD_LIGHT_A = 17;
    public static final short STANDARD_LIGHT_B = 18;
    public static final short STANDARD_LIGHT_C = 19;
    public static final short TUNGSTEN = 3;
    public static final short UNKNOWN = 0;
    public static final short WHITE_FLUORESCENT = 15;
  }

  public static abstract interface MeteringMode
  {
    public static final short AVERAGE = 1;
    public static final short CENTER_WEIGHTED_AVERAGE = 2;
    public static final short MULTISPOT = 4;
    public static final short OTHER = 255;
    public static final short PARTAIL = 6;
    public static final short PATTERN = 5;
    public static final short SPOT = 3;
    public static final short UNKNOWN;
  }

  public static abstract interface Orientation
  {
    public static final short BOTTOM_LEFT = 3;
    public static final short BOTTOM_RIGHT = 4;
    public static final short LEFT_BOTTOM = 7;
    public static final short LEFT_TOP = 5;
    public static final short RIGHT_BOTTOM = 8;
    public static final short RIGHT_TOP = 6;
    public static final short TOP_LEFT = 1;
    public static final short TOP_RIGHT = 2;
  }

  public static abstract interface PhotometricInterpretation
  {
    public static final short RGB = 2;
    public static final short YCBCR = 6;
  }

  public static abstract interface PlanarConfiguration
  {
    public static final short CHUNKY = 1;
    public static final short PLANAR = 2;
  }

  public static abstract interface ResolutionUnit
  {
    public static final short CENTIMETERS = 3;
    public static final short INCHES = 2;
  }

  public static abstract interface Saturation
  {
    public static final short HIGH = 2;
    public static final short LOW = 1;
    public static final short NORMAL;
  }

  public static abstract interface SceneCapture
  {
    public static final short LANDSCAPE = 1;
    public static final short NIGHT_SCENE = 3;
    public static final short PROTRAIT = 2;
    public static final short STANDARD;
  }

  public static abstract interface SceneType
  {
    public static final short DIRECT_PHOTOGRAPHED = 1;
  }

  public static abstract interface SensingMethod
  {
    public static final short COLOR_SEQUENTIAL_AREA = 5;
    public static final short COLOR_SEQUENTIAL_LINEAR = 8;
    public static final short NOT_DEFINED = 1;
    public static final short ONE_CHIP_COLOR = 2;
    public static final short THREE_CHIP_COLOR = 4;
    public static final short TRILINEAR = 7;
    public static final short TWO_CHIP_COLOR = 3;
  }

  public static abstract interface Sharpness
  {
    public static final short HARD = 2;
    public static final short NORMAL = 0;
    public static final short SOFT = 1;
  }

  public static abstract interface SubjectDistance
  {
    public static final short CLOSE_VIEW = 2;
    public static final short DISTANT_VIEW = 3;
    public static final short MACRO = 1;
    public static final short UNKNOWN;
  }

  public static abstract interface WhiteBalance
  {
    public static final short AUTO = 0;
    public static final short MANUAL = 1;
  }

  public static abstract interface YCbCrPositioning
  {
    public static final short CENTERED = 1;
    public static final short CO_SITED = 2;
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.android.mms.exif.ExifInterface
 * JD-Core Version:    0.6.2
 */