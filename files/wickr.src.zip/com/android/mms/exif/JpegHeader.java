package com.android.mms.exif;

class JpegHeader
{
  public static final short APP0 = -32;
  public static final short APP1 = -31;
  public static final short DAC = -52;
  public static final short DHT = -60;
  public static final short EOI = -39;
  public static final short JPG = -56;
  public static final short SOF0 = -64;
  public static final short SOF15 = -49;
  public static final short SOI = -40;

  public static final boolean isSofMarker(short paramShort)
  {
    return (paramShort >= -64) && (paramShort <= -49) && (paramShort != -60) && (paramShort != -56) && (paramShort != -52);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.android.mms.exif.JpegHeader
 * JD-Core Version:    0.6.2
 */