package com.android.mms.exif;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Iterator;
import java.util.List;

class ExifModifier
{
  public static final boolean DEBUG = false;
  public static final String TAG = "ExifModifier";
  private final ByteBuffer mByteBuffer;
  private final ExifInterface mInterface;
  private int mOffsetBase;
  private final List<TagOffset> mTagOffsets;
  private final ExifData mTagToModified;

  // ERROR //
  protected ExifModifier(ByteBuffer paramByteBuffer, ExifInterface paramExifInterface)
    throws java.io.IOException, ExifInvalidFormatException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial 31	java/lang/Object:<init>	()V
    //   4: aload_0
    //   5: new 33	java/util/ArrayList
    //   8: dup
    //   9: invokespecial 34	java/util/ArrayList:<init>	()V
    //   12: putfield 36	com/android/mms/exif/ExifModifier:mTagOffsets	Ljava/util/List;
    //   15: aload_0
    //   16: aload_1
    //   17: putfield 38	com/android/mms/exif/ExifModifier:mByteBuffer	Ljava/nio/ByteBuffer;
    //   20: aload_0
    //   21: aload_1
    //   22: invokevirtual 44	java/nio/ByteBuffer:position	()I
    //   25: putfield 46	com/android/mms/exif/ExifModifier:mOffsetBase	I
    //   28: aload_0
    //   29: aload_2
    //   30: putfield 48	com/android/mms/exif/ExifModifier:mInterface	Lcom/android/mms/exif/ExifInterface;
    //   33: aconst_null
    //   34: astore_3
    //   35: new 50	com/android/mms/exif/ByteBufferInputStream
    //   38: dup
    //   39: aload_1
    //   40: invokespecial 53	com/android/mms/exif/ByteBufferInputStream:<init>	(Ljava/nio/ByteBuffer;)V
    //   43: astore 4
    //   45: aload 4
    //   47: aload_0
    //   48: getfield 48	com/android/mms/exif/ExifModifier:mInterface	Lcom/android/mms/exif/ExifInterface;
    //   51: invokestatic 59	com/android/mms/exif/ExifParser:parse	(Ljava/io/InputStream;Lcom/android/mms/exif/ExifInterface;)Lcom/android/mms/exif/ExifParser;
    //   54: astore 6
    //   56: aload_0
    //   57: new 61	com/android/mms/exif/ExifData
    //   60: dup
    //   61: aload 6
    //   63: invokevirtual 65	com/android/mms/exif/ExifParser:getByteOrder	()Ljava/nio/ByteOrder;
    //   66: invokespecial 68	com/android/mms/exif/ExifData:<init>	(Ljava/nio/ByteOrder;)V
    //   69: putfield 70	com/android/mms/exif/ExifModifier:mTagToModified	Lcom/android/mms/exif/ExifData;
    //   72: aload_0
    //   73: aload_0
    //   74: getfield 46	com/android/mms/exif/ExifModifier:mOffsetBase	I
    //   77: aload 6
    //   79: invokevirtual 73	com/android/mms/exif/ExifParser:getTiffStartPosition	()I
    //   82: iadd
    //   83: putfield 46	com/android/mms/exif/ExifModifier:mOffsetBase	I
    //   86: aload_0
    //   87: getfield 38	com/android/mms/exif/ExifModifier:mByteBuffer	Ljava/nio/ByteBuffer;
    //   90: iconst_0
    //   91: invokevirtual 76	java/nio/ByteBuffer:position	(I)Ljava/nio/Buffer;
    //   94: pop
    //   95: aload 4
    //   97: invokestatic 82	com/android/mms/exif/ExifInterface:closeSilently	(Ljava/io/Closeable;)V
    //   100: return
    //   101: astore 5
    //   103: aload_3
    //   104: invokestatic 82	com/android/mms/exif/ExifInterface:closeSilently	(Ljava/io/Closeable;)V
    //   107: aload 5
    //   109: athrow
    //   110: astore 5
    //   112: aload 4
    //   114: astore_3
    //   115: goto -12 -> 103
    //
    // Exception table:
    //   from	to	target	type
    //   35	45	101	finally
    //   45	95	110	finally
  }

  private void modify()
  {
    this.mByteBuffer.order(getByteOrder());
    Iterator localIterator = this.mTagOffsets.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return;
      TagOffset localTagOffset = (TagOffset)localIterator.next();
      writeTagValue(localTagOffset.mTag, localTagOffset.mOffset);
    }
  }

  private void writeTagValue(ExifTag paramExifTag, int paramInt)
  {
    this.mByteBuffer.position(paramInt + this.mOffsetBase);
    switch (paramExifTag.getDataType())
    {
    case 6:
    case 8:
    default:
    case 2:
    case 4:
    case 9:
    case 5:
    case 10:
    case 1:
    case 7:
    case 3:
    }
    while (true)
    {
      return;
      byte[] arrayOfByte2 = paramExifTag.getStringByte();
      if (arrayOfByte2.length == paramExifTag.getComponentCount())
      {
        arrayOfByte2[(-1 + arrayOfByte2.length)] = 0;
        this.mByteBuffer.put(arrayOfByte2);
        return;
      }
      this.mByteBuffer.put(arrayOfByte2);
      this.mByteBuffer.put((byte)0);
      return;
      int n = 0;
      int i1 = paramExifTag.getComponentCount();
      while (n < i1)
      {
        this.mByteBuffer.putInt((int)paramExifTag.getValueAt(n));
        n++;
      }
      continue;
      int k = 0;
      int m = paramExifTag.getComponentCount();
      while (k < m)
      {
        Rational localRational = paramExifTag.getRational(k);
        this.mByteBuffer.putInt((int)localRational.getNumerator());
        this.mByteBuffer.putInt((int)localRational.getDenominator());
        k++;
      }
      continue;
      byte[] arrayOfByte1 = new byte[paramExifTag.getComponentCount()];
      paramExifTag.getBytes(arrayOfByte1);
      this.mByteBuffer.put(arrayOfByte1);
      return;
      int i = 0;
      int j = paramExifTag.getComponentCount();
      while (i < j)
      {
        this.mByteBuffer.putShort((short)(int)paramExifTag.getValueAt(i));
        i++;
      }
    }
  }

  // ERROR //
  protected boolean commit()
    throws java.io.IOException, ExifInvalidFormatException
  {
    // Byte code:
    //   0: new 50	com/android/mms/exif/ByteBufferInputStream
    //   3: dup
    //   4: aload_0
    //   5: getfield 38	com/android/mms/exif/ExifModifier:mByteBuffer	Ljava/nio/ByteBuffer;
    //   8: invokespecial 53	com/android/mms/exif/ByteBufferInputStream:<init>	(Ljava/nio/ByteBuffer;)V
    //   11: astore_1
    //   12: iconst_5
    //   13: anewarray 169	com/android/mms/exif/IfdData
    //   16: astore 4
    //   18: aload 4
    //   20: iconst_0
    //   21: aload_0
    //   22: getfield 70	com/android/mms/exif/ExifModifier:mTagToModified	Lcom/android/mms/exif/ExifData;
    //   25: iconst_0
    //   26: invokevirtual 173	com/android/mms/exif/ExifData:getIfdData	(I)Lcom/android/mms/exif/IfdData;
    //   29: aastore
    //   30: aload 4
    //   32: iconst_1
    //   33: aload_0
    //   34: getfield 70	com/android/mms/exif/ExifModifier:mTagToModified	Lcom/android/mms/exif/ExifData;
    //   37: iconst_1
    //   38: invokevirtual 173	com/android/mms/exif/ExifData:getIfdData	(I)Lcom/android/mms/exif/IfdData;
    //   41: aastore
    //   42: aload 4
    //   44: iconst_2
    //   45: aload_0
    //   46: getfield 70	com/android/mms/exif/ExifModifier:mTagToModified	Lcom/android/mms/exif/ExifData;
    //   49: iconst_2
    //   50: invokevirtual 173	com/android/mms/exif/ExifData:getIfdData	(I)Lcom/android/mms/exif/IfdData;
    //   53: aastore
    //   54: aload 4
    //   56: iconst_3
    //   57: aload_0
    //   58: getfield 70	com/android/mms/exif/ExifModifier:mTagToModified	Lcom/android/mms/exif/ExifData;
    //   61: iconst_3
    //   62: invokevirtual 173	com/android/mms/exif/ExifData:getIfdData	(I)Lcom/android/mms/exif/IfdData;
    //   65: aastore
    //   66: aload 4
    //   68: iconst_4
    //   69: aload_0
    //   70: getfield 70	com/android/mms/exif/ExifModifier:mTagToModified	Lcom/android/mms/exif/ExifData;
    //   73: iconst_4
    //   74: invokevirtual 173	com/android/mms/exif/ExifData:getIfdData	(I)Lcom/android/mms/exif/IfdData;
    //   77: aastore
    //   78: aload 4
    //   80: iconst_0
    //   81: aaload
    //   82: astore 5
    //   84: iconst_0
    //   85: istore 6
    //   87: aload 5
    //   89: ifnull +8 -> 97
    //   92: iconst_0
    //   93: iconst_1
    //   94: ior
    //   95: istore 6
    //   97: aload 4
    //   99: iconst_1
    //   100: aaload
    //   101: ifnull +9 -> 110
    //   104: iload 6
    //   106: iconst_2
    //   107: ior
    //   108: istore 6
    //   110: aload 4
    //   112: iconst_2
    //   113: aaload
    //   114: ifnull +9 -> 123
    //   117: iload 6
    //   119: iconst_4
    //   120: ior
    //   121: istore 6
    //   123: aload 4
    //   125: iconst_4
    //   126: aaload
    //   127: ifnull +10 -> 137
    //   130: iload 6
    //   132: bipush 8
    //   134: ior
    //   135: istore 6
    //   137: aload 4
    //   139: iconst_3
    //   140: aaload
    //   141: ifnull +10 -> 151
    //   144: iload 6
    //   146: bipush 16
    //   148: ior
    //   149: istore 6
    //   151: aload_1
    //   152: iload 6
    //   154: aload_0
    //   155: getfield 48	com/android/mms/exif/ExifModifier:mInterface	Lcom/android/mms/exif/ExifInterface;
    //   158: invokestatic 176	com/android/mms/exif/ExifParser:parse	(Ljava/io/InputStream;ILcom/android/mms/exif/ExifInterface;)Lcom/android/mms/exif/ExifParser;
    //   161: astore 7
    //   163: aload 7
    //   165: invokevirtual 178	com/android/mms/exif/ExifParser:next	()I
    //   168: istore 8
    //   170: aconst_null
    //   171: astore 9
    //   173: iload 8
    //   175: iconst_5
    //   176: if_icmpne +28 -> 204
    //   179: aload 4
    //   181: arraylength
    //   182: istore 10
    //   184: iconst_0
    //   185: istore 11
    //   187: iload 11
    //   189: iload 10
    //   191: if_icmplt +193 -> 384
    //   194: aload_0
    //   195: invokespecial 180	com/android/mms/exif/ExifModifier:modify	()V
    //   198: aload_1
    //   199: invokestatic 82	com/android/mms/exif/ExifInterface:closeSilently	(Ljava/io/Closeable;)V
    //   202: iconst_1
    //   203: ireturn
    //   204: iload 8
    //   206: tableswitch	default:+22 -> 228, 0:+32->238, 1:+64->270
    //   229: iconst_4
    //   230: invokevirtual 178	com/android/mms/exif/ExifParser:next	()I
    //   233: istore 8
    //   235: goto -62 -> 173
    //   238: aload 4
    //   240: aload 7
    //   242: invokevirtual 183	com/android/mms/exif/ExifParser:getCurrentIfd	()I
    //   245: aaload
    //   246: astore 9
    //   248: aload 9
    //   250: ifnonnull -22 -> 228
    //   253: aload 7
    //   255: invokevirtual 186	com/android/mms/exif/ExifParser:skipRemainingTagsInCurrentIfd	()V
    //   258: goto -30 -> 228
    //   261: astore_2
    //   262: aload_1
    //   263: astore_3
    //   264: aload_3
    //   265: invokestatic 82	com/android/mms/exif/ExifInterface:closeSilently	(Ljava/io/Closeable;)V
    //   268: aload_2
    //   269: athrow
    //   270: aload 7
    //   272: invokevirtual 190	com/android/mms/exif/ExifParser:getTag	()Lcom/android/mms/exif/ExifTag;
    //   275: astore 14
    //   277: aload 9
    //   279: aload 14
    //   281: invokevirtual 193	com/android/mms/exif/ExifTag:getTagId	()S
    //   284: invokevirtual 196	com/android/mms/exif/IfdData:getTag	(S)Lcom/android/mms/exif/ExifTag;
    //   287: astore 15
    //   289: aload 15
    //   291: ifnull -63 -> 228
    //   294: aload 15
    //   296: invokevirtual 130	com/android/mms/exif/ExifTag:getComponentCount	()I
    //   299: aload 14
    //   301: invokevirtual 130	com/android/mms/exif/ExifTag:getComponentCount	()I
    //   304: if_icmpne +24 -> 328
    //   307: aload 15
    //   309: invokevirtual 123	com/android/mms/exif/ExifTag:getDataType	()S
    //   312: istore 16
    //   314: aload 14
    //   316: invokevirtual 123	com/android/mms/exif/ExifTag:getDataType	()S
    //   319: istore 17
    //   321: iload 16
    //   323: iload 17
    //   325: if_icmpeq +9 -> 334
    //   328: aload_1
    //   329: invokestatic 82	com/android/mms/exif/ExifInterface:closeSilently	(Ljava/io/Closeable;)V
    //   332: iconst_0
    //   333: ireturn
    //   334: aload_0
    //   335: getfield 36	com/android/mms/exif/ExifModifier:mTagOffsets	Ljava/util/List;
    //   338: new 106	com/android/mms/exif/ExifModifier$TagOffset
    //   341: dup
    //   342: aload 15
    //   344: aload 14
    //   346: invokevirtual 199	com/android/mms/exif/ExifTag:getOffset	()I
    //   349: invokespecial 201	com/android/mms/exif/ExifModifier$TagOffset:<init>	(Lcom/android/mms/exif/ExifTag;I)V
    //   352: invokeinterface 205 2 0
    //   357: pop
    //   358: aload 9
    //   360: aload 14
    //   362: invokevirtual 193	com/android/mms/exif/ExifTag:getTagId	()S
    //   365: invokevirtual 209	com/android/mms/exif/IfdData:removeTag	(S)V
    //   368: aload 9
    //   370: invokevirtual 212	com/android/mms/exif/IfdData:getTagCount	()I
    //   373: ifne -145 -> 228
    //   376: aload 7
    //   378: invokevirtual 186	com/android/mms/exif/ExifParser:skipRemainingTagsInCurrentIfd	()V
    //   381: goto -153 -> 228
    //   384: aload 4
    //   386: iload 11
    //   388: aaload
    //   389: astore 12
    //   391: aload 12
    //   393: ifnull +21 -> 414
    //   396: aload 12
    //   398: invokevirtual 212	com/android/mms/exif/IfdData:getTagCount	()I
    //   401: istore 13
    //   403: iload 13
    //   405: ifle +9 -> 414
    //   408: aload_1
    //   409: invokestatic 82	com/android/mms/exif/ExifInterface:closeSilently	(Ljava/io/Closeable;)V
    //   412: iconst_0
    //   413: ireturn
    //   414: iinc 11 1
    //   417: goto -230 -> 187
    //   420: astore_2
    //   421: aconst_null
    //   422: astore_3
    //   423: goto -159 -> 264
    //
    // Exception table:
    //   from	to	target	type
    //   12	84	261	finally
    //   97	104	261	finally
    //   110	117	261	finally
    //   123	130	261	finally
    //   137	144	261	finally
    //   151	170	261	finally
    //   179	184	261	finally
    //   194	198	261	finally
    //   228	235	261	finally
    //   238	248	261	finally
    //   253	258	261	finally
    //   270	289	261	finally
    //   294	321	261	finally
    //   334	381	261	finally
    //   384	391	261	finally
    //   396	403	261	finally
    //   0	12	420	finally
  }

  protected ByteOrder getByteOrder()
  {
    return this.mTagToModified.getByteOrder();
  }

  public void modifyTag(ExifTag paramExifTag)
  {
    this.mTagToModified.addTag(paramExifTag);
  }

  private static class TagOffset
  {
    final int mOffset;
    final ExifTag mTag;

    TagOffset(ExifTag paramExifTag, int paramInt)
    {
      this.mTag = paramExifTag;
      this.mOffset = paramInt;
    }
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.android.mms.exif.ExifModifier
 * JD-Core Version:    0.6.2
 */