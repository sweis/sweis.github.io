package com.android.mms.exif;

public class Rational
{
  private final long mDenominator;
  private final long mNumerator;

  public Rational(long paramLong1, long paramLong2)
  {
    this.mNumerator = paramLong1;
    this.mDenominator = paramLong2;
  }

  public Rational(Rational paramRational)
  {
    this.mNumerator = paramRational.mNumerator;
    this.mDenominator = paramRational.mDenominator;
  }

  public boolean equals(Object paramObject)
  {
    if (paramObject == null);
    Rational localRational;
    do
    {
      do
      {
        return false;
        if (this == paramObject)
          return true;
      }
      while (!(paramObject instanceof Rational));
      localRational = (Rational)paramObject;
    }
    while ((this.mNumerator != localRational.mNumerator) || (this.mDenominator != localRational.mDenominator));
    return true;
  }

  public long getDenominator()
  {
    return this.mDenominator;
  }

  public long getNumerator()
  {
    return this.mNumerator;
  }

  public double toDouble()
  {
    return this.mNumerator / this.mDenominator;
  }

  public String toString()
  {
    return this.mNumerator + "/" + this.mDenominator;
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.android.mms.exif.Rational
 * JD-Core Version:    0.6.2
 */