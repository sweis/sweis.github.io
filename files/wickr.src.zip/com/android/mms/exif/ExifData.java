package com.android.mms.exif;

import android.util.Log;
import java.io.UnsupportedEncodingException;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class ExifData
{
  private static final String TAG = "ExifData";
  private static final byte[] USER_COMMENT_ASCII;
  private static final byte[] USER_COMMENT_JIS;
  private static final byte[] USER_COMMENT_UNICODE = arrayOfByte3;
  private final ByteOrder mByteOrder;
  private final IfdData[] mIfdDatas = new IfdData[5];
  private final ArrayList<byte[]> mStripBytes = new ArrayList();
  private byte[] mThumbnail;

  static
  {
    byte[] arrayOfByte1 = new byte[8];
    arrayOfByte1[0] = 65;
    arrayOfByte1[1] = 83;
    arrayOfByte1[2] = 67;
    arrayOfByte1[3] = 73;
    arrayOfByte1[4] = 73;
    USER_COMMENT_ASCII = arrayOfByte1;
    byte[] arrayOfByte2 = new byte[8];
    arrayOfByte2[0] = 74;
    arrayOfByte2[1] = 73;
    arrayOfByte2[2] = 83;
    USER_COMMENT_JIS = arrayOfByte2;
    byte[] arrayOfByte3 = new byte[8];
    arrayOfByte3[0] = 85;
    arrayOfByte3[1] = 78;
    arrayOfByte3[2] = 73;
    arrayOfByte3[3] = 67;
    arrayOfByte3[4] = 79;
    arrayOfByte3[5] = 68;
    arrayOfByte3[6] = 69;
  }

  ExifData(ByteOrder paramByteOrder)
  {
    this.mByteOrder = paramByteOrder;
  }

  protected void addIfdData(IfdData paramIfdData)
  {
    this.mIfdDatas[paramIfdData.getId()] = paramIfdData;
  }

  protected ExifTag addTag(ExifTag paramExifTag)
  {
    if (paramExifTag != null)
      return addTag(paramExifTag, paramExifTag.getIfd());
    return null;
  }

  protected ExifTag addTag(ExifTag paramExifTag, int paramInt)
  {
    if ((paramExifTag != null) && (ExifTag.isValidIfd(paramInt)))
      return getOrCreateIfdData(paramInt).setTag(paramExifTag);
    return null;
  }

  protected void clearThumbnailAndStrips()
  {
    this.mThumbnail = null;
    this.mStripBytes.clear();
  }

  public boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    if (paramObject == null)
      return false;
    if ((paramObject instanceof ExifData))
    {
      ExifData localExifData = (ExifData)paramObject;
      if ((localExifData.mByteOrder != this.mByteOrder) || (localExifData.mStripBytes.size() != this.mStripBytes.size()) || (!Arrays.equals(localExifData.mThumbnail, this.mThumbnail)))
        return false;
      int i = 0;
      if (i >= this.mStripBytes.size());
      for (int j = 0; ; j++)
      {
        if (j >= 5)
        {
          return true;
          if (!Arrays.equals((byte[])localExifData.mStripBytes.get(i), (byte[])this.mStripBytes.get(i)))
            return false;
          i++;
          break;
        }
        IfdData localIfdData1 = localExifData.getIfdData(j);
        IfdData localIfdData2 = getIfdData(j);
        if ((localIfdData1 != localIfdData2) && (localIfdData1 != null) && (!localIfdData1.equals(localIfdData2)))
          return false;
      }
    }
    return false;
  }

  protected List<ExifTag> getAllTags()
  {
    ArrayList localArrayList = new ArrayList();
    IfdData[] arrayOfIfdData = this.mIfdDatas;
    int i = arrayOfIfdData.length;
    int j = 0;
    if (j >= i)
    {
      if (localArrayList.size() == 0)
        localArrayList = null;
      return localArrayList;
    }
    IfdData localIfdData = arrayOfIfdData[j];
    ExifTag[] arrayOfExifTag;
    int k;
    if (localIfdData != null)
    {
      arrayOfExifTag = localIfdData.getAllTags();
      if (arrayOfExifTag != null)
        k = arrayOfExifTag.length;
    }
    for (int m = 0; ; m++)
    {
      if (m >= k)
      {
        j++;
        break;
      }
      localArrayList.add(arrayOfExifTag[m]);
    }
  }

  protected List<ExifTag> getAllTagsForIfd(int paramInt)
  {
    IfdData localIfdData = this.mIfdDatas[paramInt];
    if (localIfdData == null)
    {
      localObject = null;
      return localObject;
    }
    ExifTag[] arrayOfExifTag = localIfdData.getAllTags();
    if (arrayOfExifTag == null)
      return null;
    Object localObject = new ArrayList(arrayOfExifTag.length);
    int i = arrayOfExifTag.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        if (((ArrayList)localObject).size() != 0)
          break;
        return null;
      }
      ((ArrayList)localObject).add(arrayOfExifTag[j]);
    }
  }

  protected List<ExifTag> getAllTagsForTagId(short paramShort)
  {
    ArrayList localArrayList = new ArrayList();
    IfdData[] arrayOfIfdData = this.mIfdDatas;
    int i = arrayOfIfdData.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        if (localArrayList.size() == 0)
          localArrayList = null;
        return localArrayList;
      }
      IfdData localIfdData = arrayOfIfdData[j];
      if (localIfdData != null)
      {
        ExifTag localExifTag = localIfdData.getTag(paramShort);
        if (localExifTag != null)
          localArrayList.add(localExifTag);
      }
    }
  }

  protected ByteOrder getByteOrder()
  {
    return this.mByteOrder;
  }

  protected byte[] getCompressedThumbnail()
  {
    return this.mThumbnail;
  }

  protected IfdData getIfdData(int paramInt)
  {
    if (ExifTag.isValidIfd(paramInt))
      return this.mIfdDatas[paramInt];
    return null;
  }

  protected IfdData getOrCreateIfdData(int paramInt)
  {
    IfdData localIfdData = this.mIfdDatas[paramInt];
    if (localIfdData == null)
    {
      localIfdData = new IfdData(paramInt);
      this.mIfdDatas[paramInt] = localIfdData;
    }
    return localIfdData;
  }

  protected byte[] getStrip(int paramInt)
  {
    return (byte[])this.mStripBytes.get(paramInt);
  }

  protected int getStripCount()
  {
    return this.mStripBytes.size();
  }

  protected ExifTag getTag(short paramShort, int paramInt)
  {
    IfdData localIfdData = this.mIfdDatas[paramInt];
    if (localIfdData == null)
      return null;
    return localIfdData.getTag(paramShort);
  }

  protected String getUserComment()
  {
    IfdData localIfdData = this.mIfdDatas[0];
    if (localIfdData == null);
    while (true)
    {
      return null;
      ExifTag localExifTag = localIfdData.getTag(ExifInterface.getTrueTagKey(ExifInterface.TAG_USER_COMMENT));
      if ((localExifTag != null) && (localExifTag.getComponentCount() >= 8))
      {
        byte[] arrayOfByte1 = new byte[localExifTag.getComponentCount()];
        localExifTag.getBytes(arrayOfByte1);
        byte[] arrayOfByte2 = new byte[8];
        System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, 8);
        try
        {
          if (Arrays.equals(arrayOfByte2, USER_COMMENT_ASCII))
            return new String(arrayOfByte1, 8, -8 + arrayOfByte1.length, "US-ASCII");
          if (Arrays.equals(arrayOfByte2, USER_COMMENT_JIS))
            return new String(arrayOfByte1, 8, -8 + arrayOfByte1.length, "EUC-JP");
          if (Arrays.equals(arrayOfByte2, USER_COMMENT_UNICODE))
          {
            String str = new String(arrayOfByte1, 8, -8 + arrayOfByte1.length, "UTF-16");
            return str;
          }
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException)
        {
          Log.w("ExifData", "Failed to decode the user comment");
        }
      }
    }
    return null;
  }

  protected boolean hasCompressedThumbnail()
  {
    return this.mThumbnail != null;
  }

  protected boolean hasUncompressedStrip()
  {
    return this.mStripBytes.size() != 0;
  }

  protected void removeTag(short paramShort, int paramInt)
  {
    IfdData localIfdData = this.mIfdDatas[paramInt];
    if (localIfdData == null)
      return;
    localIfdData.removeTag(paramShort);
  }

  protected void removeThumbnailData()
  {
    clearThumbnailAndStrips();
    this.mIfdDatas[1] = null;
  }

  protected void setCompressedThumbnail(byte[] paramArrayOfByte)
  {
    this.mThumbnail = paramArrayOfByte;
  }

  protected void setStripBytes(int paramInt, byte[] paramArrayOfByte)
  {
    if (paramInt < this.mStripBytes.size())
    {
      this.mStripBytes.set(paramInt, paramArrayOfByte);
      return;
    }
    for (int i = this.mStripBytes.size(); ; i++)
    {
      if (i >= paramInt)
      {
        this.mStripBytes.add(paramArrayOfByte);
        return;
      }
      this.mStripBytes.add(null);
    }
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.android.mms.exif.ExifData
 * JD-Core Version:    0.6.2
 */