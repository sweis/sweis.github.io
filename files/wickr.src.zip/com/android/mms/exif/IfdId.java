package com.android.mms.exif;

public abstract interface IfdId
{
  public static final int TYPE_IFD_0 = 0;
  public static final int TYPE_IFD_1 = 1;
  public static final int TYPE_IFD_COUNT = 5;
  public static final int TYPE_IFD_EXIF = 2;
  public static final int TYPE_IFD_GPS = 4;
  public static final int TYPE_IFD_INTEROPERABILITY = 3;
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.android.mms.exif.IfdId
 * JD-Core Version:    0.6.2
 */