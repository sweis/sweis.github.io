package com.android.mms.exif;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

class IfdData
{
  private static final int[] sIfds = arrayOfInt;
  private final Map<Short, ExifTag> mExifTags = new HashMap();
  private final int mIfdId;
  private int mOffsetToNextIfd = 0;

  static
  {
    int[] arrayOfInt = new int[5];
    arrayOfInt[1] = 1;
    arrayOfInt[2] = 2;
    arrayOfInt[3] = 3;
    arrayOfInt[4] = 4;
  }

  IfdData(int paramInt)
  {
    this.mIfdId = paramInt;
  }

  protected static int[] getIfds()
  {
    return sIfds;
  }

  protected boolean checkCollision(short paramShort)
  {
    return this.mExifTags.get(Short.valueOf(paramShort)) != null;
  }

  public boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    if (paramObject == null)
      return false;
    if ((paramObject instanceof IfdData))
    {
      IfdData localIfdData = (IfdData)paramObject;
      if ((localIfdData.getId() == this.mIfdId) && (localIfdData.getTagCount() == getTagCount()))
      {
        ExifTag[] arrayOfExifTag = localIfdData.getAllTags();
        int i = arrayOfExifTag.length;
        int j = 0;
        label59: ExifTag localExifTag;
        if (j < i)
        {
          localExifTag = arrayOfExifTag[j];
          if (!ExifInterface.isOffsetTag(localExifTag.getTagId()))
            break label89;
        }
        label89: 
        while (localExifTag.equals((ExifTag)this.mExifTags.get(Short.valueOf(localExifTag.getTagId()))))
        {
          j++;
          break label59;
          break;
        }
        return false;
      }
    }
    return false;
  }

  protected ExifTag[] getAllTags()
  {
    return (ExifTag[])this.mExifTags.values().toArray(new ExifTag[this.mExifTags.size()]);
  }

  protected int getId()
  {
    return this.mIfdId;
  }

  protected int getOffsetToNextIfd()
  {
    return this.mOffsetToNextIfd;
  }

  protected ExifTag getTag(short paramShort)
  {
    return (ExifTag)this.mExifTags.get(Short.valueOf(paramShort));
  }

  protected int getTagCount()
  {
    return this.mExifTags.size();
  }

  protected void removeTag(short paramShort)
  {
    this.mExifTags.remove(Short.valueOf(paramShort));
  }

  protected void setOffsetToNextIfd(int paramInt)
  {
    this.mOffsetToNextIfd = paramInt;
  }

  protected ExifTag setTag(ExifTag paramExifTag)
  {
    paramExifTag.setIfd(this.mIfdId);
    return (ExifTag)this.mExifTags.put(Short.valueOf(paramExifTag.getTagId()), paramExifTag);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.android.mms.exif.IfdData
 * JD-Core Version:    0.6.2
 */