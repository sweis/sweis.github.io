package com.android.mms.exif;

import java.io.BufferedOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class ExifOutputStream extends FilterOutputStream
{
  private static final boolean DEBUG = false;
  private static final int EXIF_HEADER = 1165519206;
  private static final int MAX_EXIF_SIZE = 65535;
  private static final int STATE_FRAME_HEADER = 1;
  private static final int STATE_JPEG_DATA = 2;
  private static final int STATE_SOI = 0;
  private static final int STREAMBUFFER_SIZE = 65536;
  private static final String TAG = "ExifOutputStream";
  private static final short TAG_SIZE = 12;
  private static final short TIFF_BIG_ENDIAN = 19789;
  private static final short TIFF_HEADER = 42;
  private static final short TIFF_HEADER_SIZE = 8;
  private static final short TIFF_LITTLE_ENDIAN = 18761;
  private final ByteBuffer mBuffer = ByteBuffer.allocate(4);
  private int mByteToCopy;
  private int mByteToSkip;
  private ExifData mExifData;
  private final ExifInterface mInterface;
  private final byte[] mSingleByteArray = new byte[1];
  private int mState = 0;

  protected ExifOutputStream(OutputStream paramOutputStream, ExifInterface paramExifInterface)
  {
    super(new BufferedOutputStream(paramOutputStream, 65536));
    this.mInterface = paramExifInterface;
  }

  private int calculateAllOffset()
  {
    IfdData localIfdData1 = this.mExifData.getIfdData(0);
    int i = calculateOffsetOfIfd(localIfdData1, 8);
    localIfdData1.getTag(ExifInterface.getTrueTagKey(ExifInterface.TAG_EXIF_IFD)).setValue(i);
    IfdData localIfdData2 = this.mExifData.getIfdData(2);
    int j = calculateOffsetOfIfd(localIfdData2, i);
    IfdData localIfdData3 = this.mExifData.getIfdData(3);
    if (localIfdData3 != null)
    {
      localIfdData2.getTag(ExifInterface.getTrueTagKey(ExifInterface.TAG_INTEROPERABILITY_IFD)).setValue(j);
      j = calculateOffsetOfIfd(localIfdData3, j);
    }
    IfdData localIfdData4 = this.mExifData.getIfdData(4);
    if (localIfdData4 != null)
    {
      localIfdData1.getTag(ExifInterface.getTrueTagKey(ExifInterface.TAG_GPS_IFD)).setValue(j);
      j = calculateOffsetOfIfd(localIfdData4, j);
    }
    IfdData localIfdData5 = this.mExifData.getIfdData(1);
    if (localIfdData5 != null)
    {
      localIfdData1.setOffsetToNextIfd(j);
      j = calculateOffsetOfIfd(localIfdData5, j);
    }
    if (this.mExifData.hasCompressedThumbnail())
    {
      localIfdData5.getTag(ExifInterface.getTrueTagKey(ExifInterface.TAG_JPEG_INTERCHANGE_FORMAT)).setValue(j);
      j += this.mExifData.getCompressedThumbnail().length;
    }
    while (!this.mExifData.hasUncompressedStrip())
      return j;
    long[] arrayOfLong = new long[this.mExifData.getStripCount()];
    for (int k = 0; ; k++)
    {
      if (k >= this.mExifData.getStripCount())
      {
        localIfdData5.getTag(ExifInterface.getTrueTagKey(ExifInterface.TAG_STRIP_OFFSETS)).setValue(arrayOfLong);
        return j;
      }
      arrayOfLong[k] = j;
      j += this.mExifData.getStrip(k).length;
    }
  }

  private int calculateOffsetOfIfd(IfdData paramIfdData, int paramInt)
  {
    int i = paramInt + (4 + (2 + 12 * paramIfdData.getTagCount()));
    ExifTag[] arrayOfExifTag = paramIfdData.getAllTags();
    int j = arrayOfExifTag.length;
    for (int k = 0; ; k++)
    {
      if (k >= j)
        return i;
      ExifTag localExifTag = arrayOfExifTag[k];
      if (localExifTag.getDataSize() > 4)
      {
        localExifTag.setOffset(i);
        i += localExifTag.getDataSize();
      }
    }
  }

  private void createRequiredIfdAndTag()
    throws IOException
  {
    IfdData localIfdData1 = this.mExifData.getIfdData(0);
    if (localIfdData1 == null)
    {
      localIfdData1 = new IfdData(0);
      this.mExifData.addIfdData(localIfdData1);
    }
    ExifTag localExifTag1 = this.mInterface.buildUninitializedTag(ExifInterface.TAG_EXIF_IFD);
    if (localExifTag1 == null)
      throw new IOException("No definition for crucial exif tag: " + ExifInterface.TAG_EXIF_IFD);
    localIfdData1.setTag(localExifTag1);
    IfdData localIfdData2 = this.mExifData.getIfdData(2);
    if (localIfdData2 == null)
    {
      localIfdData2 = new IfdData(2);
      this.mExifData.addIfdData(localIfdData2);
    }
    if (this.mExifData.getIfdData(4) != null)
    {
      ExifTag localExifTag7 = this.mInterface.buildUninitializedTag(ExifInterface.TAG_GPS_IFD);
      if (localExifTag7 == null)
        throw new IOException("No definition for crucial exif tag: " + ExifInterface.TAG_GPS_IFD);
      localIfdData1.setTag(localExifTag7);
    }
    if (this.mExifData.getIfdData(3) != null)
    {
      ExifTag localExifTag6 = this.mInterface.buildUninitializedTag(ExifInterface.TAG_INTEROPERABILITY_IFD);
      if (localExifTag6 == null)
        throw new IOException("No definition for crucial exif tag: " + ExifInterface.TAG_INTEROPERABILITY_IFD);
      localIfdData2.setTag(localExifTag6);
    }
    IfdData localIfdData3 = this.mExifData.getIfdData(1);
    if (this.mExifData.hasCompressedThumbnail())
    {
      if (localIfdData3 == null)
      {
        localIfdData3 = new IfdData(1);
        this.mExifData.addIfdData(localIfdData3);
      }
      ExifTag localExifTag4 = this.mInterface.buildUninitializedTag(ExifInterface.TAG_JPEG_INTERCHANGE_FORMAT);
      if (localExifTag4 == null)
        throw new IOException("No definition for crucial exif tag: " + ExifInterface.TAG_JPEG_INTERCHANGE_FORMAT);
      localIfdData3.setTag(localExifTag4);
      ExifTag localExifTag5 = this.mInterface.buildUninitializedTag(ExifInterface.TAG_JPEG_INTERCHANGE_FORMAT_LENGTH);
      if (localExifTag5 == null)
        throw new IOException("No definition for crucial exif tag: " + ExifInterface.TAG_JPEG_INTERCHANGE_FORMAT_LENGTH);
      localExifTag5.setValue(this.mExifData.getCompressedThumbnail().length);
      localIfdData3.setTag(localExifTag5);
      localIfdData3.removeTag(ExifInterface.getTrueTagKey(ExifInterface.TAG_STRIP_OFFSETS));
      localIfdData3.removeTag(ExifInterface.getTrueTagKey(ExifInterface.TAG_STRIP_BYTE_COUNTS));
    }
    do
    {
      return;
      if (this.mExifData.hasUncompressedStrip())
      {
        if (localIfdData3 == null)
        {
          localIfdData3 = new IfdData(1);
          this.mExifData.addIfdData(localIfdData3);
        }
        int i = this.mExifData.getStripCount();
        ExifTag localExifTag2 = this.mInterface.buildUninitializedTag(ExifInterface.TAG_STRIP_OFFSETS);
        if (localExifTag2 == null)
          throw new IOException("No definition for crucial exif tag: " + ExifInterface.TAG_STRIP_OFFSETS);
        ExifTag localExifTag3 = this.mInterface.buildUninitializedTag(ExifInterface.TAG_STRIP_BYTE_COUNTS);
        if (localExifTag3 == null)
          throw new IOException("No definition for crucial exif tag: " + ExifInterface.TAG_STRIP_BYTE_COUNTS);
        long[] arrayOfLong = new long[i];
        for (int j = 0; ; j++)
        {
          if (j >= this.mExifData.getStripCount())
          {
            localExifTag3.setValue(arrayOfLong);
            localIfdData3.setTag(localExifTag2);
            localIfdData3.setTag(localExifTag3);
            localIfdData3.removeTag(ExifInterface.getTrueTagKey(ExifInterface.TAG_JPEG_INTERCHANGE_FORMAT));
            localIfdData3.removeTag(ExifInterface.getTrueTagKey(ExifInterface.TAG_JPEG_INTERCHANGE_FORMAT_LENGTH));
            return;
          }
          arrayOfLong[j] = this.mExifData.getStrip(j).length;
        }
      }
    }
    while (localIfdData3 == null);
    localIfdData3.removeTag(ExifInterface.getTrueTagKey(ExifInterface.TAG_STRIP_OFFSETS));
    localIfdData3.removeTag(ExifInterface.getTrueTagKey(ExifInterface.TAG_STRIP_BYTE_COUNTS));
    localIfdData3.removeTag(ExifInterface.getTrueTagKey(ExifInterface.TAG_JPEG_INTERCHANGE_FORMAT));
    localIfdData3.removeTag(ExifInterface.getTrueTagKey(ExifInterface.TAG_JPEG_INTERCHANGE_FORMAT_LENGTH));
  }

  private int requestByteToBuffer(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
  {
    int i = paramInt1 - this.mBuffer.position();
    if (paramInt3 > i);
    for (int j = i; ; j = paramInt3)
    {
      this.mBuffer.put(paramArrayOfByte, paramInt2, j);
      return j;
    }
  }

  private ArrayList<ExifTag> stripNullValueTags(ExifData paramExifData)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramExifData.getAllTags().iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return localArrayList;
      ExifTag localExifTag = (ExifTag)localIterator.next();
      if ((localExifTag.getValue() == null) && (!ExifInterface.isOffsetTag(localExifTag.getTagId())))
      {
        paramExifData.removeTag(localExifTag.getTagId(), localExifTag.getIfd());
        localArrayList.add(localExifTag);
      }
    }
  }

  private void writeAllTags(OrderedDataOutputStream paramOrderedDataOutputStream)
    throws IOException
  {
    writeIfd(this.mExifData.getIfdData(0), paramOrderedDataOutputStream);
    writeIfd(this.mExifData.getIfdData(2), paramOrderedDataOutputStream);
    IfdData localIfdData1 = this.mExifData.getIfdData(3);
    if (localIfdData1 != null)
      writeIfd(localIfdData1, paramOrderedDataOutputStream);
    IfdData localIfdData2 = this.mExifData.getIfdData(4);
    if (localIfdData2 != null)
      writeIfd(localIfdData2, paramOrderedDataOutputStream);
    if (this.mExifData.getIfdData(1) != null)
      writeIfd(this.mExifData.getIfdData(1), paramOrderedDataOutputStream);
  }

  private void writeExifData()
    throws IOException
  {
    if (this.mExifData == null)
      return;
    ArrayList localArrayList = stripNullValueTags(this.mExifData);
    createRequiredIfdAndTag();
    int i = calculateAllOffset();
    if (i + 8 > 65535)
      throw new IOException("Exif header is too large (>64Kb)");
    OrderedDataOutputStream localOrderedDataOutputStream = new OrderedDataOutputStream(this.out);
    localOrderedDataOutputStream.setByteOrder(ByteOrder.BIG_ENDIAN);
    localOrderedDataOutputStream.writeShort((short)-31);
    localOrderedDataOutputStream.writeShort((short)(i + 8));
    localOrderedDataOutputStream.writeInt(1165519206);
    localOrderedDataOutputStream.writeShort((short)0);
    if (this.mExifData.getByteOrder() == ByteOrder.BIG_ENDIAN)
      localOrderedDataOutputStream.writeShort((short)19789);
    while (true)
    {
      localOrderedDataOutputStream.setByteOrder(this.mExifData.getByteOrder());
      localOrderedDataOutputStream.writeShort((short)42);
      localOrderedDataOutputStream.writeInt(8);
      writeAllTags(localOrderedDataOutputStream);
      writeThumbnail(localOrderedDataOutputStream);
      Iterator localIterator = localArrayList.iterator();
      while (localIterator.hasNext())
      {
        ExifTag localExifTag = (ExifTag)localIterator.next();
        this.mExifData.addTag(localExifTag);
      }
      break;
      localOrderedDataOutputStream.writeShort((short)18761);
    }
  }

  private void writeIfd(IfdData paramIfdData, OrderedDataOutputStream paramOrderedDataOutputStream)
    throws IOException
  {
    int i = 0;
    ExifTag[] arrayOfExifTag = paramIfdData.getAllTags();
    paramOrderedDataOutputStream.writeShort((short)arrayOfExifTag.length);
    int j = arrayOfExifTag.length;
    int k = 0;
    int i1;
    if (k >= j)
    {
      paramOrderedDataOutputStream.writeInt(paramIfdData.getOffsetToNextIfd());
      i1 = arrayOfExifTag.length;
    }
    while (true)
    {
      if (i >= i1)
      {
        return;
        ExifTag localExifTag1 = arrayOfExifTag[k];
        paramOrderedDataOutputStream.writeShort(localExifTag1.getTagId());
        paramOrderedDataOutputStream.writeShort(localExifTag1.getDataType());
        paramOrderedDataOutputStream.writeInt(localExifTag1.getComponentCount());
        if (localExifTag1.getDataSize() > 4)
          paramOrderedDataOutputStream.writeInt(localExifTag1.getOffset());
        while (true)
        {
          k++;
          break;
          writeTagValue(localExifTag1, paramOrderedDataOutputStream);
          int m = 0;
          int n = 4 - localExifTag1.getDataSize();
          while (m < n)
          {
            paramOrderedDataOutputStream.write(0);
            m++;
          }
        }
      }
      ExifTag localExifTag2 = arrayOfExifTag[i];
      if (localExifTag2.getDataSize() > 4)
        writeTagValue(localExifTag2, paramOrderedDataOutputStream);
      i++;
    }
  }

  static void writeTagValue(ExifTag paramExifTag, OrderedDataOutputStream paramOrderedDataOutputStream)
    throws IOException
  {
    switch (paramExifTag.getDataType())
    {
    case 6:
    case 8:
    default:
    case 2:
    case 4:
    case 9:
    case 5:
    case 10:
    case 1:
    case 7:
    case 3:
    }
    while (true)
    {
      return;
      byte[] arrayOfByte2 = paramExifTag.getStringByte();
      if (arrayOfByte2.length == paramExifTag.getComponentCount())
      {
        arrayOfByte2[(-1 + arrayOfByte2.length)] = 0;
        paramOrderedDataOutputStream.write(arrayOfByte2);
        return;
      }
      paramOrderedDataOutputStream.write(arrayOfByte2);
      paramOrderedDataOutputStream.write(0);
      return;
      int n = 0;
      int i1 = paramExifTag.getComponentCount();
      while (n < i1)
      {
        paramOrderedDataOutputStream.writeInt((int)paramExifTag.getValueAt(n));
        n++;
      }
      continue;
      int k = 0;
      int m = paramExifTag.getComponentCount();
      while (k < m)
      {
        paramOrderedDataOutputStream.writeRational(paramExifTag.getRational(k));
        k++;
      }
      continue;
      byte[] arrayOfByte1 = new byte[paramExifTag.getComponentCount()];
      paramExifTag.getBytes(arrayOfByte1);
      paramOrderedDataOutputStream.write(arrayOfByte1);
      return;
      int i = 0;
      int j = paramExifTag.getComponentCount();
      while (i < j)
      {
        paramOrderedDataOutputStream.writeShort((short)(int)paramExifTag.getValueAt(i));
        i++;
      }
    }
  }

  private void writeThumbnail(OrderedDataOutputStream paramOrderedDataOutputStream)
    throws IOException
  {
    if (this.mExifData.hasCompressedThumbnail())
      paramOrderedDataOutputStream.write(this.mExifData.getCompressedThumbnail());
    while (true)
    {
      return;
      if (this.mExifData.hasUncompressedStrip())
        for (int i = 0; i < this.mExifData.getStripCount(); i++)
          paramOrderedDataOutputStream.write(this.mExifData.getStrip(i));
    }
  }

  protected ExifData getExifData()
  {
    return this.mExifData;
  }

  protected void setExifData(ExifData paramExifData)
  {
    this.mExifData = paramExifData;
  }

  public void write(int paramInt)
    throws IOException
  {
    this.mSingleByteArray[0] = ((byte)(paramInt & 0xFF));
    write(this.mSingleByteArray);
  }

  public void write(byte[] paramArrayOfByte)
    throws IOException
  {
    write(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    if (((this.mByteToSkip <= 0) && (this.mByteToCopy <= 0) && (this.mState == 2)) || (paramInt2 <= 0))
      if (paramInt2 > 0)
        this.out.write(paramArrayOfByte, paramInt1, paramInt2);
    label40: label62: label239: label245: 
    do
    {
      return;
      int m;
      if (this.mByteToSkip > 0)
      {
        if (paramInt2 > this.mByteToSkip)
        {
          m = this.mByteToSkip;
          paramInt2 -= m;
          this.mByteToSkip -= m;
          paramInt1 += m;
        }
      }
      else if (this.mByteToCopy > 0)
        if (paramInt2 <= this.mByteToCopy)
          break label239;
      for (int k = this.mByteToCopy; ; k = paramInt2)
      {
        this.out.write(paramArrayOfByte, paramInt1, k);
        paramInt2 -= k;
        this.mByteToCopy -= k;
        paramInt1 += k;
        if (paramInt2 == 0)
          break label40;
        switch (this.mState)
        {
        default:
          break;
        case 0:
          int j = requestByteToBuffer(2, paramArrayOfByte, paramInt1, paramInt2);
          paramInt1 += j;
          paramInt2 -= j;
          if (this.mBuffer.position() < 2)
            break label40;
          this.mBuffer.rewind();
          if (this.mBuffer.getShort() == -40)
            break label245;
          throw new IOException("Not a valid jpeg image, cannot write exif");
          m = paramInt2;
          break label62;
        case 1:
        }
      }
      this.out.write(this.mBuffer.array(), 0, 2);
      this.mState = 1;
      this.mBuffer.rewind();
      writeExifData();
      break;
      int i = requestByteToBuffer(4, paramArrayOfByte, paramInt1, paramInt2);
      paramInt1 += i;
      paramInt2 -= i;
      if ((this.mBuffer.position() == 2) && (this.mBuffer.getShort() == -39))
      {
        this.out.write(this.mBuffer.array(), 0, 2);
        this.mBuffer.rewind();
      }
    }
    while (this.mBuffer.position() < 4);
    this.mBuffer.rewind();
    short s = this.mBuffer.getShort();
    if (s == -31)
    {
      this.mByteToSkip = (-2 + (0xFFFF & this.mBuffer.getShort()));
      this.mState = 2;
    }
    while (true)
    {
      this.mBuffer.rewind();
      break;
      if (!JpegHeader.isSofMarker(s))
      {
        this.out.write(this.mBuffer.array(), 0, 4);
        this.mByteToCopy = (-2 + (0xFFFF & this.mBuffer.getShort()));
      }
      else
      {
        this.out.write(this.mBuffer.array(), 0, 4);
        this.mState = 2;
      }
    }
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.android.mms.exif.ExifOutputStream
 * JD-Core Version:    0.6.2
 */