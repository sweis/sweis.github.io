package com.android.mms.exif;

public class ExifInvalidFormatException extends Exception
{
  public ExifInvalidFormatException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.android.mms.exif.ExifInvalidFormatException
 * JD-Core Version:    0.6.2
 */