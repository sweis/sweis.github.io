package com.android.mms.exif;

import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

public class ExifTag
{
  private static final long LONG_MAX = 2147483647L;
  private static final long LONG_MIN = -2147483648L;
  static final int SIZE_UNDEFINED = 0;
  private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("yyyy:MM:dd kk:mm:ss");
  public static final short TYPE_ASCII = 2;
  public static final short TYPE_LONG = 9;
  public static final short TYPE_RATIONAL = 10;
  private static final int[] TYPE_TO_SIZE_MAP;
  public static final short TYPE_UNDEFINED = 7;
  public static final short TYPE_UNSIGNED_BYTE = 1;
  public static final short TYPE_UNSIGNED_LONG = 4;
  public static final short TYPE_UNSIGNED_RATIONAL = 5;
  public static final short TYPE_UNSIGNED_SHORT = 3;
  private static final long UNSIGNED_LONG_MAX = 4294967295L;
  private static final int UNSIGNED_SHORT_MAX = 65535;
  private static Charset US_ASCII = Charset.forName("US-ASCII");
  private int mComponentCountActual;
  private final short mDataType;
  private boolean mHasDefinedDefaultComponentCount;
  private int mIfd;
  private int mOffset;
  private final short mTagId;
  private Object mValue;

  static
  {
    TYPE_TO_SIZE_MAP = new int[11];
    TYPE_TO_SIZE_MAP[1] = 1;
    TYPE_TO_SIZE_MAP[2] = 1;
    TYPE_TO_SIZE_MAP[3] = 2;
    TYPE_TO_SIZE_MAP[4] = 4;
    TYPE_TO_SIZE_MAP[5] = 8;
    TYPE_TO_SIZE_MAP[7] = 1;
    TYPE_TO_SIZE_MAP[9] = 4;
    TYPE_TO_SIZE_MAP[10] = 8;
  }

  ExifTag(short paramShort1, short paramShort2, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    this.mTagId = paramShort1;
    this.mDataType = paramShort2;
    this.mComponentCountActual = paramInt1;
    this.mHasDefinedDefaultComponentCount = paramBoolean;
    this.mIfd = paramInt2;
    this.mValue = null;
  }

  private boolean checkBadComponentCount(int paramInt)
  {
    return (this.mHasDefinedDefaultComponentCount) && (this.mComponentCountActual != paramInt);
  }

  private boolean checkOverflowForRational(Rational[] paramArrayOfRational)
  {
    int i = paramArrayOfRational.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return false;
      Rational localRational = paramArrayOfRational[j];
      if ((localRational.getNumerator() < -2147483648L) || (localRational.getDenominator() < -2147483648L) || (localRational.getNumerator() > 2147483647L) || (localRational.getDenominator() > 2147483647L))
        return true;
    }
  }

  private boolean checkOverflowForUnsignedLong(int[] paramArrayOfInt)
  {
    int i = paramArrayOfInt.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return false;
      if (paramArrayOfInt[j] < 0)
        return true;
    }
  }

  private boolean checkOverflowForUnsignedLong(long[] paramArrayOfLong)
  {
    int i = paramArrayOfLong.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return false;
      long l = paramArrayOfLong[j];
      if ((l < 0L) || (l > 4294967295L))
        return true;
    }
  }

  private boolean checkOverflowForUnsignedRational(Rational[] paramArrayOfRational)
  {
    int i = paramArrayOfRational.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return false;
      Rational localRational = paramArrayOfRational[j];
      if ((localRational.getNumerator() < 0L) || (localRational.getDenominator() < 0L) || (localRational.getNumerator() > 4294967295L) || (localRational.getDenominator() > 4294967295L))
        return true;
    }
  }

  private boolean checkOverflowForUnsignedShort(int[] paramArrayOfInt)
  {
    int i = paramArrayOfInt.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return false;
      int k = paramArrayOfInt[j];
      if ((k > 65535) || (k < 0))
        return true;
    }
  }

  private static String convertTypeToString(short paramShort)
  {
    switch (paramShort)
    {
    case 6:
    case 8:
    default:
      return "";
    case 1:
      return "UNSIGNED_BYTE";
    case 2:
      return "ASCII";
    case 3:
      return "UNSIGNED_SHORT";
    case 4:
      return "UNSIGNED_LONG";
    case 5:
      return "UNSIGNED_RATIONAL";
    case 7:
      return "UNDEFINED";
    case 9:
      return "LONG";
    case 10:
    }
    return "RATIONAL";
  }

  public static int getElementSize(short paramShort)
  {
    return TYPE_TO_SIZE_MAP[paramShort];
  }

  public static boolean isValidIfd(int paramInt)
  {
    int i = 1;
    if ((paramInt != 0) && (paramInt != i) && (paramInt != 2) && (paramInt != 3) && (paramInt != 4))
      i = 0;
    return i;
  }

  public static boolean isValidType(short paramShort)
  {
    short s = 1;
    if ((paramShort != s) && (paramShort != 2) && (paramShort != 3) && (paramShort != 4) && (paramShort != 5) && (paramShort != 7) && (paramShort != 9) && (paramShort != 10))
      s = 0;
    return s;
  }

  public boolean equals(Object paramObject)
  {
    if (paramObject == null);
    ExifTag localExifTag;
    do
    {
      do
      {
        do
        {
          do
          {
            do
            {
              do
              {
                do
                  return false;
                while (!(paramObject instanceof ExifTag));
                localExifTag = (ExifTag)paramObject;
              }
              while ((localExifTag.mTagId != this.mTagId) || (localExifTag.mComponentCountActual != this.mComponentCountActual) || (localExifTag.mDataType != this.mDataType));
              if (this.mValue == null)
                break;
            }
            while (localExifTag.mValue == null);
            if (!(this.mValue instanceof long[]))
              break;
          }
          while (!(localExifTag.mValue instanceof long[]));
          return Arrays.equals((long[])this.mValue, (long[])localExifTag.mValue);
          if (!(this.mValue instanceof Rational[]))
            break;
        }
        while (!(localExifTag.mValue instanceof Rational[]));
        return Arrays.equals((Rational[])this.mValue, (Rational[])localExifTag.mValue);
        if (!(this.mValue instanceof byte[]))
          break;
      }
      while (!(localExifTag.mValue instanceof byte[]));
      return Arrays.equals((byte[])this.mValue, (byte[])localExifTag.mValue);
      return this.mValue.equals(localExifTag.mValue);
    }
    while (localExifTag.mValue != null);
    return true;
  }

  public long forceGetValueAsLong(long paramLong)
  {
    long[] arrayOfLong = getValueAsLongs();
    if ((arrayOfLong != null) && (arrayOfLong.length >= 1))
      paramLong = arrayOfLong[0];
    Rational[] arrayOfRational;
    do
    {
      return paramLong;
      byte[] arrayOfByte = getValueAsBytes();
      if ((arrayOfByte != null) && (arrayOfByte.length >= 1))
        return arrayOfByte[0];
      arrayOfRational = getValueAsRationals();
    }
    while ((arrayOfRational == null) || (arrayOfRational.length < 1) || (arrayOfRational[0].getDenominator() == 0L));
    return ()arrayOfRational[0].toDouble();
  }

  public String forceGetValueAsString()
  {
    if (this.mValue == null)
      return "";
    if ((this.mValue instanceof byte[]))
    {
      if (this.mDataType == 2)
        return new String((byte[])this.mValue, US_ASCII);
      return Arrays.toString((byte[])this.mValue);
    }
    if ((this.mValue instanceof long[]))
    {
      if (((long[])this.mValue).length == 1)
        return String.valueOf(((long[])this.mValue)[0]);
      return Arrays.toString((long[])this.mValue);
    }
    if ((this.mValue instanceof Object[]))
    {
      if (((Object[])this.mValue).length == 1)
      {
        Object localObject = ((Object[])this.mValue)[0];
        if (localObject == null)
          return "";
        return localObject.toString();
      }
      return Arrays.toString((Object[])this.mValue);
    }
    return this.mValue.toString();
  }

  protected void forceSetComponentCount(int paramInt)
  {
    this.mComponentCountActual = paramInt;
  }

  protected void getBytes(byte[] paramArrayOfByte)
  {
    getBytes(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  protected void getBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if ((this.mDataType != 7) && (this.mDataType != 1))
      throw new IllegalArgumentException("Cannot get BYTE value from " + convertTypeToString(this.mDataType));
    Object localObject = this.mValue;
    if (paramInt2 > this.mComponentCountActual)
      paramInt2 = this.mComponentCountActual;
    System.arraycopy(localObject, 0, paramArrayOfByte, paramInt1, paramInt2);
  }

  public int getComponentCount()
  {
    return this.mComponentCountActual;
  }

  public int getDataSize()
  {
    return getComponentCount() * getElementSize(getDataType());
  }

  public short getDataType()
  {
    return this.mDataType;
  }

  public int getIfd()
  {
    return this.mIfd;
  }

  protected int getOffset()
  {
    return this.mOffset;
  }

  protected Rational getRational(int paramInt)
  {
    if ((this.mDataType != 10) && (this.mDataType != 5))
      throw new IllegalArgumentException("Cannot get RATIONAL value from " + convertTypeToString(this.mDataType));
    return ((Rational[])this.mValue)[paramInt];
  }

  protected String getString()
  {
    if (this.mDataType != 2)
      throw new IllegalArgumentException("Cannot get ASCII value from " + convertTypeToString(this.mDataType));
    return new String((byte[])this.mValue, US_ASCII);
  }

  protected byte[] getStringByte()
  {
    return (byte[])this.mValue;
  }

  public short getTagId()
  {
    return this.mTagId;
  }

  public Object getValue()
  {
    return this.mValue;
  }

  public byte getValueAsByte(byte paramByte)
  {
    byte[] arrayOfByte = getValueAsBytes();
    if ((arrayOfByte == null) || (arrayOfByte.length < 1))
      return paramByte;
    return arrayOfByte[0];
  }

  public byte[] getValueAsBytes()
  {
    if ((this.mValue instanceof byte[]))
      return (byte[])this.mValue;
    return null;
  }

  public int getValueAsInt(int paramInt)
  {
    int[] arrayOfInt = getValueAsInts();
    if ((arrayOfInt == null) || (arrayOfInt.length < 1))
      return paramInt;
    return arrayOfInt[0];
  }

  public int[] getValueAsInts()
  {
    Object localObject = this.mValue;
    int[] arrayOfInt = null;
    if (localObject == null);
    while (true)
    {
      return arrayOfInt;
      boolean bool = this.mValue instanceof long[];
      arrayOfInt = null;
      if (bool)
      {
        long[] arrayOfLong = (long[])this.mValue;
        arrayOfInt = new int[arrayOfLong.length];
        for (int i = 0; i < arrayOfLong.length; i++)
          arrayOfInt[i] = ((int)arrayOfLong[i]);
      }
    }
  }

  public long getValueAsLong(long paramLong)
  {
    long[] arrayOfLong = getValueAsLongs();
    if ((arrayOfLong == null) || (arrayOfLong.length < 1))
      return paramLong;
    return arrayOfLong[0];
  }

  public long[] getValueAsLongs()
  {
    if ((this.mValue instanceof long[]))
      return (long[])this.mValue;
    return null;
  }

  public Rational getValueAsRational(long paramLong)
  {
    return getValueAsRational(new Rational(paramLong, 1L));
  }

  public Rational getValueAsRational(Rational paramRational)
  {
    Rational[] arrayOfRational = getValueAsRationals();
    if ((arrayOfRational == null) || (arrayOfRational.length < 1))
      return paramRational;
    return arrayOfRational[0];
  }

  public Rational[] getValueAsRationals()
  {
    if ((this.mValue instanceof Rational[]))
      return (Rational[])this.mValue;
    return null;
  }

  public String getValueAsString()
  {
    if (this.mValue == null);
    do
    {
      return null;
      if ((this.mValue instanceof String))
        return (String)this.mValue;
    }
    while (!(this.mValue instanceof byte[]));
    return new String((byte[])this.mValue, US_ASCII);
  }

  public String getValueAsString(String paramString)
  {
    String str = getValueAsString();
    if (str == null)
      return paramString;
    return str;
  }

  protected long getValueAt(int paramInt)
  {
    if ((this.mValue instanceof long[]))
      return ((long[])this.mValue)[paramInt];
    if ((this.mValue instanceof byte[]))
      return ((byte[])this.mValue)[paramInt];
    throw new IllegalArgumentException("Cannot get integer value from " + convertTypeToString(this.mDataType));
  }

  protected boolean hasDefinedCount()
  {
    return this.mHasDefinedDefaultComponentCount;
  }

  public boolean hasValue()
  {
    return this.mValue != null;
  }

  protected void setHasDefinedCount(boolean paramBoolean)
  {
    this.mHasDefinedDefaultComponentCount = paramBoolean;
  }

  protected void setIfd(int paramInt)
  {
    this.mIfd = paramInt;
  }

  protected void setOffset(int paramInt)
  {
    this.mOffset = paramInt;
  }

  public boolean setTimeValue(long paramLong)
  {
    synchronized (TIME_FORMAT)
    {
      boolean bool = setValue(TIME_FORMAT.format(new Date(paramLong)));
      return bool;
    }
  }

  public boolean setValue(byte paramByte)
  {
    return setValue(new byte[] { paramByte });
  }

  public boolean setValue(int paramInt)
  {
    return setValue(new int[] { paramInt });
  }

  public boolean setValue(long paramLong)
  {
    return setValue(new long[] { paramLong });
  }

  public boolean setValue(Rational paramRational)
  {
    return setValue(new Rational[] { paramRational });
  }

  public boolean setValue(Object paramObject)
  {
    if (paramObject == null);
    do
    {
      return false;
      if ((paramObject instanceof Short))
        return setValue(0xFFFF & ((Short)paramObject).shortValue());
      if ((paramObject instanceof String))
        return setValue((String)paramObject);
      if ((paramObject instanceof int[]))
        return setValue((int[])paramObject);
      if ((paramObject instanceof long[]))
        return setValue((long[])paramObject);
      if ((paramObject instanceof Rational))
        return setValue((Rational)paramObject);
      if ((paramObject instanceof Rational[]))
        return setValue((Rational[])paramObject);
      if ((paramObject instanceof byte[]))
        return setValue((byte[])paramObject);
      if ((paramObject instanceof Integer))
        return setValue(((Integer)paramObject).intValue());
      if ((paramObject instanceof Long))
        return setValue(((Long)paramObject).longValue());
      if ((paramObject instanceof Byte))
        return setValue(((Byte)paramObject).byteValue());
      if ((paramObject instanceof Short[]))
      {
        Short[] arrayOfShort = (Short[])paramObject;
        int[] arrayOfInt2 = new int[arrayOfShort.length];
        int i1 = 0;
        if (i1 >= arrayOfShort.length)
          return setValue(arrayOfInt2);
        if (arrayOfShort[i1] == null);
        for (int i2 = 0; ; i2 = 0xFFFF & arrayOfShort[i1].shortValue())
        {
          arrayOfInt2[i1] = i2;
          i1++;
          break;
        }
      }
      if ((paramObject instanceof Integer[]))
      {
        Integer[] arrayOfInteger = (Integer[])paramObject;
        int[] arrayOfInt1 = new int[arrayOfInteger.length];
        int m = 0;
        if (m >= arrayOfInteger.length)
          return setValue(arrayOfInt1);
        if (arrayOfInteger[m] == null);
        for (int n = 0; ; n = arrayOfInteger[m].intValue())
        {
          arrayOfInt1[m] = n;
          m++;
          break;
        }
      }
      if ((paramObject instanceof Long[]))
      {
        Long[] arrayOfLong = (Long[])paramObject;
        long[] arrayOfLong1 = new long[arrayOfLong.length];
        int k = 0;
        if (k >= arrayOfLong.length)
          return setValue(arrayOfLong1);
        if (arrayOfLong[k] == null);
        for (long l = 0L; ; l = arrayOfLong[k].longValue())
        {
          arrayOfLong1[k] = l;
          k++;
          break;
        }
      }
    }
    while (!(paramObject instanceof Byte[]));
    Byte[] arrayOfByte = (Byte[])paramObject;
    byte[] arrayOfByte1 = new byte[arrayOfByte.length];
    int i = 0;
    if (i >= arrayOfByte.length)
      return setValue(arrayOfByte1);
    if (arrayOfByte[i] == null);
    for (int j = 0; ; j = arrayOfByte[i].byteValue())
    {
      arrayOfByte1[i] = j;
      i++;
      break;
    }
  }

  public boolean setValue(String paramString)
  {
    if ((this.mDataType != 2) && (this.mDataType != 7))
      return false;
    byte[] arrayOfByte1 = paramString.getBytes(US_ASCII);
    byte[] arrayOfByte2 = arrayOfByte1;
    if (arrayOfByte1.length > 0)
      if ((arrayOfByte1[(-1 + arrayOfByte1.length)] == 0) || (this.mDataType == 7))
        arrayOfByte2 = arrayOfByte1;
    while (true)
    {
      int i = arrayOfByte2.length;
      if (checkBadComponentCount(i))
        break;
      this.mComponentCountActual = i;
      this.mValue = arrayOfByte2;
      return true;
      arrayOfByte2 = Arrays.copyOf(arrayOfByte1, 1 + arrayOfByte1.length);
      continue;
      if ((this.mDataType == 2) && (this.mComponentCountActual == 1))
        arrayOfByte2 = new byte[1];
    }
  }

  public boolean setValue(byte[] paramArrayOfByte)
  {
    return setValue(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public boolean setValue(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if (checkBadComponentCount(paramInt2));
    while ((this.mDataType != 1) && (this.mDataType != 7))
      return false;
    this.mValue = new byte[paramInt2];
    System.arraycopy(paramArrayOfByte, paramInt1, this.mValue, 0, paramInt2);
    this.mComponentCountActual = paramInt2;
    return true;
  }

  public boolean setValue(int[] paramArrayOfInt)
  {
    if (checkBadComponentCount(paramArrayOfInt.length));
    while (((this.mDataType != 3) && (this.mDataType != 9) && (this.mDataType != 4)) || ((this.mDataType == 3) && (checkOverflowForUnsignedShort(paramArrayOfInt))) || ((this.mDataType == 4) && (checkOverflowForUnsignedLong(paramArrayOfInt))))
      return false;
    long[] arrayOfLong = new long[paramArrayOfInt.length];
    for (int i = 0; ; i++)
    {
      if (i >= paramArrayOfInt.length)
      {
        this.mValue = arrayOfLong;
        this.mComponentCountActual = paramArrayOfInt.length;
        return true;
      }
      arrayOfLong[i] = paramArrayOfInt[i];
    }
  }

  public boolean setValue(long[] paramArrayOfLong)
  {
    if ((checkBadComponentCount(paramArrayOfLong.length)) || (this.mDataType != 4));
    while (checkOverflowForUnsignedLong(paramArrayOfLong))
      return false;
    this.mValue = paramArrayOfLong;
    this.mComponentCountActual = paramArrayOfLong.length;
    return true;
  }

  public boolean setValue(Rational[] paramArrayOfRational)
  {
    if (checkBadComponentCount(paramArrayOfRational.length));
    while (((this.mDataType != 5) && (this.mDataType != 10)) || ((this.mDataType == 5) && (checkOverflowForUnsignedRational(paramArrayOfRational))) || ((this.mDataType == 10) && (checkOverflowForRational(paramArrayOfRational))))
      return false;
    this.mValue = paramArrayOfRational;
    this.mComponentCountActual = paramArrayOfRational.length;
    return true;
  }

  public String toString()
  {
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = Short.valueOf(this.mTagId);
    return String.format("tag id: %04X\n", arrayOfObject) + "ifd id: " + this.mIfd + "\ntype: " + convertTypeToString(this.mDataType) + "\ncount: " + this.mComponentCountActual + "\noffset: " + this.mOffset + "\nvalue: " + forceGetValueAsString() + "\n";
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.android.mms.exif.ExifTag
 * JD-Core Version:    0.6.2
 */