package com.google.android.gms.cast;

import android.content.Context;
import android.os.RemoteException;
import android.text.TextUtils;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ApiOptions;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.a.a;
import com.google.android.gms.internal.dg;
import com.google.android.gms.internal.dt;
import com.google.android.gms.internal.eg;
import java.io.IOException;

public final class Cast
{
  public static final Api API = new Api(jO, new Scope[0]);
  public static final CastApi CastApi = new Cast.CastApi.a();
  public static final String EXTRA_APP_NO_LONGER_RUNNING = "com.google.android.gms.cast.EXTRA_APP_NO_LONGER_RUNNING";
  public static final int MAX_MESSAGE_LENGTH = 65536;
  public static final int MAX_NAMESPACE_LENGTH = 128;
  static final Api.b<dg> jO = new Api.b()
  {
    public dg c(Context paramAnonymousContext, dt paramAnonymousdt, GoogleApiClient.ApiOptions paramAnonymousApiOptions, GoogleApiClient.ConnectionCallbacks paramAnonymousConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener paramAnonymousOnConnectionFailedListener)
    {
      eg.b(paramAnonymousApiOptions, "Setting the API options is required.");
      eg.b(paramAnonymousApiOptions instanceof Cast.CastOptions, "Must provide valid CastOptions!");
      Cast.CastOptions localCastOptions = (Cast.CastOptions)paramAnonymousApiOptions;
      return new dg(paramAnonymousContext, localCastOptions.ks, Cast.CastOptions.a(localCastOptions), localCastOptions.kt, paramAnonymousConnectionCallbacks, paramAnonymousOnConnectionFailedListener);
    }

    public int getPriority()
    {
      return 2147483647;
    }
  };

  public static abstract interface ApplicationConnectionResult extends Result
  {
    public abstract ApplicationMetadata getApplicationMetadata();

    public abstract String getApplicationStatus();

    public abstract String getSessionId();

    public abstract boolean getWasLaunched();
  }

  public static abstract interface CastApi
  {
    public abstract ApplicationMetadata getApplicationMetadata(GoogleApiClient paramGoogleApiClient)
      throws IllegalStateException;

    public abstract String getApplicationStatus(GoogleApiClient paramGoogleApiClient)
      throws IllegalStateException;

    public abstract double getVolume(GoogleApiClient paramGoogleApiClient)
      throws IllegalStateException;

    public abstract boolean isMute(GoogleApiClient paramGoogleApiClient)
      throws IllegalStateException;

    public abstract PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient paramGoogleApiClient);

    public abstract PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient paramGoogleApiClient, String paramString);

    public abstract PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient paramGoogleApiClient, String paramString1, String paramString2);

    public abstract PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient paramGoogleApiClient, String paramString);

    public abstract PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient paramGoogleApiClient, String paramString, boolean paramBoolean);

    public abstract PendingResult<Status> leaveApplication(GoogleApiClient paramGoogleApiClient);

    public abstract void removeMessageReceivedCallbacks(GoogleApiClient paramGoogleApiClient, String paramString)
      throws IOException, IllegalStateException;

    public abstract void requestStatus(GoogleApiClient paramGoogleApiClient)
      throws IOException, IllegalStateException;

    public abstract PendingResult<Status> sendMessage(GoogleApiClient paramGoogleApiClient, String paramString1, String paramString2);

    public abstract void setMessageReceivedCallbacks(GoogleApiClient paramGoogleApiClient, String paramString, Cast.MessageReceivedCallback paramMessageReceivedCallback)
      throws IOException, IllegalStateException;

    public abstract void setMute(GoogleApiClient paramGoogleApiClient, boolean paramBoolean)
      throws IOException, IllegalStateException;

    public abstract void setVolume(GoogleApiClient paramGoogleApiClient, double paramDouble)
      throws IOException, IllegalArgumentException, IllegalStateException;

    public abstract PendingResult<Status> stopApplication(GoogleApiClient paramGoogleApiClient);

    public abstract PendingResult<Status> stopApplication(GoogleApiClient paramGoogleApiClient, String paramString);

    public static final class a
      implements Cast.CastApi
    {
      public ApplicationMetadata getApplicationMetadata(GoogleApiClient paramGoogleApiClient)
        throws IllegalStateException
      {
        return ((dg)paramGoogleApiClient.a(Cast.jO)).getApplicationMetadata();
      }

      public String getApplicationStatus(GoogleApiClient paramGoogleApiClient)
        throws IllegalStateException
      {
        return ((dg)paramGoogleApiClient.a(Cast.jO)).getApplicationStatus();
      }

      public double getVolume(GoogleApiClient paramGoogleApiClient)
        throws IllegalStateException
      {
        return ((dg)paramGoogleApiClient.a(Cast.jO)).aW();
      }

      public boolean isMute(GoogleApiClient paramGoogleApiClient)
        throws IllegalStateException
      {
        return ((dg)paramGoogleApiClient.a(Cast.jO)).isMute();
      }

      public PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient paramGoogleApiClient)
      {
        // Byte code:
        //   0: aload_1
        //   1: new 51	com/google/android/gms/cast/Cast$CastApi$a$6
        //   4: dup
        //   5: aload_0
        //   6: invokespecial 54	com/google/android/gms/cast/Cast$CastApi$a$6:<init>	(Lcom/google/android/gms/cast/Cast$CastApi$a;)V
        //   9: invokevirtual 58	com/google/android/gms/common/api/GoogleApiClient:b	(Lcom/google/android/gms/common/api/a$a;)Lcom/google/android/gms/common/api/a$a;
        //   12: areturn
      }

      public PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient paramGoogleApiClient, final String paramString)
      {
        return paramGoogleApiClient.b(new Cast.c(paramString)
        {
          protected void a(dg paramAnonymousdg)
          {
            try
            {
              paramAnonymousdg.b(paramString, null, this);
              return;
            }
            catch (IllegalStateException localIllegalStateException)
            {
              r(2001);
              return;
            }
            catch (RemoteException localRemoteException)
            {
              r(8);
            }
          }
        });
      }

      public PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient paramGoogleApiClient, final String paramString1, final String paramString2)
      {
        return paramGoogleApiClient.b(new Cast.c(paramString1)
        {
          protected void a(dg paramAnonymousdg)
          {
            try
            {
              paramAnonymousdg.b(paramString1, paramString2, this);
              return;
            }
            catch (IllegalStateException localIllegalStateException)
            {
              r(2001);
              return;
            }
            catch (RemoteException localRemoteException)
            {
              r(8);
            }
          }
        });
      }

      public PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient paramGoogleApiClient, final String paramString)
      {
        return paramGoogleApiClient.b(new Cast.c(paramString)
        {
          protected void a(dg paramAnonymousdg)
          {
            try
            {
              paramAnonymousdg.a(paramString, false, this);
              return;
            }
            catch (IllegalStateException localIllegalStateException)
            {
              r(2001);
              return;
            }
            catch (RemoteException localRemoteException)
            {
              r(8);
            }
          }
        });
      }

      public PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient paramGoogleApiClient, final String paramString, final boolean paramBoolean)
      {
        return paramGoogleApiClient.b(new Cast.c(paramString)
        {
          protected void a(dg paramAnonymousdg)
          {
            try
            {
              paramAnonymousdg.a(paramString, paramBoolean, this);
              return;
            }
            catch (IllegalStateException localIllegalStateException)
            {
              r(2001);
              return;
            }
            catch (RemoteException localRemoteException)
            {
              r(8);
            }
          }
        });
      }

      public PendingResult<Status> leaveApplication(GoogleApiClient paramGoogleApiClient)
      {
        // Byte code:
        //   0: aload_1
        //   1: new 83	com/google/android/gms/cast/Cast$CastApi$a$7
        //   4: dup
        //   5: aload_0
        //   6: invokespecial 84	com/google/android/gms/cast/Cast$CastApi$a$7:<init>	(Lcom/google/android/gms/cast/Cast$CastApi$a;)V
        //   9: invokevirtual 58	com/google/android/gms/common/api/GoogleApiClient:b	(Lcom/google/android/gms/common/api/a$a;)Lcom/google/android/gms/common/api/a$a;
        //   12: areturn
      }

      public void removeMessageReceivedCallbacks(GoogleApiClient paramGoogleApiClient, String paramString)
        throws IOException, IllegalStateException
      {
        try
        {
          ((dg)paramGoogleApiClient.a(Cast.jO)).C(paramString);
          return;
        }
        catch (RemoteException localRemoteException)
        {
        }
        throw new IOException("service error");
      }

      public void requestStatus(GoogleApiClient paramGoogleApiClient)
        throws IOException, IllegalStateException
      {
        try
        {
          ((dg)paramGoogleApiClient.a(Cast.jO)).aV();
          return;
        }
        catch (RemoteException localRemoteException)
        {
        }
        throw new IOException("service error");
      }

      public PendingResult<Status> sendMessage(GoogleApiClient paramGoogleApiClient, final String paramString1, final String paramString2)
      {
        return paramGoogleApiClient.b(new Cast.b(paramString1)
        {
          protected void a(dg paramAnonymousdg)
          {
            try
            {
              paramAnonymousdg.a(paramString1, paramString2, this);
              return;
            }
            catch (IllegalArgumentException localIllegalArgumentException)
            {
              r(2001);
              return;
            }
            catch (IllegalStateException localIllegalStateException)
            {
              r(2001);
              return;
            }
            catch (RemoteException localRemoteException)
            {
              r(8);
            }
          }
        });
      }

      public void setMessageReceivedCallbacks(GoogleApiClient paramGoogleApiClient, String paramString, Cast.MessageReceivedCallback paramMessageReceivedCallback)
        throws IOException, IllegalStateException
      {
        try
        {
          ((dg)paramGoogleApiClient.a(Cast.jO)).a(paramString, paramMessageReceivedCallback);
          return;
        }
        catch (RemoteException localRemoteException)
        {
        }
        throw new IOException("service error");
      }

      public void setMute(GoogleApiClient paramGoogleApiClient, boolean paramBoolean)
        throws IOException, IllegalStateException
      {
        try
        {
          ((dg)paramGoogleApiClient.a(Cast.jO)).n(paramBoolean);
          return;
        }
        catch (RemoteException localRemoteException)
        {
        }
        throw new IOException("service error");
      }

      public void setVolume(GoogleApiClient paramGoogleApiClient, double paramDouble)
        throws IOException, IllegalArgumentException, IllegalStateException
      {
        try
        {
          ((dg)paramGoogleApiClient.a(Cast.jO)).a(paramDouble);
          return;
        }
        catch (RemoteException localRemoteException)
        {
        }
        throw new IOException("service error");
      }

      public PendingResult<Status> stopApplication(GoogleApiClient paramGoogleApiClient)
      {
        // Byte code:
        //   0: aload_1
        //   1: new 128	com/google/android/gms/cast/Cast$CastApi$a$8
        //   4: dup
        //   5: aload_0
        //   6: invokespecial 129	com/google/android/gms/cast/Cast$CastApi$a$8:<init>	(Lcom/google/android/gms/cast/Cast$CastApi$a;)V
        //   9: invokevirtual 58	com/google/android/gms/common/api/GoogleApiClient:b	(Lcom/google/android/gms/common/api/a$a;)Lcom/google/android/gms/common/api/a$a;
        //   12: areturn
      }

      public PendingResult<Status> stopApplication(GoogleApiClient paramGoogleApiClient, final String paramString)
      {
        return paramGoogleApiClient.b(new Cast.b(paramString)
        {
          protected void a(dg paramAnonymousdg)
          {
            if (TextUtils.isEmpty(paramString))
            {
              c(2001, "IllegalArgument: sessionId cannot be null or empty");
              return;
            }
            try
            {
              paramAnonymousdg.a(paramString, this);
              return;
            }
            catch (IllegalStateException localIllegalStateException)
            {
              r(2001);
              return;
            }
            catch (RemoteException localRemoteException)
            {
              r(8);
            }
          }
        });
      }
    }
  }

  public static final class CastOptions
    implements GoogleApiClient.ApiOptions
  {
    final CastDevice ks;
    final Cast.Listener kt;
    private final int ku;

    private CastOptions(Builder paramBuilder)
    {
      this.ks = paramBuilder.kv;
      this.kt = paramBuilder.kw;
      this.ku = Builder.a(paramBuilder);
    }

    public static Builder builder(CastDevice paramCastDevice, Cast.Listener paramListener)
    {
      return new Builder(paramCastDevice, paramListener, null);
    }

    public static final class Builder
    {
      CastDevice kv;
      Cast.Listener kw;
      private int kx;

      private Builder(CastDevice paramCastDevice, Cast.Listener paramListener)
      {
        this.kv = paramCastDevice;
        this.kw = paramListener;
        this.kx = 0;
      }

      public Cast.CastOptions build()
      {
        return new Cast.CastOptions(this, null);
      }

      public Builder setDebuggingEnabled()
      {
        this.kx = (0x1 | this.kx);
        return this;
      }
    }
  }

  public static abstract class Listener
  {
    public void onApplicationDisconnected(int paramInt)
    {
    }

    public void onApplicationStatusChanged()
    {
    }

    public void onVolumeChanged()
    {
    }
  }

  public static abstract interface MessageReceivedCallback
  {
    public abstract void onMessageReceived(CastDevice paramCastDevice, String paramString1, String paramString2);
  }

  protected static abstract class a<R extends Result> extends a.a<R, dg>
    implements PendingResult<R>
  {
    public a()
    {
      super();
    }

    public void c(int paramInt, String paramString)
    {
      a(e(new Status(paramInt, paramString, null)));
    }

    public void r(int paramInt)
    {
      a(e(new Status(paramInt)));
    }
  }

  private static abstract class b extends Cast.a<Status>
  {
    public Status g(Status paramStatus)
    {
      return paramStatus;
    }
  }

  private static abstract class c extends Cast.a<Cast.ApplicationConnectionResult>
  {
    public Cast.ApplicationConnectionResult i(final Status paramStatus)
    {
      return new Cast.ApplicationConnectionResult()
      {
        public ApplicationMetadata getApplicationMetadata()
        {
          return null;
        }

        public String getApplicationStatus()
        {
          return null;
        }

        public String getSessionId()
        {
          return null;
        }

        public Status getStatus()
        {
          return paramStatus;
        }

        public boolean getWasLaunched()
        {
          return false;
        }
      };
    }
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.cast.Cast
 * JD-Core Version:    0.6.2
 */