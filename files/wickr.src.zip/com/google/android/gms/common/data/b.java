package com.google.android.gms.common.data;

import android.database.CharArrayBuffer;
import android.net.Uri;
import com.google.android.gms.internal.ee;
import com.google.android.gms.internal.eg;

public abstract class b
{
  protected final DataHolder nE;
  protected final int nG;
  private final int nH;

  public b(DataHolder paramDataHolder, int paramInt)
  {
    this.nE = ((DataHolder)eg.f(paramDataHolder));
    if ((paramInt >= 0) && (paramInt < paramDataHolder.getCount()));
    for (boolean bool = true; ; bool = false)
    {
      eg.p(bool);
      this.nG = paramInt;
      this.nH = paramDataHolder.C(this.nG);
      return;
    }
  }

  protected Uri L(String paramString)
  {
    return this.nE.parseUri(paramString, this.nG, this.nH);
  }

  protected boolean M(String paramString)
  {
    return this.nE.hasNull(paramString, this.nG, this.nH);
  }

  protected void a(String paramString, CharArrayBuffer paramCharArrayBuffer)
  {
    this.nE.copyToBuffer(paramString, this.nG, this.nH, paramCharArrayBuffer);
  }

  public boolean equals(Object paramObject)
  {
    boolean bool1 = paramObject instanceof b;
    boolean bool2 = false;
    if (bool1)
    {
      b localb = (b)paramObject;
      boolean bool3 = ee.equal(Integer.valueOf(localb.nG), Integer.valueOf(this.nG));
      bool2 = false;
      if (bool3)
      {
        boolean bool4 = ee.equal(Integer.valueOf(localb.nH), Integer.valueOf(this.nH));
        bool2 = false;
        if (bool4)
        {
          DataHolder localDataHolder1 = localb.nE;
          DataHolder localDataHolder2 = this.nE;
          bool2 = false;
          if (localDataHolder1 == localDataHolder2)
            bool2 = true;
        }
      }
    }
    return bool2;
  }

  protected boolean getBoolean(String paramString)
  {
    return this.nE.getBoolean(paramString, this.nG, this.nH);
  }

  protected byte[] getByteArray(String paramString)
  {
    return this.nE.getByteArray(paramString, this.nG, this.nH);
  }

  protected int getInteger(String paramString)
  {
    return this.nE.getInteger(paramString, this.nG, this.nH);
  }

  protected long getLong(String paramString)
  {
    return this.nE.getLong(paramString, this.nG, this.nH);
  }

  protected String getString(String paramString)
  {
    return this.nE.getString(paramString, this.nG, this.nH);
  }

  public boolean hasColumn(String paramString)
  {
    return this.nE.hasColumn(paramString);
  }

  public int hashCode()
  {
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = Integer.valueOf(this.nG);
    arrayOfObject[1] = Integer.valueOf(this.nH);
    arrayOfObject[2] = this.nE;
    return ee.hashCode(arrayOfObject);
  }

  public boolean isDataValid()
  {
    return !this.nE.isClosed();
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.data.b
 * JD-Core Version:    0.6.2
 */