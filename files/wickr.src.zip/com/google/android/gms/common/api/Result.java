package com.google.android.gms.common.api;

public abstract interface Result
{
  public abstract Status getStatus();
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.Result
 * JD-Core Version:    0.6.2
 */