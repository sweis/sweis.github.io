package com.google.android.gms.common.api;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.util.Pair;
import com.google.android.gms.internal.eg;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class a
{
  public static abstract class a<R extends Result, A extends Api.a>
    implements GoogleApiClient.b<A>, PendingResult<R>, a.c<R>
  {
    private final Api.b<A> mU;
    private final Object mV = new Object();
    private final a.b<R> mW;
    private final CountDownLatch mX = new CountDownLatch(1);
    private final ArrayList<PendingResult.a> mY = new ArrayList();
    private ResultCallback<R> mZ;
    private R na;
    private boolean nb;
    private GoogleApiClient.a nc;

    public a(Api.b<A> paramb)
    {
      this.mU = paramb;
      this.mW = new a.b()
      {
        protected void a(ResultCallback<R> paramAnonymousResultCallback, R paramAnonymousR)
        {
          paramAnonymousResultCallback.onResult(paramAnonymousR);
        }
      };
    }

    private R bl()
    {
      while (true)
      {
        synchronized (this.mV)
        {
          if (!this.nb)
          {
            bool = true;
            eg.a(bool, "Result has already been consumed.");
            eg.a(isReady(), "Result is not ready.");
            Result localResult = this.na;
            bm();
            return localResult;
          }
        }
        boolean bool = false;
      }
    }

    protected abstract void a(A paramA);

    public void a(GoogleApiClient.a parama)
    {
      this.nc = parama;
    }

    public final void a(R paramR)
    {
      boolean bool1 = true;
      boolean bool2;
      if (!isReady())
      {
        bool2 = bool1;
        eg.a(bool2, "Results have already been set");
        if (this.nb)
          break label136;
      }
      while (true)
      {
        eg.a(bool1, "Result has already been consumed");
        synchronized (this.mV)
        {
          this.na = paramR;
          this.mX.countDown();
          Status localStatus = this.na.getStatus();
          if (this.mZ != null)
            this.mW.b(this.mZ, bl());
          Iterator localIterator = this.mY.iterator();
          if (!localIterator.hasNext())
            break label141;
          ((PendingResult.a)localIterator.next()).l(localStatus);
        }
        bool2 = false;
        break;
        label136: bool1 = false;
      }
      label141: this.mY.clear();
    }

    public final R await()
    {
      boolean bool;
      if (!this.nb)
        bool = true;
      while (true)
      {
        eg.a(bool, "Results has already been consumed");
        try
        {
          this.mX.await();
          eg.a(isReady(), "Result is not ready.");
          return bl();
          bool = false;
        }
        catch (InterruptedException localInterruptedException)
        {
          while (true)
            a(e(Status.nB));
        }
      }
    }

    public final R await(long paramLong, TimeUnit paramTimeUnit)
    {
      boolean bool;
      if (!this.nb)
        bool = true;
      while (true)
      {
        eg.a(bool, "Result has already been consumed.");
        try
        {
          if (!this.mX.await(paramLong, paramTimeUnit))
            a(e(Status.nC));
          eg.a(isReady(), "Result is not ready.");
          return bl();
          bool = false;
        }
        catch (InterruptedException localInterruptedException)
        {
          while (true)
            a(e(Status.nB));
        }
      }
    }

    public final void b(A paramA)
    {
      a(paramA);
    }

    public final Api.b<A> bj()
    {
      return this.mU;
    }

    void bm()
    {
      this.nb = true;
      this.na = null;
      if (this.nc != null)
        this.nc.b(this);
    }

    public final boolean isReady()
    {
      return this.mX.getCount() == 0L;
    }

    public final void setResultCallback(ResultCallback<R> paramResultCallback)
    {
      if (!this.nb);
      for (boolean bool = true; ; bool = false)
      {
        eg.a(bool, "Result has already been consumed.");
        synchronized (this.mV)
        {
          if (isReady())
          {
            this.mW.b(paramResultCallback, bl());
            return;
          }
          this.mZ = paramResultCallback;
        }
      }
    }
  }

  static abstract class b<R extends Result> extends Handler
  {
    public b()
    {
      this(Looper.getMainLooper());
    }

    public b(Looper paramLooper)
    {
      super();
    }

    protected abstract void a(ResultCallback<R> paramResultCallback, R paramR);

    public void b(ResultCallback<R> paramResultCallback, R paramR)
    {
      sendMessage(obtainMessage(1, new Pair(paramResultCallback, paramR)));
    }

    public void handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default:
        Log.wtf("GoogleApi", "Don't know how to handle this message.");
        return;
      case 1:
      }
      Pair localPair = (Pair)paramMessage.obj;
      a((ResultCallback)localPair.first, (Result)localPair.second);
    }
  }

  public static abstract interface c<R>
  {
    public abstract void a(R paramR);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.a
 * JD-Core Version:    0.6.2
 */