package com.google.android.gms.common.api;

import java.util.concurrent.TimeUnit;

public abstract interface PendingResult<R extends Result>
{
  public abstract R await();

  public abstract R await(long paramLong, TimeUnit paramTimeUnit);

  public abstract R e(Status paramStatus);

  public abstract void setResultCallback(ResultCallback<R> paramResultCallback);

  public static abstract interface a
  {
    public abstract void l(Status paramStatus);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.PendingResult
 * JD-Core Version:    0.6.2
 */