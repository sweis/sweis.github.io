package com.google.android.gms.common.api;

public final class Scope
{
  private final String nz;

  public Scope(String paramString)
  {
    this.nz = paramString;
  }

  public String br()
  {
    return this.nz;
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.Scope
 * JD-Core Version:    0.6.2
 */