package com.google.android.gms.common;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import com.google.android.gms.R.string;
import com.google.android.gms.internal.du;
import com.google.android.gms.internal.dz;
import com.google.android.gms.internal.fg;
import java.io.UnsupportedEncodingException;

public final class GooglePlayServicesUtil
{
  public static final String GOOGLE_PLAY_SERVICES_PACKAGE = "com.google.android.gms";
  public static final int GOOGLE_PLAY_SERVICES_VERSION_CODE = 4242000;
  public static final String GOOGLE_PLAY_STORE_PACKAGE = "com.android.vending";
  static final byte[][] mD;
  static final byte[][] mE;
  static final byte[][] mF;
  static final byte[][] mG;
  private static final byte[][] mH;
  private static final byte[][] mI;
  static final byte[][] mJ = arrayOfByte6;
  public static boolean mK = false;
  public static boolean mL = false;
  static boolean mM = false;
  private static int mN = -1;
  private static final Object mO = new Object();

  static
  {
    byte[][] arrayOfByte1 = new byte[2][];
    arrayOfByte1[0] = K("");
    arrayOfByte1[1] = K("");
    mD = arrayOfByte1;
    byte[][] arrayOfByte2 = new byte[2][];
    arrayOfByte2[0] = K("");
    arrayOfByte2[1] = K("");
    mE = arrayOfByte2;
    byte[][] arrayOfByte3 = new byte[1][];
    arrayOfByte3[0] = K("");
    mF = arrayOfByte3;
    byte[][] arrayOfByte4 = new byte[2][];
    arrayOfByte4[0] = K("");
    arrayOfByte4[1] = K("");
    mG = arrayOfByte4;
    byte[][][] arrayOfByte = new byte[4][][];
    arrayOfByte[0] = mD;
    arrayOfByte[1] = mE;
    arrayOfByte[2] = mF;
    arrayOfByte[3] = mG;
    mH = a(arrayOfByte);
    byte[][] arrayOfByte5 = new byte[3][];
    arrayOfByte5[0] = mD[0];
    arrayOfByte5[1] = mE[0];
    arrayOfByte5[2] = mG[0];
    mI = arrayOfByte5;
    byte[][] arrayOfByte6 = new byte[1][];
    arrayOfByte6[0] = K("");
  }

  private static byte[] K(String paramString)
  {
    try
    {
      byte[] arrayOfByte = paramString.getBytes("ISO-8859-1");
      return arrayOfByte;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      throw new AssertionError(localUnsupportedEncodingException);
    }
  }

  public static Dialog a(int paramInt1, Activity paramActivity, int paramInt2, DialogInterface.OnCancelListener paramOnCancelListener, int paramInt3)
  {
    AlertDialog.Builder localBuilder = new AlertDialog.Builder(paramActivity).setMessage(b(paramActivity, paramInt1, paramInt3));
    if (paramOnCancelListener != null)
      localBuilder.setOnCancelListener(paramOnCancelListener);
    du localdu = new du(paramActivity, a(paramActivity, paramInt1, paramInt3), paramInt2);
    String str = b(paramActivity, paramInt1);
    if (str != null)
      localBuilder.setPositiveButton(str, localdu);
    switch (paramInt1)
    {
    default:
      Log.e("GooglePlayServicesUtil", "Unexpected error code " + paramInt1);
      return localBuilder.create();
    case 0:
      return null;
    case 4:
    case 6:
      return localBuilder.create();
    case 1:
      return localBuilder.setTitle(R.string.common_google_play_services_install_title).create();
    case 3:
      return localBuilder.setTitle(R.string.common_google_play_services_enable_title).create();
    case 2:
      return localBuilder.setTitle(R.string.common_google_play_services_update_title).create();
    case 9:
      Log.e("GooglePlayServicesUtil", "Google Play services is invalid. Cannot recover.");
      return localBuilder.setTitle(R.string.common_google_play_services_unsupported_title).create();
    case 7:
      Log.e("GooglePlayServicesUtil", "Network error occurred. Please retry request later.");
      return localBuilder.setTitle(R.string.common_google_play_services_network_error_title).create();
    case 8:
      Log.e("GooglePlayServicesUtil", "Internal error occurred. Please see logs for detailed information");
      return localBuilder.create();
    case 10:
      Log.e("GooglePlayServicesUtil", "Developer error occurred. Please see logs for detailed information");
      return localBuilder.create();
    case 5:
      Log.e("GooglePlayServicesUtil", "An invalid account was specified when connecting. Please provide a valid account.");
      return localBuilder.setTitle(R.string.common_google_play_services_invalid_account_title).create();
    case 11:
      Log.e("GooglePlayServicesUtil", "The application is not licensed to the user.");
      return localBuilder.create();
    case 12:
    }
    Log.e("GooglePlayServicesUtil", "The date of the device is not valid.");
    return localBuilder.setTitle(R.string.common_google_play_services_unsupported_title).create();
  }

  public static Intent a(Context paramContext, int paramInt1, int paramInt2)
  {
    switch (paramInt1)
    {
    default:
      return null;
    case 1:
    case 2:
      if (y(paramInt2))
      {
        if (o(paramContext))
          return dz.T("com.google.android.gms");
        return dz.S("com.google.android.apps.bazaar");
      }
      return dz.S("com.google.android.gms");
    case 3:
      return dz.Q("com.google.android.gms");
    case 12:
    }
    return dz.bX();
  }

  public static boolean a(Resources paramResources)
  {
    if (paramResources == null);
    while (true)
    {
      return false;
      if ((0xF & paramResources.getConfiguration().screenLayout) > 3);
      for (int i = 1; ((fg.cD()) && (i != 0)) || (b(paramResources)); i = 0)
        return true;
    }
  }

  // ERROR //
  private static byte[] a(PackageInfo paramPackageInfo, byte[][] paramArrayOfByte)
  {
    // Byte code:
    //   0: ldc 253
    //   2: invokestatic 259	java/security/cert/CertificateFactory:getInstance	(Ljava/lang/String;)Ljava/security/cert/CertificateFactory;
    //   5: astore 4
    //   7: aload_0
    //   8: getfield 265	android/content/pm/PackageInfo:signatures	[Landroid/content/pm/Signature;
    //   11: arraylength
    //   12: iconst_1
    //   13: if_icmpeq +26 -> 39
    //   16: ldc 134
    //   18: ldc_w 267
    //   21: invokestatic 270	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   24: pop
    //   25: aconst_null
    //   26: areturn
    //   27: astore_2
    //   28: ldc 134
    //   30: ldc_w 272
    //   33: invokestatic 270	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   36: pop
    //   37: aconst_null
    //   38: areturn
    //   39: new 274	java/io/ByteArrayInputStream
    //   42: dup
    //   43: aload_0
    //   44: getfield 265	android/content/pm/PackageInfo:signatures	[Landroid/content/pm/Signature;
    //   47: iconst_0
    //   48: aaload
    //   49: invokevirtual 280	android/content/pm/Signature:toByteArray	()[B
    //   52: invokespecial 283	java/io/ByteArrayInputStream:<init>	([B)V
    //   55: astore 5
    //   57: aload 4
    //   59: aload 5
    //   61: invokevirtual 287	java/security/cert/CertificateFactory:generateCertificate	(Ljava/io/InputStream;)Ljava/security/cert/Certificate;
    //   64: checkcast 289	java/security/cert/X509Certificate
    //   67: astore 8
    //   69: aload 8
    //   71: invokevirtual 292	java/security/cert/X509Certificate:checkValidity	()V
    //   74: aload_0
    //   75: getfield 265	android/content/pm/PackageInfo:signatures	[Landroid/content/pm/Signature;
    //   78: iconst_0
    //   79: aaload
    //   80: invokevirtual 280	android/content/pm/Signature:toByteArray	()[B
    //   83: astore 13
    //   85: iconst_0
    //   86: istore 14
    //   88: iload 14
    //   90: aload_1
    //   91: arraylength
    //   92: if_icmpge +67 -> 159
    //   95: aload_1
    //   96: iload 14
    //   98: aaload
    //   99: astore 16
    //   101: aload 16
    //   103: aload 13
    //   105: invokestatic 298	java/util/Arrays:equals	([B[B)Z
    //   108: ifeq +45 -> 153
    //   111: aload 16
    //   113: areturn
    //   114: astore 6
    //   116: ldc 134
    //   118: ldc_w 300
    //   121: invokestatic 270	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   124: pop
    //   125: aconst_null
    //   126: areturn
    //   127: astore 11
    //   129: ldc 134
    //   131: ldc_w 302
    //   134: invokestatic 270	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   137: pop
    //   138: aconst_null
    //   139: areturn
    //   140: astore 9
    //   142: ldc 134
    //   144: ldc_w 304
    //   147: invokestatic 270	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   150: pop
    //   151: aconst_null
    //   152: areturn
    //   153: iinc 14 1
    //   156: goto -68 -> 88
    //   159: ldc 134
    //   161: iconst_2
    //   162: invokestatic 308	android/util/Log:isLoggable	(Ljava/lang/String;I)Z
    //   165: ifeq +34 -> 199
    //   168: ldc 134
    //   170: new 136	java/lang/StringBuilder
    //   173: dup
    //   174: invokespecial 137	java/lang/StringBuilder:<init>	()V
    //   177: ldc_w 310
    //   180: invokevirtual 143	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   183: aload 13
    //   185: iconst_0
    //   186: invokestatic 316	android/util/Base64:encodeToString	([BI)Ljava/lang/String;
    //   189: invokevirtual 143	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   192: invokevirtual 150	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   195: invokestatic 319	android/util/Log:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   198: pop
    //   199: aconst_null
    //   200: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	7	27	java/security/cert/CertificateException
    //   57	69	114	java/security/cert/CertificateException
    //   69	74	127	java/security/cert/CertificateExpiredException
    //   69	74	140	java/security/cert/CertificateNotYetValidException
  }

  private static byte[][] a(byte[][][] paramArrayOfByte)
  {
    int i = paramArrayOfByte.length;
    int j = 0;
    int k = 0;
    while (j < i)
    {
      k += paramArrayOfByte[j].length;
      j++;
    }
    byte[][] arrayOfByte = new byte[k][];
    int m = paramArrayOfByte.length;
    int n = 0;
    int i2;
    for (int i1 = 0; n < m; i1 = i2)
    {
      byte[][] arrayOfByte1 = paramArrayOfByte[n];
      i2 = i1;
      int i3 = 0;
      while (i3 < arrayOfByte1.length)
      {
        int i4 = i2 + 1;
        arrayOfByte[i2] = arrayOfByte1[i3];
        i3++;
        i2 = i4;
      }
      n++;
    }
    return arrayOfByte;
  }

  public static String b(Context paramContext, int paramInt)
  {
    Resources localResources = paramContext.getResources();
    switch (paramInt)
    {
    default:
      return localResources.getString(17039370);
    case 1:
      return localResources.getString(R.string.common_google_play_services_install_button);
    case 3:
      return localResources.getString(R.string.common_google_play_services_enable_button);
    case 2:
    }
    return localResources.getString(R.string.common_google_play_services_update_button);
  }

  public static String b(Context paramContext, int paramInt1, int paramInt2)
  {
    Resources localResources = paramContext.getResources();
    String str;
    switch (paramInt1)
    {
    case 4:
    case 6:
    case 8:
    case 10:
    case 11:
    default:
      str = localResources.getString(R.string.common_google_play_services_unknown_issue);
    case 1:
    case 3:
    case 2:
      do
      {
        return str;
        if (a(paramContext.getResources()));
        for (str = localResources.getString(R.string.common_google_play_services_install_text_tablet); y(paramInt2); str = localResources.getString(R.string.common_google_play_services_install_text_phone))
          return str + " (via Bazaar)";
        return localResources.getString(R.string.common_google_play_services_enable_text);
        str = localResources.getString(R.string.common_google_play_services_update_text);
      }
      while (!y(paramInt2));
      return str + " (via Bazaar)";
    case 9:
      return localResources.getString(R.string.common_google_play_services_unsupported_text);
    case 7:
      return localResources.getString(R.string.common_google_play_services_network_error_text);
    case 5:
      return localResources.getString(R.string.common_google_play_services_invalid_account_text);
    case 12:
    }
    return localResources.getString(R.string.common_google_play_services_unsupported_date_text);
  }

  private static boolean b(Resources paramResources)
  {
    Configuration localConfiguration = paramResources.getConfiguration();
    boolean bool1 = fg.cF();
    boolean bool2 = false;
    if (bool1)
    {
      int i = 0xF & localConfiguration.screenLayout;
      bool2 = false;
      if (i <= 3)
      {
        int j = localConfiguration.smallestScreenWidthDp;
        bool2 = false;
        if (j >= 600)
          bool2 = true;
      }
    }
    return bool2;
  }

  public static boolean bi()
  {
    if (mK)
      return mL;
    return "user".equals(Build.TYPE);
  }

  public static Dialog getErrorDialog(int paramInt1, Activity paramActivity, int paramInt2)
  {
    return a(paramInt1, paramActivity, paramInt2, null, -1);
  }

  public static Dialog getErrorDialog(int paramInt1, Activity paramActivity, int paramInt2, DialogInterface.OnCancelListener paramOnCancelListener)
  {
    return a(paramInt1, paramActivity, paramInt2, paramOnCancelListener, -1);
  }

  public static PendingIntent getErrorPendingIntent(int paramInt1, Context paramContext, int paramInt2)
  {
    Intent localIntent = a(paramContext, paramInt1, -1);
    if (localIntent == null)
      return null;
    return PendingIntent.getActivity(paramContext, paramInt2, localIntent, 268435456);
  }

  public static String getErrorString(int paramInt)
  {
    switch (paramInt)
    {
    default:
      return "UNKNOWN_ERROR_CODE";
    case 0:
      return "SUCCESS";
    case 1:
      return "SERVICE_MISSING";
    case 2:
      return "SERVICE_VERSION_UPDATE_REQUIRED";
    case 3:
      return "SERVICE_DISABLED";
    case 4:
      return "SIGN_IN_REQUIRED";
    case 5:
      return "INVALID_ACCOUNT";
    case 6:
      return "RESOLUTION_REQUIRED";
    case 7:
      return "NETWORK_ERROR";
    case 8:
      return "INTERNAL_ERROR";
    case 9:
      return "SERVICE_INVALID";
    case 10:
      return "DEVELOPER_ERROR";
    case 11:
      return "LICENSE_CHECK_FAILED";
    case 12:
    }
    return "DATE_INVALID";
  }

  // ERROR //
  public static String getOpenSourceSoftwareLicenseInfo(Context paramContext)
  {
    // Byte code:
    //   0: new 438	android/net/Uri$Builder
    //   3: dup
    //   4: invokespecial 439	android/net/Uri$Builder:<init>	()V
    //   7: ldc_w 441
    //   10: invokevirtual 445	android/net/Uri$Builder:scheme	(Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   13: ldc 8
    //   15: invokevirtual 448	android/net/Uri$Builder:authority	(Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   18: ldc_w 450
    //   21: invokevirtual 453	android/net/Uri$Builder:appendPath	(Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   24: ldc_w 455
    //   27: invokevirtual 453	android/net/Uri$Builder:appendPath	(Ljava/lang/String;)Landroid/net/Uri$Builder;
    //   30: invokevirtual 459	android/net/Uri$Builder:build	()Landroid/net/Uri;
    //   33: astore_1
    //   34: aload_0
    //   35: invokevirtual 463	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   38: aload_1
    //   39: invokevirtual 469	android/content/ContentResolver:openInputStream	(Landroid/net/Uri;)Ljava/io/InputStream;
    //   42: astore 4
    //   44: new 471	java/util/Scanner
    //   47: dup
    //   48: aload 4
    //   50: invokespecial 474	java/util/Scanner:<init>	(Ljava/io/InputStream;)V
    //   53: ldc_w 476
    //   56: invokevirtual 480	java/util/Scanner:useDelimiter	(Ljava/lang/String;)Ljava/util/Scanner;
    //   59: invokevirtual 483	java/util/Scanner:next	()Ljava/lang/String;
    //   62: astore 7
    //   64: aload 7
    //   66: astore_3
    //   67: aload 4
    //   69: ifnull +43 -> 112
    //   72: aload 4
    //   74: invokevirtual 488	java/io/InputStream:close	()V
    //   77: aload_3
    //   78: areturn
    //   79: astore 6
    //   81: aload 4
    //   83: ifnull +31 -> 114
    //   86: aload 4
    //   88: invokevirtual 488	java/io/InputStream:close	()V
    //   91: goto +23 -> 114
    //   94: astore 5
    //   96: aload 4
    //   98: ifnull +8 -> 106
    //   101: aload 4
    //   103: invokevirtual 488	java/io/InputStream:close	()V
    //   106: aload 5
    //   108: athrow
    //   109: astore_2
    //   110: aconst_null
    //   111: astore_3
    //   112: aload_3
    //   113: areturn
    //   114: aconst_null
    //   115: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   44	64	79	java/util/NoSuchElementException
    //   44	64	94	finally
    //   34	44	109	java/lang/Exception
    //   72	77	109	java/lang/Exception
    //   86	91	109	java/lang/Exception
    //   101	106	109	java/lang/Exception
    //   106	109	109	java/lang/Exception
  }

  public static Context getRemoteContext(Context paramContext)
  {
    try
    {
      Context localContext = paramContext.createPackageContext("com.google.android.gms", 3);
      return localContext;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
    }
    return null;
  }

  public static Resources getRemoteResource(Context paramContext)
  {
    try
    {
      Resources localResources = paramContext.getPackageManager().getResourcesForApplication("com.google.android.gms");
      return localResources;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
    }
    return null;
  }

  public static int isGooglePlayServicesAvailable(Context paramContext)
  {
    PackageManager localPackageManager = paramContext.getPackageManager();
    try
    {
      paramContext.getResources().getString(R.string.common_google_play_services_unknown_issue);
      if (System.currentTimeMillis() < 1227312000288L)
        return 12;
    }
    catch (Throwable localThrowable)
    {
      while (true)
        Log.e("GooglePlayServicesUtil", "The Google Play services resources were not found. Check your project configuration to ensure that the resources are included.");
      n(paramContext);
      byte[] arrayOfByte;
      try
      {
        PackageInfo localPackageInfo1 = localPackageManager.getPackageInfo("com.android.vending", 64);
        arrayOfByte = a(localPackageInfo1, mD);
        if (arrayOfByte == null)
        {
          Log.w("GooglePlayServicesUtil", "Google Play Store signature invalid.");
          return 9;
        }
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException1)
      {
        Log.w("GooglePlayServicesUtil", "Google Play Store is missing.");
        return 9;
      }
      PackageInfo localPackageInfo2;
      try
      {
        localPackageInfo2 = localPackageManager.getPackageInfo("com.google.android.gms", 64);
        if (a(localPackageInfo2, new byte[][] { arrayOfByte }) == null)
        {
          Log.w("GooglePlayServicesUtil", "Google Play services signature invalid.");
          return 9;
        }
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException2)
      {
        Log.w("GooglePlayServicesUtil", "Google Play services is missing.");
        return 1;
      }
      if (localPackageInfo2.versionCode < 4242000)
      {
        Log.w("GooglePlayServicesUtil", "Google Play services out of date.  Requires 4242000 but found " + localPackageInfo2.versionCode);
        return 2;
      }
      try
      {
        ApplicationInfo localApplicationInfo = localPackageManager.getApplicationInfo("com.google.android.gms", 0);
        if (!localApplicationInfo.enabled)
          return 3;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException3)
      {
        Log.wtf("GooglePlayServicesUtil", "Google Play services missing when getting application info.");
        localNameNotFoundException3.printStackTrace();
        return 1;
      }
    }
    return 0;
  }

  public static boolean isUserRecoverableError(int paramInt)
  {
    switch (paramInt)
    {
    default:
      return false;
    case 1:
    case 2:
    case 3:
    case 9:
    case 12:
    }
    return true;
  }

  public static void m(Context paramContext)
    throws GooglePlayServicesRepairableException, GooglePlayServicesNotAvailableException
  {
    int i = isGooglePlayServicesAvailable(paramContext);
    if (i != 0)
    {
      Intent localIntent = a(paramContext, i, -1);
      Log.e("GooglePlayServicesUtil", "GooglePlayServices not available due to error " + i);
      if (localIntent == null)
        throw new GooglePlayServicesNotAvailableException(i);
      throw new GooglePlayServicesRepairableException(i, "Google Play Services not available", localIntent);
    }
  }

  private static void n(Context paramContext)
  {
    int i;
    try
    {
      ApplicationInfo localApplicationInfo2 = paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128);
      localApplicationInfo1 = localApplicationInfo2;
      Bundle localBundle = localApplicationInfo1.metaData;
      if (localBundle == null)
        break label123;
      i = localBundle.getInt("com.google.android.gms.version");
      if (i == 4242000)
        return;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      while (true)
      {
        Log.wtf("GooglePlayServicesUtil", "This should never happen.", localNameNotFoundException);
        ApplicationInfo localApplicationInfo1 = null;
      }
    }
    throw new IllegalStateException("The meta-data tag in your app's AndroidManifest.xml does not have the right value.  Expected 4242000 but found " + i + ".  You must have the" + " following declaration within the <application> element: " + "    <meta-data android:name=\"" + "com.google.android.gms.version" + "\" android:value=\"@integer/google_play_services_version\" />");
    label123: throw new IllegalStateException("A required meta-data tag in your app's AndroidManifest.xml does not exist.  You must have the following declaration within the <application> element:     <meta-data android:name=\"com.google.android.gms.version\" android:value=\"@integer/google_play_services_version\" />");
  }

  private static boolean o(Context paramContext)
  {
    boolean bool;
    if (mK)
      bool = mM;
    while (true)
    {
      return bool;
      try
      {
        byte[] arrayOfByte = a(paramContext.getPackageManager().getPackageInfo("com.google.android.apps.bazaar", 64), mJ);
        bool = false;
        if (arrayOfByte != null)
          return true;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
      }
    }
    return false;
  }

  static boolean y(int paramInt)
  {
    boolean bool = true;
    switch (z(paramInt))
    {
    default:
      bool = false;
    case 1:
    case 0:
      do
        return bool;
      while (!bi());
      return false;
    case 2:
    }
    return false;
  }

  private static int z(int paramInt)
  {
    if (paramInt == -1)
      paramInt = 2;
    return paramInt;
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.GooglePlayServicesUtil
 * JD-Core Version:    0.6.2
 */