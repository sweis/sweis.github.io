package com.google.android.gms.appstate;

@Deprecated
public abstract interface OnStateDeletedListener
{
  public abstract void onStateDeleted(int paramInt1, int paramInt2);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.appstate.OnStateDeletedListener
 * JD-Core Version:    0.6.2
 */