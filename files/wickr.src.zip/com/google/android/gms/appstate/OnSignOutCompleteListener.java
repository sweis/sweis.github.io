package com.google.android.gms.appstate;

@Deprecated
public abstract interface OnSignOutCompleteListener
{
  public abstract void onSignOutComplete();
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.appstate.OnSignOutCompleteListener
 * JD-Core Version:    0.6.2
 */