package com.google.android.gms.appstate;

import android.content.Context;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ApiOptions;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.a.a;
import com.google.android.gms.internal.dc;
import com.google.android.gms.internal.dt;
import com.google.android.gms.internal.eg;
import java.util.List;

public final class AppStateManager
{
  public static final Api API = new Api(localb, arrayOfScope);
  public static final Scope SCOPE_APP_STATE;
  static final Api.b<dc> jO = new Api.b()
  {
    public dc a(Context paramAnonymousContext, dt paramAnonymousdt, GoogleApiClient.ApiOptions paramAnonymousApiOptions, GoogleApiClient.ConnectionCallbacks paramAnonymousConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener paramAnonymousOnConnectionFailedListener)
    {
      return new dc(paramAnonymousContext, paramAnonymousConnectionCallbacks, paramAnonymousOnConnectionFailedListener, paramAnonymousdt.bF(), (String[])paramAnonymousdt.bH().toArray(new String[0]));
    }

    public int getPriority()
    {
      return 2147483647;
    }
  };

  static
  {
    SCOPE_APP_STATE = new Scope("https://www.googleapis.com/auth/appstate");
    Api.b localb = jO;
    Scope[] arrayOfScope = new Scope[1];
    arrayOfScope[0] = SCOPE_APP_STATE;
  }

  public static dc a(GoogleApiClient paramGoogleApiClient)
  {
    boolean bool1 = true;
    boolean bool2;
    dc localdc;
    if (paramGoogleApiClient != null)
    {
      bool2 = bool1;
      eg.b(bool2, "GoogleApiClient parameter is required.");
      eg.a(paramGoogleApiClient.isConnected(), "GoogleApiClient must be connected.");
      localdc = (dc)paramGoogleApiClient.a(jO);
      if (localdc == null)
        break label51;
    }
    while (true)
    {
      eg.a(bool1, "GoogleApiClient is not configured to use the AppState API. Pass AppStateManager.API into GoogleApiClient.Builder#addApi() to use this feature.");
      return localdc;
      bool2 = false;
      break;
      label51: bool1 = false;
    }
  }

  private static StateResult b(Status paramStatus)
  {
    return new StateResult()
    {
      public AppStateManager.StateConflictResult getConflictResult()
      {
        return null;
      }

      public AppStateManager.StateLoadedResult getLoadedResult()
      {
        return null;
      }

      public Status getStatus()
      {
        return this.jP;
      }
    };
  }

  public static PendingResult<StateDeletedResult> delete(GoogleApiClient paramGoogleApiClient, int paramInt)
  {
    return paramGoogleApiClient.b(new b(paramInt)
    {
      protected void a(dc paramAnonymousdc)
      {
        paramAnonymousdc.a(this, this.jQ);
      }

      public AppStateManager.StateDeletedResult d(final Status paramAnonymousStatus)
      {
        return new AppStateManager.StateDeletedResult()
        {
          public int getStateKey()
          {
            return AppStateManager.5.this.jQ;
          }

          public Status getStatus()
          {
            return paramAnonymousStatus;
          }
        };
      }
    });
  }

  public static int getMaxNumKeys(GoogleApiClient paramGoogleApiClient)
  {
    return a(paramGoogleApiClient).getMaxNumKeys();
  }

  public static int getMaxStateSize(GoogleApiClient paramGoogleApiClient)
  {
    return a(paramGoogleApiClient).getMaxStateSize();
  }

  public static PendingResult<StateListResult> list(GoogleApiClient paramGoogleApiClient)
  {
    // Byte code:
    //   0: aload_0
    //   1: new 97	com/google/android/gms/appstate/AppStateManager$7
    //   4: dup
    //   5: invokespecial 98	com/google/android/gms/appstate/AppStateManager$7:<init>	()V
    //   8: invokevirtual 100	com/google/android/gms/common/api/GoogleApiClient:a	(Lcom/google/android/gms/common/api/a$a;)Lcom/google/android/gms/common/api/a$a;
    //   11: areturn
  }

  public static PendingResult<StateResult> load(GoogleApiClient paramGoogleApiClient, int paramInt)
  {
    return paramGoogleApiClient.a(new e(paramInt)
    {
      protected void a(dc paramAnonymousdc)
      {
        paramAnonymousdc.b(this, this.jQ);
      }
    });
  }

  public static PendingResult<StateResult> resolve(GoogleApiClient paramGoogleApiClient, int paramInt, final String paramString, final byte[] paramArrayOfByte)
  {
    return paramGoogleApiClient.b(new e(paramInt)
    {
      protected void a(dc paramAnonymousdc)
      {
        paramAnonymousdc.a(this, this.jQ, paramString, paramArrayOfByte);
      }
    });
  }

  public static PendingResult<Status> signOut(GoogleApiClient paramGoogleApiClient)
  {
    // Byte code:
    //   0: aload_0
    //   1: new 114	com/google/android/gms/appstate/AppStateManager$9
    //   4: dup
    //   5: invokespecial 115	com/google/android/gms/appstate/AppStateManager$9:<init>	()V
    //   8: invokevirtual 83	com/google/android/gms/common/api/GoogleApiClient:b	(Lcom/google/android/gms/common/api/a$a;)Lcom/google/android/gms/common/api/a$a;
    //   11: areturn
  }

  public static void update(GoogleApiClient paramGoogleApiClient, int paramInt, final byte[] paramArrayOfByte)
  {
    paramGoogleApiClient.b(new e(paramInt)
    {
      protected void a(dc paramAnonymousdc)
      {
        paramAnonymousdc.a(null, this.jQ, paramArrayOfByte);
      }
    });
  }

  public static PendingResult<StateResult> updateImmediate(GoogleApiClient paramGoogleApiClient, int paramInt, final byte[] paramArrayOfByte)
  {
    return paramGoogleApiClient.b(new e(paramInt)
    {
      protected void a(dc paramAnonymousdc)
      {
        paramAnonymousdc.a(this, this.jQ, paramArrayOfByte);
      }
    });
  }

  public static abstract interface StateConflictResult extends Result
  {
    public abstract byte[] getLocalData();

    public abstract String getResolvedVersion();

    public abstract byte[] getServerData();

    public abstract int getStateKey();
  }

  public static abstract interface StateDeletedResult extends Result
  {
    public abstract int getStateKey();
  }

  public static abstract interface StateListResult extends Result
  {
    public abstract AppStateBuffer getStateBuffer();
  }

  public static abstract interface StateLoadedResult extends Result
  {
    public abstract byte[] getLocalData();

    public abstract int getStateKey();
  }

  public static abstract interface StateResult extends Result
  {
    public abstract AppStateManager.StateConflictResult getConflictResult();

    public abstract AppStateManager.StateLoadedResult getLoadedResult();
  }

  public static abstract class a<R extends Result> extends a.a<R, dc>
    implements PendingResult<R>
  {
    public a()
    {
      super();
    }
  }

  private static abstract class b extends AppStateManager.a<AppStateManager.StateDeletedResult>
  {
  }

  private static abstract class c extends AppStateManager.a<AppStateManager.StateListResult>
  {
    public AppStateManager.StateListResult f(final Status paramStatus)
    {
      return new AppStateManager.StateListResult()
      {
        public AppStateBuffer getStateBuffer()
        {
          return new AppStateBuffer(null);
        }

        public Status getStatus()
        {
          return paramStatus;
        }
      };
    }
  }

  private static abstract class d extends AppStateManager.a<Status>
  {
    public Status g(Status paramStatus)
    {
      return paramStatus;
    }
  }

  private static abstract class e extends AppStateManager.a<AppStateManager.StateResult>
  {
    public AppStateManager.StateResult h(Status paramStatus)
    {
      return AppStateManager.c(paramStatus);
    }
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.appstate.AppStateManager
 * JD-Core Version:    0.6.2
 */