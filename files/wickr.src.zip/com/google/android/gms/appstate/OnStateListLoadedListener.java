package com.google.android.gms.appstate;

@Deprecated
public abstract interface OnStateListLoadedListener
{
  public abstract void onStateListLoaded(int paramInt, AppStateBuffer paramAppStateBuffer);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.appstate.OnStateListLoadedListener
 * JD-Core Version:    0.6.2
 */