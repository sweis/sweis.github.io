package com.google.android.gms.dynamic;

public abstract interface d<T extends LifecycleDelegate>
{
  public abstract void a(T paramT);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.dynamic.d
 * JD-Core Version:    0.6.2
 */