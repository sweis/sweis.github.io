package com.google.android.gms.games;

@Deprecated
public abstract interface OnGamesLoadedListener
{
  public abstract void onGamesLoaded(int paramInt, GameBuffer paramGameBuffer);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.OnGamesLoadedListener
 * JD-Core Version:    0.6.2
 */