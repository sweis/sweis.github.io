package com.google.android.gms.games;

@Deprecated
public abstract interface OnPlayersLoadedListener
{
  public abstract void onPlayersLoaded(int paramInt, PlayerBuffer paramPlayerBuffer);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.OnPlayersLoadedListener
 * JD-Core Version:    0.6.2
 */