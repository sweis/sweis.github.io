package com.google.android.gms.games.leaderboard;

import android.os.Bundle;

public final class c
{
  private final Bundle vJ;

  public c(Bundle paramBundle)
  {
    if (paramBundle == null)
      paramBundle = new Bundle();
    this.vJ = paramBundle;
  }

  public Bundle dr()
  {
    return this.vJ;
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.leaderboard.c
 * JD-Core Version:    0.6.2
 */