package com.google.android.gms.games.leaderboard;

import android.content.ContentValues;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.data.DataHolder.Builder;
import com.google.android.gms.internal.ee;
import com.google.android.gms.internal.ee.a;
import com.google.android.gms.internal.eg;
import com.google.android.gms.internal.ge;
import java.util.HashMap;

public final class ScoreSubmissionData
{
  private static final String[] wh = { "leaderboardId", "playerId", "timeSpan", "hasResult", "rawScore", "formattedScore", "newBest", "scoreTag" };
  private int mC;
  private String tC;
  private String vD;
  private HashMap<Integer, Result> wi;

  public ScoreSubmissionData(DataHolder paramDataHolder)
  {
    this.mC = paramDataHolder.getStatusCode();
    this.wi = new HashMap();
    int i = paramDataHolder.getCount();
    if (i == 3);
    for (boolean bool = true; ; bool = false)
    {
      eg.r(bool);
      for (int j = 0; j < i; j++)
      {
        int k = paramDataHolder.C(j);
        if (j == 0)
        {
          this.vD = paramDataHolder.getString("leaderboardId", j, k);
          this.tC = paramDataHolder.getString("playerId", j, k);
        }
        if (paramDataHolder.getBoolean("hasResult", j, k))
          a(new Result(paramDataHolder.getLong("rawScore", j, k), paramDataHolder.getString("formattedScore", j, k), paramDataHolder.getString("scoreTag", j, k), paramDataHolder.getBoolean("newBest", j, k)), paramDataHolder.getInteger("timeSpan", j, k));
      }
    }
  }

  private void a(Result paramResult, int paramInt)
  {
    this.wi.put(Integer.valueOf(paramInt), paramResult);
  }

  private ContentValues aH(int paramInt)
  {
    Result localResult = getScoreResult(paramInt);
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("leaderboardId", this.vD);
    localContentValues.put("playerId", this.tC);
    localContentValues.put("timeSpan", Integer.valueOf(paramInt));
    if (localResult != null)
    {
      localContentValues.put("rawScore", Long.valueOf(localResult.rawScore));
      localContentValues.put("formattedScore", localResult.formattedScore);
      localContentValues.put("scoreTag", localResult.scoreTag);
      localContentValues.put("newBest", Boolean.valueOf(localResult.newBest));
      localContentValues.put("hasResult", Boolean.valueOf(true));
      return localContentValues;
    }
    localContentValues.put("hasResult", Boolean.valueOf(false));
    return localContentValues;
  }

  public DataHolder dx()
  {
    DataHolder.Builder localBuilder = DataHolder.builder(wh);
    for (int i = 0; i < 3; i++)
      localBuilder.withRow(aH(i));
    return localBuilder.build(this.mC);
  }

  public String getLeaderboardId()
  {
    return this.vD;
  }

  public String getPlayerId()
  {
    return this.tC;
  }

  public Result getScoreResult(int paramInt)
  {
    return (Result)this.wi.get(Integer.valueOf(paramInt));
  }

  public String toString()
  {
    ee.a locala = ee.e(this).a("PlayerId", this.tC).a("StatusCode", Integer.valueOf(this.mC));
    int i = 0;
    if (i < 3)
    {
      Result localResult = (Result)this.wi.get(Integer.valueOf(i));
      locala.a("TimesSpan", ge.aG(i));
      if (localResult == null);
      for (String str = "null"; ; str = localResult.toString())
      {
        locala.a("Result", str);
        i++;
        break;
      }
    }
    return locala.toString();
  }

  public static final class Result
  {
    public final String formattedScore;
    public final boolean newBest;
    public final long rawScore;
    public final String scoreTag;

    public Result(long paramLong, String paramString1, String paramString2, boolean paramBoolean)
    {
      this.rawScore = paramLong;
      this.formattedScore = paramString1;
      this.scoreTag = paramString2;
      this.newBest = paramBoolean;
    }

    public String toString()
    {
      return ee.e(this).a("RawScore", Long.valueOf(this.rawScore)).a("FormattedScore", this.formattedScore).a("ScoreTag", this.scoreTag).a("NewBest", Boolean.valueOf(this.newBest)).toString();
    }
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.leaderboard.ScoreSubmissionData
 * JD-Core Version:    0.6.2
 */