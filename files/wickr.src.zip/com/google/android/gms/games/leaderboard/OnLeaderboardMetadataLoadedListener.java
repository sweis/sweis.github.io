package com.google.android.gms.games.leaderboard;

@Deprecated
public abstract interface OnLeaderboardMetadataLoadedListener
{
  public abstract void onLeaderboardMetadataLoaded(int paramInt, LeaderboardBuffer paramLeaderboardBuffer);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.leaderboard.OnLeaderboardMetadataLoadedListener
 * JD-Core Version:    0.6.2
 */