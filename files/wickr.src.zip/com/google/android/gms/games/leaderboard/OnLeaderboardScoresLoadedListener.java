package com.google.android.gms.games.leaderboard;

@Deprecated
public abstract interface OnLeaderboardScoresLoadedListener
{
  public abstract void onLeaderboardScoresLoaded(int paramInt, Leaderboard paramLeaderboard, LeaderboardScoreBuffer paramLeaderboardScoreBuffer);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.leaderboard.OnLeaderboardScoresLoadedListener
 * JD-Core Version:    0.6.2
 */