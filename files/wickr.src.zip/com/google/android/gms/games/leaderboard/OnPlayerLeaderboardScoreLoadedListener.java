package com.google.android.gms.games.leaderboard;

@Deprecated
public abstract interface OnPlayerLeaderboardScoreLoadedListener
{
  public abstract void onPlayerLeaderboardScoreLoaded(int paramInt, LeaderboardScore paramLeaderboardScore);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.leaderboard.OnPlayerLeaderboardScoreLoadedListener
 * JD-Core Version:    0.6.2
 */