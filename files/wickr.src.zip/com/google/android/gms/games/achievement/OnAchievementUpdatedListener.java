package com.google.android.gms.games.achievement;

@Deprecated
public abstract interface OnAchievementUpdatedListener
{
  public abstract void onAchievementUpdated(int paramInt, String paramString);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.achievement.OnAchievementUpdatedListener
 * JD-Core Version:    0.6.2
 */