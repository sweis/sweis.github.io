package com.google.android.gms.games.achievement;

@Deprecated
public abstract interface OnAchievementsLoadedListener
{
  public abstract void onAchievementsLoaded(int paramInt, AchievementBuffer paramAchievementBuffer);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.achievement.OnAchievementsLoadedListener
 * JD-Core Version:    0.6.2
 */