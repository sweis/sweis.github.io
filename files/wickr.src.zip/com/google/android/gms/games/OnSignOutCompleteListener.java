package com.google.android.gms.games;

@Deprecated
public abstract interface OnSignOutCompleteListener
{
  public abstract void onSignOutComplete();
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.OnSignOutCompleteListener
 * JD-Core Version:    0.6.2
 */