package com.google.android.gms.games.multiplayer.turnbased;

@Deprecated
public abstract interface OnTurnBasedMatchCanceledListener
{
  public abstract void onTurnBasedMatchCanceled(int paramInt, String paramString);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.multiplayer.turnbased.OnTurnBasedMatchCanceledListener
 * JD-Core Version:    0.6.2
 */