package com.google.android.gms.games.multiplayer.turnbased;

@Deprecated
public abstract interface OnTurnBasedMatchUpdatedListener
{
  public abstract void onTurnBasedMatchUpdated(int paramInt, TurnBasedMatch paramTurnBasedMatch);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.multiplayer.turnbased.OnTurnBasedMatchUpdatedListener
 * JD-Core Version:    0.6.2
 */