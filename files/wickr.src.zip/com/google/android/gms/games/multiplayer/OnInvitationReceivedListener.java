package com.google.android.gms.games.multiplayer;

public abstract interface OnInvitationReceivedListener
{
  public abstract void onInvitationReceived(Invitation paramInvitation);

  public abstract void onInvitationRemoved(String paramString);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.multiplayer.OnInvitationReceivedListener
 * JD-Core Version:    0.6.2
 */