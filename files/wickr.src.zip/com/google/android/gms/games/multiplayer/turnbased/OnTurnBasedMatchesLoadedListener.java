package com.google.android.gms.games.multiplayer.turnbased;

@Deprecated
public abstract interface OnTurnBasedMatchesLoadedListener
{
  public abstract void onTurnBasedMatchesLoaded(int paramInt, LoadMatchesResponse paramLoadMatchesResponse);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.multiplayer.turnbased.OnTurnBasedMatchesLoadedListener
 * JD-Core Version:    0.6.2
 */