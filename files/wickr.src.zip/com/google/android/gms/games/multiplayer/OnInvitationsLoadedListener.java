package com.google.android.gms.games.multiplayer;

@Deprecated
public abstract interface OnInvitationsLoadedListener
{
  public abstract void onInvitationsLoaded(int paramInt, InvitationBuffer paramInvitationBuffer);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.multiplayer.OnInvitationsLoadedListener
 * JD-Core Version:    0.6.2
 */