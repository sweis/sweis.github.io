package com.google.android.gms.games.multiplayer.realtime;

@Deprecated
public abstract interface RealTimeReliableMessageSentListener
{
  public abstract void onRealTimeMessageSent(int paramInt1, int paramInt2, String paramString);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.multiplayer.realtime.RealTimeReliableMessageSentListener
 * JD-Core Version:    0.6.2
 */