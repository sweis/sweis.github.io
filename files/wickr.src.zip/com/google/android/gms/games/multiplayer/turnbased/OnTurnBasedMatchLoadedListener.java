package com.google.android.gms.games.multiplayer.turnbased;

@Deprecated
public abstract interface OnTurnBasedMatchLoadedListener
{
  public abstract void onTurnBasedMatchLoaded(int paramInt, TurnBasedMatch paramTurnBasedMatch);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.multiplayer.turnbased.OnTurnBasedMatchLoadedListener
 * JD-Core Version:    0.6.2
 */