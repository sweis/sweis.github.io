package com.google.android.gms.games.multiplayer.turnbased;

@Deprecated
public abstract interface OnTurnBasedMatchInitiatedListener
{
  public abstract void onTurnBasedMatchInitiated(int paramInt, TurnBasedMatch paramTurnBasedMatch);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.games.multiplayer.turnbased.OnTurnBasedMatchInitiatedListener
 * JD-Core Version:    0.6.2
 */