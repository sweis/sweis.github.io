package com.google.android.gms.drive.query;

public abstract interface Filter
{
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.drive.query.Filter
 * JD-Core Version:    0.6.2
 */