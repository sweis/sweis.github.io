package com.google.android.gms.drive;

import android.content.IntentSender;
import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.drive.internal.OpenFileIntentSenderRequest;
import com.google.android.gms.drive.internal.j;
import com.google.android.gms.drive.internal.o;
import com.google.android.gms.internal.eg;

public class OpenFileActivityBuilder
{
  public static final String EXTRA_RESPONSE_DRIVE_ID = "response_drive_id";
  private String qL;
  private DriveId qM;
  private String[] qW;

  public IntentSender build(GoogleApiClient paramGoogleApiClient)
  {
    eg.b(this.qW, "setMimeType(String[]) must be called on this builder before calling build()");
    eg.a(paramGoogleApiClient.isConnected(), "Client must be connected");
    o localo = ((j)paramGoogleApiClient.a(Drive.jO)).cN();
    try
    {
      IntentSender localIntentSender = localo.a(new OpenFileIntentSenderRequest(this.qL, this.qW, this.qM));
      return localIntentSender;
    }
    catch (RemoteException localRemoteException)
    {
      throw new RuntimeException("Unable to connect Drive Play Service", localRemoteException);
    }
  }

  public OpenFileActivityBuilder setActivityStartFolder(DriveId paramDriveId)
  {
    this.qM = ((DriveId)eg.f(paramDriveId));
    return this;
  }

  public OpenFileActivityBuilder setActivityTitle(String paramString)
  {
    this.qL = ((String)eg.f(paramString));
    return this;
  }

  public OpenFileActivityBuilder setMimeType(String[] paramArrayOfString)
  {
    if ((paramArrayOfString != null) && (paramArrayOfString.length > 0));
    for (boolean bool = true; ; bool = false)
    {
      eg.b(bool, "mimeTypes may not be null and must contain at least one value");
      this.qW = paramArrayOfString;
      return this;
    }
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.drive.OpenFileActivityBuilder
 * JD-Core Version:    0.6.2
 */