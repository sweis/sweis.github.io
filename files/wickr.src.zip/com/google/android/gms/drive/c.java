package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class c
  implements Parcelable.Creator<DriveId>
{
  static void a(DriveId paramDriveId, Parcel paramParcel, int paramInt)
  {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1, paramDriveId.kg);
    b.a(paramParcel, 2, paramDriveId.qO, false);
    b.a(paramParcel, 3, paramDriveId.qP);
    b.a(paramParcel, 4, paramDriveId.qQ);
    b.D(paramParcel, i);
  }

  public DriveId[] Z(int paramInt)
  {
    return new DriveId[paramInt];
  }

  public DriveId z(Parcel paramParcel)
  {
    long l1 = 0L;
    int i = a.n(paramParcel);
    int j = 0;
    String str = null;
    long l2 = l1;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.m(paramParcel);
      switch (a.M(k))
      {
      default:
        a.b(paramParcel, k);
        break;
      case 1:
        j = a.g(paramParcel, k);
        break;
      case 2:
        str = a.m(paramParcel, k);
        break;
      case 3:
        l2 = a.h(paramParcel, k);
        break;
      case 4:
        l1 = a.h(paramParcel, k);
      }
    }
    if (paramParcel.dataPosition() != i)
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    return new DriveId(j, str, l2, l1);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.drive.c
 * JD-Core Version:    0.6.2
 */