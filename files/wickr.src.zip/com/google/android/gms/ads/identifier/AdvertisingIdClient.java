package com.google.android.gms.ads.identifier;

public final class AdvertisingIdClient
{
  // ERROR //
  private static com.google.android.gms.common.a g(android.content.Context paramContext)
    throws java.io.IOException, com.google.android.gms.common.GooglePlayServicesNotAvailableException, com.google.android.gms.common.GooglePlayServicesRepairableException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 24	android/content/Context:getPackageManager	()Landroid/content/pm/PackageManager;
    //   4: ldc 26
    //   6: iconst_0
    //   7: invokevirtual 32	android/content/pm/PackageManager:getPackageInfo	(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   10: pop
    //   11: aload_0
    //   12: invokestatic 38	com/google/android/gms/common/GooglePlayServicesUtil:m	(Landroid/content/Context;)V
    //   15: new 40	com/google/android/gms/common/a
    //   18: dup
    //   19: invokespecial 41	com/google/android/gms/common/a:<init>	()V
    //   22: astore 4
    //   24: new 43	android/content/Intent
    //   27: dup
    //   28: ldc 45
    //   30: invokespecial 48	android/content/Intent:<init>	(Ljava/lang/String;)V
    //   33: astore 5
    //   35: aload 5
    //   37: ldc 50
    //   39: invokevirtual 54	android/content/Intent:setPackage	(Ljava/lang/String;)Landroid/content/Intent;
    //   42: pop
    //   43: aload_0
    //   44: aload 5
    //   46: aload 4
    //   48: iconst_1
    //   49: invokevirtual 58	android/content/Context:bindService	(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
    //   52: ifeq +27 -> 79
    //   55: aload 4
    //   57: areturn
    //   58: astore_1
    //   59: new 14	com/google/android/gms/common/GooglePlayServicesNotAvailableException
    //   62: dup
    //   63: bipush 9
    //   65: invokespecial 61	com/google/android/gms/common/GooglePlayServicesNotAvailableException:<init>	(I)V
    //   68: athrow
    //   69: astore_3
    //   70: new 12	java/io/IOException
    //   73: dup
    //   74: aload_3
    //   75: invokespecial 64	java/io/IOException:<init>	(Ljava/lang/Throwable;)V
    //   78: athrow
    //   79: new 12	java/io/IOException
    //   82: dup
    //   83: ldc 66
    //   85: invokespecial 67	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   88: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   0	11	58	android/content/pm/PackageManager$NameNotFoundException
    //   11	15	69	com/google/android/gms/common/GooglePlayServicesNotAvailableException
  }

  // ERROR //
  public static Info getAdvertisingIdInfo(android.content.Context paramContext)
    throws java.io.IOException, java.lang.IllegalStateException, com.google.android.gms.common.GooglePlayServicesNotAvailableException, com.google.android.gms.common.GooglePlayServicesRepairableException
  {
    // Byte code:
    //   0: ldc 77
    //   2: invokestatic 82	com/google/android/gms/internal/eg:O	(Ljava/lang/String;)V
    //   5: aload_0
    //   6: invokestatic 84	com/google/android/gms/ads/identifier/AdvertisingIdClient:g	(Landroid/content/Context;)Lcom/google/android/gms/common/a;
    //   9: astore_1
    //   10: aload_1
    //   11: invokevirtual 88	com/google/android/gms/common/a:bg	()Landroid/os/IBinder;
    //   14: invokestatic 94	com/google/android/gms/internal/p$a:b	(Landroid/os/IBinder;)Lcom/google/android/gms/internal/p;
    //   17: astore 6
    //   19: new 96	com/google/android/gms/ads/identifier/AdvertisingIdClient$Info
    //   22: dup
    //   23: aload 6
    //   25: invokeinterface 102 1 0
    //   30: aload 6
    //   32: iconst_1
    //   33: invokeinterface 106 2 0
    //   38: invokespecial 109	com/google/android/gms/ads/identifier/AdvertisingIdClient$Info:<init>	(Ljava/lang/String;Z)V
    //   41: astore 7
    //   43: aload_0
    //   44: aload_1
    //   45: invokevirtual 113	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   48: aload 7
    //   50: areturn
    //   51: astore 4
    //   53: ldc 115
    //   55: ldc 117
    //   57: aload 4
    //   59: invokestatic 123	android/util/Log:i	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   62: pop
    //   63: new 12	java/io/IOException
    //   66: dup
    //   67: ldc 125
    //   69: invokespecial 67	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   72: athrow
    //   73: astore_3
    //   74: aload_0
    //   75: aload_1
    //   76: invokevirtual 113	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
    //   79: aload_3
    //   80: athrow
    //   81: astore_2
    //   82: new 12	java/io/IOException
    //   85: dup
    //   86: ldc 127
    //   88: invokespecial 67	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   91: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   10	43	51	android/os/RemoteException
    //   10	43	73	finally
    //   53	73	73	finally
    //   82	92	73	finally
    //   10	43	81	java/lang/InterruptedException
  }

  public static final class Info
  {
    private final String eb;
    private final boolean ec;

    Info(String paramString, boolean paramBoolean)
    {
      this.eb = paramString;
      this.ec = paramBoolean;
    }

    public String getId()
    {
      return this.eb;
    }

    public boolean isLimitAdTrackingEnabled()
    {
      return this.ec;
    }
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.identifier.AdvertisingIdClient
 * JD-Core Version:    0.6.2
 */