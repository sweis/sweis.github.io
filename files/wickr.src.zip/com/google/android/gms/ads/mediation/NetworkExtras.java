package com.google.android.gms.ads.mediation;

public abstract interface NetworkExtras
{
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.mediation.NetworkExtras
 * JD-Core Version:    0.6.2
 */