package com.google.android.gms.ads;

public final class a
{
  public static AdSize a(int paramInt1, int paramInt2, String paramString)
  {
    return new AdSize(paramInt1, paramInt2, paramString);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.ads.a
 * JD-Core Version:    0.6.2
 */