package com.google.android.gms.auth;

public class GoogleAuthException extends Exception
{
  public GoogleAuthException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.auth.GoogleAuthException
 * JD-Core Version:    0.6.2
 */