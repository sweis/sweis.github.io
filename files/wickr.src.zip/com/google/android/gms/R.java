package com.google.android.gms;

public final class R
{
  public static final class attr
  {
    public static final int adSize = 2130772099;
    public static final int adSizes = 2130772100;
    public static final int adUnitId = 2130772101;
    public static final int cameraBearing = 2130772103;
    public static final int cameraTargetLat = 2130772104;
    public static final int cameraTargetLng = 2130772105;
    public static final int cameraTilt = 2130772106;
    public static final int cameraZoom = 2130772107;
    public static final int mapType = 2130772102;
    public static final int uiCompass = 2130772108;
    public static final int uiRotateGestures = 2130772109;
    public static final int uiScrollGestures = 2130772110;
    public static final int uiTiltGestures = 2130772111;
    public static final int uiZoomControls = 2130772112;
    public static final int uiZoomGestures = 2130772113;
    public static final int useViewLifecycle = 2130772114;
    public static final int zOrderOnTop = 2130772115;
  }

  public static final class color
  {
    public static final int common_action_bar_splitter = 2131034134;
    public static final int common_signin_btn_dark_text_default = 2131034125;
    public static final int common_signin_btn_dark_text_disabled = 2131034127;
    public static final int common_signin_btn_dark_text_focused = 2131034128;
    public static final int common_signin_btn_dark_text_pressed = 2131034126;
    public static final int common_signin_btn_default_background = 2131034133;
    public static final int common_signin_btn_light_text_default = 2131034129;
    public static final int common_signin_btn_light_text_disabled = 2131034131;
    public static final int common_signin_btn_light_text_focused = 2131034132;
    public static final int common_signin_btn_light_text_pressed = 2131034130;
    public static final int common_signin_btn_text_dark = 2131034172;
    public static final int common_signin_btn_text_light = 2131034173;
  }

  public static final class drawable
  {
    public static final int common_signin_btn_icon_dark = 2130837636;
    public static final int common_signin_btn_icon_disabled_dark = 2130837637;
    public static final int common_signin_btn_icon_disabled_focus_dark = 2130837638;
    public static final int common_signin_btn_icon_disabled_focus_light = 2130837639;
    public static final int common_signin_btn_icon_disabled_light = 2130837640;
    public static final int common_signin_btn_icon_focus_dark = 2130837641;
    public static final int common_signin_btn_icon_focus_light = 2130837642;
    public static final int common_signin_btn_icon_light = 2130837643;
    public static final int common_signin_btn_icon_normal_dark = 2130837644;
    public static final int common_signin_btn_icon_normal_light = 2130837645;
    public static final int common_signin_btn_icon_pressed_dark = 2130837646;
    public static final int common_signin_btn_icon_pressed_light = 2130837647;
    public static final int common_signin_btn_text_dark = 2130837648;
    public static final int common_signin_btn_text_disabled_dark = 2130837649;
    public static final int common_signin_btn_text_disabled_focus_dark = 2130837650;
    public static final int common_signin_btn_text_disabled_focus_light = 2130837651;
    public static final int common_signin_btn_text_disabled_light = 2130837652;
    public static final int common_signin_btn_text_focus_dark = 2130837653;
    public static final int common_signin_btn_text_focus_light = 2130837654;
    public static final int common_signin_btn_text_light = 2130837655;
    public static final int common_signin_btn_text_normal_dark = 2130837656;
    public static final int common_signin_btn_text_normal_light = 2130837657;
    public static final int common_signin_btn_text_pressed_dark = 2130837658;
    public static final int common_signin_btn_text_pressed_light = 2130837659;
    public static final int ic_plusone_medium_off_client = 2130837739;
    public static final int ic_plusone_small_off_client = 2130837740;
    public static final int ic_plusone_standard_off_client = 2130837741;
    public static final int ic_plusone_tall_off_client = 2130837742;
  }

  public static final class id
  {
    public static final int hybrid = 2131296277;
    public static final int none = 2131296274;
    public static final int normal = 2131296257;
    public static final int satellite = 2131296275;
    public static final int terrain = 2131296276;
  }

  public static final class integer
  {
    public static final int google_play_services_version = 2131427329;
  }

  public static final class string
  {
    public static final int auth_client_needs_enabling_title = 2131165222;
    public static final int auth_client_needs_installation_title = 2131165223;
    public static final int auth_client_needs_update_title = 2131165224;
    public static final int auth_client_play_services_err_notification_msg = 2131165225;
    public static final int auth_client_requested_by_msg = 2131165226;
    public static final int auth_client_using_bad_version_title = 2131165221;
    public static final int common_google_play_services_enable_button = 2131165207;
    public static final int common_google_play_services_enable_text = 2131165206;
    public static final int common_google_play_services_enable_title = 2131165205;
    public static final int common_google_play_services_install_button = 2131165204;
    public static final int common_google_play_services_install_text_phone = 2131165202;
    public static final int common_google_play_services_install_text_tablet = 2131165203;
    public static final int common_google_play_services_install_title = 2131165201;
    public static final int common_google_play_services_invalid_account_text = 2131165213;
    public static final int common_google_play_services_invalid_account_title = 2131165212;
    public static final int common_google_play_services_network_error_text = 2131165211;
    public static final int common_google_play_services_network_error_title = 2131165210;
    public static final int common_google_play_services_unknown_issue = 2131165214;
    public static final int common_google_play_services_unsupported_date_text = 2131165217;
    public static final int common_google_play_services_unsupported_text = 2131165216;
    public static final int common_google_play_services_unsupported_title = 2131165215;
    public static final int common_google_play_services_update_button = 2131165218;
    public static final int common_google_play_services_update_text = 2131165209;
    public static final int common_google_play_services_update_title = 2131165208;
    public static final int common_signin_button_text = 2131165219;
    public static final int common_signin_button_text_long = 2131165220;
  }

  public static final class styleable
  {
    public static final int[] AdsAttrs = { 2130772099, 2130772100, 2130772101 };
    public static final int AdsAttrs_adSize = 0;
    public static final int AdsAttrs_adSizes = 1;
    public static final int AdsAttrs_adUnitId = 2;
    public static final int[] MapAttrs = { 2130772102, 2130772103, 2130772104, 2130772105, 2130772106, 2130772107, 2130772108, 2130772109, 2130772110, 2130772111, 2130772112, 2130772113, 2130772114, 2130772115 };
    public static final int MapAttrs_cameraBearing = 1;
    public static final int MapAttrs_cameraTargetLat = 2;
    public static final int MapAttrs_cameraTargetLng = 3;
    public static final int MapAttrs_cameraTilt = 4;
    public static final int MapAttrs_cameraZoom = 5;
    public static final int MapAttrs_mapType = 0;
    public static final int MapAttrs_uiCompass = 6;
    public static final int MapAttrs_uiRotateGestures = 7;
    public static final int MapAttrs_uiScrollGestures = 8;
    public static final int MapAttrs_uiTiltGestures = 9;
    public static final int MapAttrs_uiZoomControls = 10;
    public static final int MapAttrs_uiZoomGestures = 11;
    public static final int MapAttrs_useViewLifecycle = 12;
    public static final int MapAttrs_zOrderOnTop = 13;
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.R
 * JD-Core Version:    0.6.2
 */