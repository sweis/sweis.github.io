package com.google.android.gms.internal;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import java.util.HashMap;
import java.util.Map;

public final class am
{
  public static final an fn = new an()
  {
    public void a(cw paramAnonymouscw, Map<String, String> paramAnonymousMap)
    {
      String str1 = (String)paramAnonymousMap.get("urls");
      if (str1 == null)
      {
        ct.v("URLs missing in canOpenURLs GMSG.");
        return;
      }
      String[] arrayOfString1 = str1.split(",");
      HashMap localHashMap = new HashMap();
      PackageManager localPackageManager = paramAnonymouscw.getContext().getPackageManager();
      int i = arrayOfString1.length;
      int j = 0;
      if (j < i)
      {
        String str2 = arrayOfString1[j];
        String[] arrayOfString2 = str2.split(";", 2);
        String str3 = arrayOfString2[0].trim();
        String str4;
        if (arrayOfString2.length > 1)
        {
          str4 = arrayOfString2[1].trim();
          label105: if (localPackageManager.resolveActivity(new Intent(str4, Uri.parse(str3)), 65536) == null)
            break label158;
        }
        label158: for (boolean bool = true; ; bool = false)
        {
          localHashMap.put(str2, Boolean.valueOf(bool));
          j++;
          break;
          str4 = "android.intent.action.VIEW";
          break label105;
        }
      }
      paramAnonymouscw.a("openableURLs", localHashMap);
    }
  };
  public static final an fo = new an()
  {
    public void a(cw paramAnonymouscw, Map<String, String> paramAnonymousMap)
    {
      String str1 = (String)paramAnonymousMap.get("u");
      if (str1 == null)
      {
        ct.v("URL missing from click GMSG.");
        return;
      }
      Uri localUri1 = Uri.parse(str1);
      try
      {
        h localh = paramAnonymouscw.aD();
        if ((localh != null) && (localh.a(localUri1)))
        {
          Uri localUri3 = localh.a(localUri1, paramAnonymouscw.getContext());
          localUri2 = localUri3;
          String str2 = localUri2.toString();
          new cr(paramAnonymouscw.getContext(), paramAnonymouscw.aE().iJ, str2).start();
          return;
        }
      }
      catch (i locali)
      {
        while (true)
        {
          ct.v("Unable to append parameter to URL: " + str1);
          Uri localUri2 = localUri1;
        }
      }
    }
  };
  public static final an fp = new an()
  {
    public void a(cw paramAnonymouscw, Map<String, String> paramAnonymousMap)
    {
      bk localbk = paramAnonymouscw.aB();
      if (localbk == null)
      {
        ct.v("A GMSG tried to close something that wasn't an overlay.");
        return;
      }
      localbk.close();
    }
  };
  public static final an fq = new an()
  {
    public void a(cw paramAnonymouscw, Map<String, String> paramAnonymousMap)
    {
      bk localbk = paramAnonymouscw.aB();
      if (localbk == null)
      {
        ct.v("A GMSG tried to use a custom close button on something that wasn't an overlay.");
        return;
      }
      localbk.g("1".equals(paramAnonymousMap.get("custom_close")));
    }
  };
  public static final an fr = new an()
  {
    public void a(cw paramAnonymouscw, Map<String, String> paramAnonymousMap)
    {
      String str = (String)paramAnonymousMap.get("u");
      if (str == null)
      {
        ct.v("URL missing from httpTrack GMSG.");
        return;
      }
      new cr(paramAnonymouscw.getContext(), paramAnonymouscw.aE().iJ, str).start();
    }
  };
  public static final an fs = new an()
  {
    public void a(cw paramAnonymouscw, Map<String, String> paramAnonymousMap)
    {
      ct.t("Received log message: " + (String)paramAnonymousMap.get("string"));
    }
  };
  public static final an ft = new ao();
  public static final an fu = new an()
  {
    public void a(cw paramAnonymouscw, Map<String, String> paramAnonymousMap)
    {
      String str1 = (String)paramAnonymousMap.get("tx");
      String str2 = (String)paramAnonymousMap.get("ty");
      String str3 = (String)paramAnonymousMap.get("td");
      try
      {
        int i = Integer.parseInt(str1);
        int j = Integer.parseInt(str2);
        int k = Integer.parseInt(str3);
        h localh = paramAnonymouscw.aD();
        if (localh != null)
          localh.g().a(i, j, k);
        return;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        ct.v("Could not parse touch parameters from gmsg.");
      }
    }
  };
  public static final an fv = new ap();
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.am
 * JD-Core Version:    0.6.2
 */