package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class bl
  implements Parcelable.Creator<bm>
{
  static void a(bm parambm, Parcel paramParcel, int paramInt)
  {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1, parambm.versionCode);
    b.a(paramParcel, 2, parambm.gG, paramInt, false);
    b.a(paramParcel, 3, parambm.aa(), false);
    b.a(paramParcel, 4, parambm.ab(), false);
    b.a(paramParcel, 5, parambm.ac(), false);
    b.a(paramParcel, 6, parambm.ad(), false);
    b.a(paramParcel, 7, parambm.gL, false);
    b.a(paramParcel, 8, parambm.gM);
    b.a(paramParcel, 9, parambm.gN, false);
    b.a(paramParcel, 10, parambm.ae(), false);
    b.c(paramParcel, 11, parambm.orientation);
    b.c(paramParcel, 12, parambm.gP);
    b.a(paramParcel, 13, parambm.go, false);
    b.a(paramParcel, 14, parambm.ej, paramInt, false);
    b.D(paramParcel, i);
  }

  public bm e(Parcel paramParcel)
  {
    int i = a.n(paramParcel);
    int j = 0;
    bj localbj = null;
    IBinder localIBinder1 = null;
    IBinder localIBinder2 = null;
    IBinder localIBinder3 = null;
    IBinder localIBinder4 = null;
    String str1 = null;
    boolean bool = false;
    String str2 = null;
    IBinder localIBinder5 = null;
    int k = 0;
    int m = 0;
    String str3 = null;
    cu localcu = null;
    while (paramParcel.dataPosition() < i)
    {
      int n = a.m(paramParcel);
      switch (a.M(n))
      {
      default:
        a.b(paramParcel, n);
        break;
      case 1:
        j = a.g(paramParcel, n);
        break;
      case 2:
        localbj = (bj)a.a(paramParcel, n, bj.CREATOR);
        break;
      case 3:
        localIBinder1 = a.n(paramParcel, n);
        break;
      case 4:
        localIBinder2 = a.n(paramParcel, n);
        break;
      case 5:
        localIBinder3 = a.n(paramParcel, n);
        break;
      case 6:
        localIBinder4 = a.n(paramParcel, n);
        break;
      case 7:
        str1 = a.m(paramParcel, n);
        break;
      case 8:
        bool = a.c(paramParcel, n);
        break;
      case 9:
        str2 = a.m(paramParcel, n);
        break;
      case 10:
        localIBinder5 = a.n(paramParcel, n);
        break;
      case 11:
        k = a.g(paramParcel, n);
        break;
      case 12:
        m = a.g(paramParcel, n);
        break;
      case 13:
        str3 = a.m(paramParcel, n);
        break;
      case 14:
        localcu = (cu)a.a(paramParcel, n, cu.CREATOR);
      }
    }
    if (paramParcel.dataPosition() != i)
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    return new bm(j, localbj, localIBinder1, localIBinder2, localIBinder3, localIBinder4, str1, bool, str2, localIBinder5, k, m, str3, localcu);
  }

  public bm[] j(int paramInt)
  {
    return new bm[paramInt];
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.bl
 * JD-Core Version:    0.6.2
 */