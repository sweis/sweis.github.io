package com.google.android.gms.internal;

import android.util.Log;

public class dk
{
  private static boolean mb = false;
  private String mTag;
  private boolean mc;
  private boolean md;

  public dk(String paramString)
  {
    this(paramString, bc());
  }

  public dk(String paramString, boolean paramBoolean)
  {
    this.mTag = paramString;
    this.mc = paramBoolean;
  }

  public static boolean bc()
  {
    return mb;
  }

  public void a(String paramString, Object[] paramArrayOfObject)
  {
    if (this.md)
      Log.v(this.mTag, String.format(paramString, paramArrayOfObject));
  }

  public void b(String paramString, Object[] paramArrayOfObject)
  {
    if ((this.mc) || (mb))
      Log.d(this.mTag, String.format(paramString, paramArrayOfObject));
  }

  public void c(String paramString, Object[] paramArrayOfObject)
  {
    Log.i(this.mTag, String.format(paramString, paramArrayOfObject));
  }

  public void d(String paramString, Object[] paramArrayOfObject)
  {
    Log.w(this.mTag, String.format(paramString, paramArrayOfObject));
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dk
 * JD-Core Version:    0.6.2
 */