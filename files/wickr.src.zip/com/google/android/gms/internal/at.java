package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class at
{
  public final String adJson;
  public final String fD;
  public final List<String> fE;
  public final String fF;
  public final List<String> fG;
  public final String fH;

  public at(JSONObject paramJSONObject)
    throws JSONException
  {
    this.fD = paramJSONObject.getString("id");
    JSONArray localJSONArray = paramJSONObject.getJSONArray("adapters");
    ArrayList localArrayList = new ArrayList(localJSONArray.length());
    for (int i = 0; i < localJSONArray.length(); i++)
      localArrayList.add(localJSONArray.getString(i));
    this.fE = Collections.unmodifiableList(localArrayList);
    this.fF = paramJSONObject.optString("allocation_id", null);
    this.fG = az.a(paramJSONObject, "imp_urls");
    JSONObject localJSONObject1 = paramJSONObject.optJSONObject("ad");
    if (localJSONObject1 != null);
    for (String str1 = localJSONObject1.toString(); ; str1 = null)
    {
      this.adJson = str1;
      JSONObject localJSONObject2 = paramJSONObject.optJSONObject("data");
      String str2 = null;
      if (localJSONObject2 != null)
        str2 = localJSONObject2.toString();
      this.fH = str2;
      return;
    }
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.at
 * JD-Core Version:    0.6.2
 */