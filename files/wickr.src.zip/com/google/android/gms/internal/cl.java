package com.google.android.gms.internal;

import android.content.Context;
import android.text.TextUtils;
import java.math.BigInteger;
import java.util.Locale;

public final class cl
{
  private static final Object hC = new Object();
  private static String iw;

  public static String as()
  {
    synchronized (hC)
    {
      String str = iw;
      return str;
    }
  }

  public static String b(Context paramContext, String paramString1, String paramString2)
  {
    synchronized (hC)
    {
      if ((iw == null) && (!TextUtils.isEmpty(paramString1)))
        c(paramContext, paramString1, paramString2);
      String str = iw;
      return str;
    }
  }

  private static void c(Context paramContext, String paramString1, String paramString2)
  {
    BigInteger localBigInteger2;
    try
    {
      ClassLoader localClassLoader = paramContext.createPackageContext(paramString2, 3).getClassLoader();
      Class localClass = Class.forName("com.google.ads.mediation.MediationAdapter", false, localClassLoader);
      BigInteger localBigInteger1 = new BigInteger(new byte[1]);
      String[] arrayOfString = paramString1.split(",");
      localBigInteger2 = localBigInteger1;
      for (int i = 0; i < arrayOfString.length; i++)
        if (co.a(localClassLoader, localClass, arrayOfString[i]))
          localBigInteger2 = localBigInteger2.setBit(i);
    }
    catch (Throwable localThrowable)
    {
      iw = "err";
      return;
    }
    iw = String.format(Locale.US, "%X", new Object[] { localBigInteger2 });
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cl
 * JD-Core Version:    0.6.2
 */