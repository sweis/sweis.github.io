package com.google.android.gms.internal;

public abstract interface bn
{
  public abstract void A();

  public abstract void B();
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.bn
 * JD-Core Version:    0.6.2
 */