package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.ArrayList;

public class cc
  implements Parcelable.Creator<cb>
{
  static void a(cb paramcb, Parcel paramParcel, int paramInt)
  {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1, paramcb.versionCode);
    b.a(paramParcel, 2, paramcb.gL, false);
    b.a(paramParcel, 3, paramcb.hw, false);
    b.a(paramParcel, 4, paramcb.fK, false);
    b.c(paramParcel, 5, paramcb.errorCode);
    b.a(paramParcel, 6, paramcb.fL, false);
    b.a(paramParcel, 7, paramcb.hx);
    b.a(paramParcel, 8, paramcb.hy);
    b.a(paramParcel, 9, paramcb.hz);
    b.a(paramParcel, 10, paramcb.hA, false);
    b.a(paramParcel, 11, paramcb.fO);
    b.c(paramParcel, 12, paramcb.orientation);
    b.a(paramParcel, 13, paramcb.hB, false);
    b.D(paramParcel, i);
  }

  public cb g(Parcel paramParcel)
  {
    int i = a.n(paramParcel);
    int j = 0;
    String str1 = null;
    String str2 = null;
    ArrayList localArrayList1 = null;
    int k = 0;
    ArrayList localArrayList2 = null;
    long l1 = 0L;
    boolean bool = false;
    long l2 = 0L;
    ArrayList localArrayList3 = null;
    long l3 = 0L;
    int m = 0;
    String str3 = null;
    while (paramParcel.dataPosition() < i)
    {
      int n = a.m(paramParcel);
      switch (a.M(n))
      {
      default:
        a.b(paramParcel, n);
        break;
      case 1:
        j = a.g(paramParcel, n);
        break;
      case 2:
        str1 = a.m(paramParcel, n);
        break;
      case 3:
        str2 = a.m(paramParcel, n);
        break;
      case 4:
        localArrayList1 = a.y(paramParcel, n);
        break;
      case 5:
        k = a.g(paramParcel, n);
        break;
      case 6:
        localArrayList2 = a.y(paramParcel, n);
        break;
      case 7:
        l1 = a.h(paramParcel, n);
        break;
      case 8:
        bool = a.c(paramParcel, n);
        break;
      case 9:
        l2 = a.h(paramParcel, n);
        break;
      case 10:
        localArrayList3 = a.y(paramParcel, n);
        break;
      case 11:
        l3 = a.h(paramParcel, n);
        break;
      case 12:
        m = a.g(paramParcel, n);
        break;
      case 13:
        str3 = a.m(paramParcel, n);
      }
    }
    if (paramParcel.dataPosition() != i)
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    return new cb(j, str1, str2, localArrayList1, k, localArrayList2, l1, bool, l2, localArrayList3, l3, m, str3);
  }

  public cb[] l(int paramInt)
  {
    return new cb[paramInt];
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cc
 * JD-Core Version:    0.6.2
 */