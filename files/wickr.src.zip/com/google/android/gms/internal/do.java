package com.google.android.gms.internal;

import android.os.SystemClock;
import org.json.JSONObject;

public final class do
{
  private static final dk lA = new dk("RequestTracker");
  public static final Object mw = new Object();
  private long ms;
  private long mt;
  private long mu;
  private dn mv;

  public do(long paramLong)
  {
    this.ms = paramLong;
    this.mt = -1L;
    this.mu = 0L;
  }

  private void be()
  {
    this.mt = -1L;
    this.mv = null;
    this.mu = 0L;
  }

  public void a(long paramLong, dn paramdn)
  {
    synchronized (mw)
    {
      dn localdn = this.mv;
      long l = this.mt;
      this.mt = paramLong;
      this.mv = paramdn;
      this.mu = SystemClock.elapsedRealtime();
      if (localdn != null)
        localdn.g(l);
      return;
    }
  }

  public boolean b(long paramLong, int paramInt, JSONObject paramJSONObject)
  {
    for (boolean bool = true; ; bool = false)
    {
      synchronized (mw)
      {
        if ((this.mt != -1L) && (this.mt == paramLong))
        {
          dk localdk = lA;
          Object[] arrayOfObject = new Object[1];
          arrayOfObject[0] = Long.valueOf(this.mt);
          localdk.b("request %d completed", arrayOfObject);
          localdn = this.mv;
          be();
          if (localdn != null)
            localdn.a(paramLong, paramInt, paramJSONObject);
          return bool;
        }
      }
      dn localdn = null;
    }
  }

  public boolean bf()
  {
    while (true)
    {
      synchronized (mw)
      {
        if (this.mt != -1L)
        {
          bool = true;
          return bool;
        }
      }
      boolean bool = false;
    }
  }

  public boolean c(long paramLong, int paramInt)
  {
    return b(paramLong, paramInt, null);
  }

  public void clear()
  {
    synchronized (mw)
    {
      if (this.mt != -1L)
        be();
      return;
    }
  }

  public boolean d(long paramLong, int paramInt)
  {
    boolean bool = true;
    long l = 0L;
    while (true)
    {
      synchronized (mw)
      {
        if ((this.mt != -1L) && (paramLong - this.mu >= this.ms))
        {
          dk localdk = lA;
          Object[] arrayOfObject = new Object[1];
          arrayOfObject[0] = Long.valueOf(this.mt);
          localdk.b("request %d timed out", arrayOfObject);
          l = this.mt;
          localdn = this.mv;
          be();
          if (localdn != null)
            localdn.a(l, paramInt, null);
          return bool;
        }
      }
      dn localdn = null;
      bool = false;
    }
  }

  public boolean i(long paramLong)
  {
    while (true)
    {
      synchronized (mw)
      {
        if ((this.mt != -1L) && (this.mt == paramLong))
        {
          bool = true;
          return bool;
        }
      }
      boolean bool = false;
    }
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.do
 * JD-Core Version:    0.6.2
 */