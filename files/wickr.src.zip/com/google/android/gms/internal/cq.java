package com.google.android.gms.internal;

import android.content.Context;
import android.webkit.WebSettings;

public final class cq
{
  public static void a(Context paramContext, WebSettings paramWebSettings)
  {
    cp.a(paramContext, paramWebSettings);
    paramWebSettings.setMediaPlaybackRequiresUserGesture(false);
  }

  public static String getDefaultUserAgent(Context paramContext)
  {
    return WebSettings.getDefaultUserAgent(paramContext);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cq
 * JD-Core Version:    0.6.2
 */