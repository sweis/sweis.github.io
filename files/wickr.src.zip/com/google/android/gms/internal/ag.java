package com.google.android.gms.internal;

import android.content.Context;
import android.os.RemoteException;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.doubleclick.AppEventListener;
import com.google.android.gms.dynamic.b;
import com.google.android.gms.dynamic.c;

public final class ag
{
  private AppEventListener eI;
  private AdSize[] eJ;
  private String eK;
  private final ba eW = new ba();
  private ac eX;
  private ViewGroup eY;
  private AdListener ev;

  public ag(ViewGroup paramViewGroup)
  {
    this.eY = paramViewGroup;
  }

  public ag(ViewGroup paramViewGroup, AttributeSet paramAttributeSet, boolean paramBoolean)
  {
    this.eY = paramViewGroup;
    Context localContext = paramViewGroup.getContext();
    try
    {
      aa localaa = new aa(localContext, paramAttributeSet);
      this.eJ = localaa.c(paramBoolean);
      this.eK = localaa.getAdUnitId();
      if (paramViewGroup.isInEditMode())
        cs.a(paramViewGroup, new x(localContext, this.eJ[0]), "Ads by Google");
      return;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      cs.a(paramViewGroup, new x(localContext, AdSize.BANNER), localIllegalArgumentException.getMessage(), localIllegalArgumentException.getMessage());
    }
  }

  private void T()
  {
    try
    {
      b localb = this.eX.x();
      if (localb == null)
        return;
      this.eY.addView((View)c.b(localb));
      return;
    }
    catch (RemoteException localRemoteException)
    {
      ct.b("Failed to get an ad frame.", localRemoteException);
    }
  }

  private void U()
    throws RemoteException
  {
    if (((this.eJ == null) || (this.eK == null)) && (this.eX == null))
      throw new IllegalStateException("The ad size and ad unit ID must be set before loadAd is called.");
    Context localContext = this.eY.getContext();
    this.eX = u.a(localContext, new x(localContext, this.eJ), this.eK, this.eW);
    if (this.ev != null)
      this.eX.a(new t(this.ev));
    if (this.eI != null)
      this.eX.a(new z(this.eI));
    T();
  }

  public void a(af paramaf)
  {
    try
    {
      if (this.eX == null)
        U();
      if (this.eX.a(new v(this.eY.getContext(), paramaf)))
        this.eW.c(paramaf.R());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      ct.b("Failed to load ad.", localRemoteException);
    }
  }

  public void a(AdSize[] paramArrayOfAdSize)
  {
    this.eJ = paramArrayOfAdSize;
    try
    {
      if (this.eX != null)
        this.eX.a(new x(this.eY.getContext(), this.eJ));
      this.eY.requestLayout();
      return;
    }
    catch (RemoteException localRemoteException)
    {
      while (true)
        ct.b("Failed to set the ad size.", localRemoteException);
    }
  }

  public void destroy()
  {
    try
    {
      if (this.eX != null)
        this.eX.destroy();
      return;
    }
    catch (RemoteException localRemoteException)
    {
      ct.b("Failed to destroy AdView.", localRemoteException);
    }
  }

  public AdListener getAdListener()
  {
    return this.ev;
  }

  public AdSize getAdSize()
  {
    try
    {
      if (this.eX != null)
      {
        AdSize localAdSize = this.eX.y().P();
        return localAdSize;
      }
    }
    catch (RemoteException localRemoteException)
    {
      ct.b("Failed to get the current AdSize.", localRemoteException);
      if (this.eJ != null)
        return this.eJ[0];
    }
    return null;
  }

  public AdSize[] getAdSizes()
  {
    return this.eJ;
  }

  public String getAdUnitId()
  {
    return this.eK;
  }

  public AppEventListener getAppEventListener()
  {
    return this.eI;
  }

  public void pause()
  {
    try
    {
      if (this.eX != null)
        this.eX.pause();
      return;
    }
    catch (RemoteException localRemoteException)
    {
      ct.b("Failed to call pause.", localRemoteException);
    }
  }

  public void recordManualImpression()
  {
    try
    {
      this.eX.H();
      return;
    }
    catch (RemoteException localRemoteException)
    {
      ct.b("Failed to record impression.", localRemoteException);
    }
  }

  public void resume()
  {
    try
    {
      if (this.eX != null)
        this.eX.resume();
      return;
    }
    catch (RemoteException localRemoteException)
    {
      ct.b("Failed to call resume.", localRemoteException);
    }
  }

  public void setAdListener(AdListener paramAdListener)
  {
    try
    {
      this.ev = paramAdListener;
      ac localac;
      if (this.eX != null)
      {
        localac = this.eX;
        if (paramAdListener == null)
          break label40;
      }
      label40: for (t localt = new t(paramAdListener); ; localt = null)
      {
        localac.a(localt);
        return;
      }
    }
    catch (RemoteException localRemoteException)
    {
      ct.b("Failed to set the AdListener.", localRemoteException);
    }
  }

  public void setAdSizes(AdSize[] paramArrayOfAdSize)
  {
    if (this.eJ != null)
      throw new IllegalStateException("The ad size can only be set once on AdView.");
    a(paramArrayOfAdSize);
  }

  public void setAdUnitId(String paramString)
  {
    if (this.eK != null)
      throw new IllegalStateException("The ad unit ID can only be set once on AdView.");
    this.eK = paramString;
  }

  public void setAppEventListener(AppEventListener paramAppEventListener)
  {
    try
    {
      this.eI = paramAppEventListener;
      ac localac;
      if (this.eX != null)
      {
        localac = this.eX;
        if (paramAppEventListener == null)
          break label40;
      }
      label40: for (z localz = new z(paramAppEventListener); ; localz = null)
      {
        localac.a(localz);
        return;
      }
    }
    catch (RemoteException localRemoteException)
    {
      ct.b("Failed to set the AppEventListener.", localRemoteException);
    }
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ag
 * JD-Core Version:    0.6.2
 */