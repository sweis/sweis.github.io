package com.google.android.gms.internal;

import java.util.Map;

public abstract interface an
{
  public abstract void a(cw paramcw, Map<String, String> paramMap);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.an
 * JD-Core Version:    0.6.2
 */