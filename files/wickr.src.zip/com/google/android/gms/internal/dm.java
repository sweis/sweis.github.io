package com.google.android.gms.internal;

import java.io.IOException;

public abstract interface dm
{
  public abstract void a(String paramString1, String paramString2, long paramLong, String paramString3)
    throws IOException;

  public abstract long aR();
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dm
 * JD-Core Version:    0.6.2
 */