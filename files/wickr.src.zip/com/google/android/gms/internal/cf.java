package com.google.android.gms.internal;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.graphics.Color;
import android.location.Location;
import android.text.TextUtils;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class cf
{
  private static final SimpleDateFormat hJ = new SimpleDateFormat("yyyyMMdd");

  public static cb a(Context paramContext, bz parambz, String paramString)
  {
    String str1;
    String str3;
    String str4;
    long l;
    int i;
    cb localcb3;
    label183: Object localObject1;
    label221: int m;
    label317: Object localObject3;
    label355: int k;
    label396: Object localObject5;
    label434: int j;
    while (true)
    {
      JSONObject localJSONObject;
      try
      {
        localJSONObject = new JSONObject(paramString);
        str1 = localJSONObject.optString("ad_base_url", null);
        String str2 = localJSONObject.optString("ad_url", null);
        str3 = localJSONObject.optString("ad_size", null);
        str4 = localJSONObject.optString("ad_html", null);
        if (!localJSONObject.has("interstitial_timeout"))
          break label575;
        l = ()(1000.0D * localJSONObject.getDouble("interstitial_timeout"));
        String str5 = localJSONObject.optString("orientation", null);
        i = -1;
        if ("portrait".equals(str5))
        {
          i = co.av();
          if (!TextUtils.isEmpty(str4))
          {
            if (!TextUtils.isEmpty(str1))
              break label569;
            ct.v("Could not parse the mediation config: Missing required ad_base_url field");
            return new cb(0);
          }
        }
        else
        {
          if (!"landscape".equals(str5))
            continue;
          i = co.au();
          continue;
        }
        if (!TextUtils.isEmpty(str2))
        {
          cb localcb2 = ce.a(paramContext, parambz.ej.iJ, str2);
          str1 = localcb2.gL;
          str4 = localcb2.hw;
          localcb3 = localcb2;
          JSONArray localJSONArray1 = localJSONObject.optJSONArray("click_urls");
          if (localcb3 == null)
          {
            localObject1 = null;
            if (localJSONArray1 == null)
              break;
            if (localObject1 != null)
              break label583;
            localObject1 = new LinkedList();
            break label583;
            if (m >= localJSONArray1.length())
              break label589;
            ((List)localObject1).add(localJSONArray1.getString(m));
            m++;
            continue;
          }
        }
        else
        {
          ct.v("Could not parse the mediation config: Missing required ad_html or ad_url field.");
          cb localcb1 = new cb(0);
          return localcb1;
        }
      }
      catch (JSONException localJSONException)
      {
        ct.v("Could not parse the mediation config: " + localJSONException.getMessage());
        return new cb(0);
      }
      localObject1 = localcb3.fK;
      continue;
      JSONArray localJSONArray2 = localJSONObject.optJSONArray("impression_urls");
      if (localcb3 == null)
        localObject3 = null;
      while (localJSONArray2 != null)
      {
        if (localObject3 != null)
          break label596;
        localObject3 = new LinkedList();
        break label596;
        while (k < localJSONArray2.length())
        {
          ((List)localObject3).add(localJSONArray2.getString(k));
          k++;
        }
        localObject3 = localcb3.fL;
        continue;
        JSONArray localJSONArray3 = localJSONObject.optJSONArray("manual_impression_urls");
        if (localcb3 == null);
        for (localObject5 = null; localJSONArray3 != null; localObject5 = localcb3.hA)
        {
          if (localObject5 != null)
            break label609;
          localObject5 = new LinkedList();
          break label609;
          while (j < localJSONArray3.length())
          {
            ((List)localObject5).add(localJSONArray3.getString(j));
            j++;
          }
        }
      }
    }
    while (true)
    {
      if (localcb3 != null)
      {
        if (localcb3.orientation != -1)
          i = localcb3.orientation;
        if (localcb3.hx > 0L)
          l = localcb3.hx;
      }
      cb localcb4 = new cb(str1, str4, (List)localObject2, (List)localObject4, l, false, -1L, (List)localObject6, -1L, i, str3);
      return localcb4;
      Object localObject6 = localObject5;
      continue;
      Object localObject4 = localObject3;
      break label396;
      Object localObject2 = localObject1;
      break label317;
      label569: localcb3 = null;
      break label183;
      label575: l = -1L;
      break;
      label583: m = 0;
      break label221;
      label589: localObject2 = localObject1;
      break label317;
      label596: k = 0;
      break label355;
      localObject4 = localObject3;
      break label396;
      label609: j = 0;
      break label434;
      localObject6 = localObject5;
    }
  }

  public static String a(bz parambz, ci paramci, Location paramLocation)
  {
    try
    {
      HashMap localHashMap = new HashMap();
      if (parambz.hq != null)
        localHashMap.put("ad_pos", parambz.hq);
      a(localHashMap, parambz.hr);
      localHashMap.put("format", parambz.em.eF);
      if (parambz.em.width == -1)
        localHashMap.put("smart_w", "full");
      if (parambz.em.height == -2)
        localHashMap.put("smart_h", "auto");
      if (parambz.em.eH != null)
      {
        StringBuilder localStringBuilder = new StringBuilder();
        x[] arrayOfx = parambz.em.eH;
        int i = arrayOfx.length;
        int j = 0;
        if (j < i)
        {
          x localx = arrayOfx[j];
          if (localStringBuilder.length() != 0)
            localStringBuilder.append("|");
          int k;
          if (localx.width == -1)
          {
            k = (int)(localx.widthPixels / paramci.ip);
            label178: localStringBuilder.append(k);
            localStringBuilder.append("x");
            if (localx.height != -2)
              break label242;
          }
          label242: for (int m = (int)(localx.heightPixels / paramci.ip); ; m = localx.height)
          {
            localStringBuilder.append(m);
            j++;
            break;
            k = localx.width;
            break label178;
          }
        }
        localHashMap.put("sz", localStringBuilder);
      }
      localHashMap.put("slotname", parambz.adUnitId);
      localHashMap.put("pn", parambz.applicationInfo.packageName);
      if (parambz.hs != null)
        localHashMap.put("vc", Integer.valueOf(parambz.hs.versionCode));
      localHashMap.put("ms", parambz.ht);
      localHashMap.put("seq_num", parambz.hu);
      localHashMap.put("session_id", parambz.hv);
      localHashMap.put("js", parambz.ej.iJ);
      a(localHashMap, paramci);
      if ((parambz.hr.versionCode >= 2) && (parambz.hr.eE != null))
        a(localHashMap, parambz.hr.eE);
      if (ct.n(2))
      {
        String str2 = co.m(localHashMap).toString(2);
        ct.u("Ad Request JSON: " + str2);
      }
      String str1 = co.m(localHashMap).toString();
      return str1;
    }
    catch (JSONException localJSONException)
    {
      ct.v("Problem serializing ad request to JSON: " + localJSONException.getMessage());
    }
    return null;
  }

  private static void a(HashMap<String, Object> paramHashMap, Location paramLocation)
  {
    HashMap localHashMap = new HashMap();
    Float localFloat = Float.valueOf(1000.0F * paramLocation.getAccuracy());
    Long localLong1 = Long.valueOf(1000L * paramLocation.getTime());
    Long localLong2 = Long.valueOf(()(10000000.0D * paramLocation.getLatitude()));
    Long localLong3 = Long.valueOf(()(10000000.0D * paramLocation.getLongitude()));
    localHashMap.put("radius", localFloat);
    localHashMap.put("lat", localLong2);
    localHashMap.put("long", localLong3);
    localHashMap.put("time", localLong1);
    paramHashMap.put("uule", localHashMap);
  }

  private static void a(HashMap<String, Object> paramHashMap, ai paramai)
  {
    if (Color.alpha(paramai.eZ) != 0)
      paramHashMap.put("acolor", m(paramai.eZ));
    if (Color.alpha(paramai.backgroundColor) != 0)
      paramHashMap.put("bgcolor", m(paramai.backgroundColor));
    if ((Color.alpha(paramai.fa) != 0) && (Color.alpha(paramai.fb) != 0))
    {
      paramHashMap.put("gradientto", m(paramai.fa));
      paramHashMap.put("gradientfrom", m(paramai.fb));
    }
    if (Color.alpha(paramai.fc) != 0)
      paramHashMap.put("bcolor", m(paramai.fc));
    paramHashMap.put("bthick", Integer.toString(paramai.fd));
    Object localObject1;
    Object localObject2;
    switch (paramai.fe)
    {
    default:
      localObject1 = null;
      if (localObject1 != null)
        paramHashMap.put("btype", localObject1);
      int i = paramai.ff;
      localObject2 = null;
      switch (i)
      {
      default:
      case 2:
      case 0:
      case 1:
      }
      break;
    case 0:
    case 1:
    case 2:
    case 3:
    }
    while (true)
    {
      if (localObject2 != null)
        paramHashMap.put("callbuttoncolor", localObject2);
      if (paramai.fg != null)
        paramHashMap.put("channel", paramai.fg);
      if (Color.alpha(paramai.fh) != 0)
        paramHashMap.put("dcolor", m(paramai.fh));
      if (paramai.fi != null)
        paramHashMap.put("font", paramai.fi);
      if (Color.alpha(paramai.fj) != 0)
        paramHashMap.put("hcolor", m(paramai.fj));
      paramHashMap.put("headersize", Integer.toString(paramai.fk));
      if (paramai.fl != null)
        paramHashMap.put("q", paramai.fl);
      return;
      localObject1 = "none";
      break;
      localObject1 = "dashed";
      break;
      localObject1 = "dotted";
      break;
      localObject1 = "solid";
      break;
      localObject2 = "dark";
      continue;
      localObject2 = "light";
      continue;
      localObject2 = "medium";
    }
  }

  private static void a(HashMap<String, Object> paramHashMap, ci paramci)
  {
    paramHashMap.put("am", Integer.valueOf(paramci.hZ));
    paramHashMap.put("cog", j(paramci.ia));
    paramHashMap.put("coh", j(paramci.ib));
    if (!TextUtils.isEmpty(paramci.ic))
      paramHashMap.put("carrier", paramci.ic);
    paramHashMap.put("gl", paramci.id);
    if (paramci.ie)
      paramHashMap.put("simulator", Integer.valueOf(1));
    paramHashMap.put("ma", j(paramci.jdField_if));
    paramHashMap.put("sp", j(paramci.ig));
    paramHashMap.put("hl", paramci.ih);
    if (!TextUtils.isEmpty(paramci.ii))
      paramHashMap.put("mv", paramci.ii);
    paramHashMap.put("muv", Integer.valueOf(paramci.ij));
    if (paramci.ik != -2)
      paramHashMap.put("cnt", Integer.valueOf(paramci.ik));
    paramHashMap.put("gnt", Integer.valueOf(paramci.il));
    paramHashMap.put("pt", Integer.valueOf(paramci.im));
    paramHashMap.put("rm", Integer.valueOf(paramci.in));
    paramHashMap.put("riv", Integer.valueOf(paramci.io));
    paramHashMap.put("u_sd", Float.valueOf(paramci.ip));
    paramHashMap.put("sh", Integer.valueOf(paramci.ir));
    paramHashMap.put("sw", Integer.valueOf(paramci.iq));
  }

  private static void a(HashMap<String, Object> paramHashMap, v paramv)
  {
    String str = cl.as();
    if (str != null)
      paramHashMap.put("abf", str);
    if (paramv.ex != -1L)
      paramHashMap.put("cust_age", hJ.format(new Date(paramv.ex)));
    if (paramv.extras != null)
      paramHashMap.put("extras", paramv.extras);
    if (paramv.ey != -1)
      paramHashMap.put("cust_gender", Integer.valueOf(paramv.ey));
    if (paramv.ez != null)
      paramHashMap.put("kw", paramv.ez);
    if (paramv.tagForChildDirectedTreatment != -1)
      paramHashMap.put("tag_for_child_directed_treatment", Integer.valueOf(paramv.tagForChildDirectedTreatment));
    if (paramv.eA)
      paramHashMap.put("adtest", "on");
    if (paramv.versionCode >= 2)
    {
      if (paramv.eB)
        paramHashMap.put("d_imp_hdr", Integer.valueOf(1));
      if (!TextUtils.isEmpty(paramv.eC))
        paramHashMap.put("ppid", paramv.eC);
      if (paramv.eD != null)
        a(paramHashMap, paramv.eD);
    }
  }

  private static Integer j(boolean paramBoolean)
  {
    if (paramBoolean);
    for (int i = 1; ; i = 0)
      return Integer.valueOf(i);
  }

  private static String m(int paramInt)
  {
    Locale localLocale = Locale.US;
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = Integer.valueOf(0xFFFFFF & paramInt);
    return String.format(localLocale, "#%06x", arrayOfObject);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cf
 * JD-Core Version:    0.6.2
 */