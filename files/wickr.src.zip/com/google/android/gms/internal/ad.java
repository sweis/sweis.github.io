package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.b;
import com.google.android.gms.dynamic.b.a;

public abstract interface ad extends IInterface
{
  public abstract IBinder a(b paramb, x paramx, String paramString, bb parambb, int paramInt)
    throws RemoteException;

  public static abstract class a extends Binder
    implements ad
  {
    public static ad g(IBinder paramIBinder)
    {
      if (paramIBinder == null)
        return null;
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.internal.client.IAdManagerCreator");
      if ((localIInterface != null) && ((localIInterface instanceof ad)))
        return (ad)localIInterface;
      return new a(paramIBinder);
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default:
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
        paramParcel2.writeString("com.google.android.gms.ads.internal.client.IAdManagerCreator");
        return true;
      case 1:
      }
      paramParcel1.enforceInterface("com.google.android.gms.ads.internal.client.IAdManagerCreator");
      b localb = b.a.E(paramParcel1.readStrongBinder());
      if (paramParcel1.readInt() != 0);
      for (x localx = x.CREATOR.b(paramParcel1); ; localx = null)
      {
        IBinder localIBinder = a(localb, localx, paramParcel1.readString(), bb.a.i(paramParcel1.readStrongBinder()), paramParcel1.readInt());
        paramParcel2.writeNoException();
        paramParcel2.writeStrongBinder(localIBinder);
        return true;
      }
    }

    private static class a
      implements ad
    {
      private IBinder dU;

      a(IBinder paramIBinder)
      {
        this.dU = paramIBinder;
      }

      public IBinder a(b paramb, x paramx, String paramString, bb parambb, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.ads.internal.client.IAdManagerCreator");
          IBinder localIBinder1;
          if (paramb != null)
          {
            localIBinder1 = paramb.asBinder();
            localParcel1.writeStrongBinder(localIBinder1);
            if (paramx == null)
              break label137;
            localParcel1.writeInt(1);
            paramx.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            localParcel1.writeString(paramString);
            IBinder localIBinder2 = null;
            if (parambb != null)
              localIBinder2 = parambb.asBinder();
            localParcel1.writeStrongBinder(localIBinder2);
            localParcel1.writeInt(paramInt);
            this.dU.transact(1, localParcel1, localParcel2, 0);
            localParcel2.readException();
            IBinder localIBinder3 = localParcel2.readStrongBinder();
            return localIBinder3;
            localIBinder1 = null;
            break;
            label137: localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public IBinder asBinder()
      {
        return this.dU;
      }
    }
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ad
 * JD-Core Version:    0.6.2
 */