package com.google.android.gms.internal;

import android.location.Location;

public abstract interface aq
{
  public abstract Location a(long paramLong);

  public abstract void init();
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.aq
 * JD-Core Version:    0.6.2
 */