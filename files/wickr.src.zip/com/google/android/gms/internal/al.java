package com.google.android.gms.internal;

public abstract interface al
{
  public abstract void onAppEvent(String paramString1, String paramString2);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.al
 * JD-Core Version:    0.6.2
 */