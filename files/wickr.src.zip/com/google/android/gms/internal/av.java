package com.google.android.gms.internal;

public abstract interface av
{
  public abstract void C();

  public abstract void D();

  public abstract void E();

  public abstract void F();

  public abstract void G();
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.av
 * JD-Core Version:    0.6.2
 */