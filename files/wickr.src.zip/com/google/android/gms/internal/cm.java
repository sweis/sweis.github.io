package com.google.android.gms.internal;

public abstract class cm
{
  private final Runnable ep = new Runnable()
  {
    public final void run()
    {
      cm.a(cm.this, Thread.currentThread());
      cm.this.ai();
    }
  };
  private volatile Thread ix;

  public abstract void ai();

  public final void cancel()
  {
    onStop();
    if (this.ix != null)
      this.ix.interrupt();
  }

  public abstract void onStop();

  public final void start()
  {
    cn.execute(this.ep);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cm
 * JD-Core Version:    0.6.2
 */