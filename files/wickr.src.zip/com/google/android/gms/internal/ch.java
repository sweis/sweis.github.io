package com.google.android.gms.internal;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public final class ch
{
  private String hP;
  private String hQ;
  private String hR;
  private List<String> hS;
  private List<String> hT;
  private long hU = -1L;
  private boolean hV = false;
  private final long hW = -1L;
  private List<String> hX;
  private long hY = -1L;
  private int mOrientation = -1;

  private static long a(Map<String, List<String>> paramMap, String paramString)
  {
    List localList = (List)paramMap.get(paramString);
    if ((localList != null) && (!localList.isEmpty()))
    {
      String str = (String)localList.get(0);
      try
      {
        float f = Float.parseFloat(str);
        return ()(f * 1000.0F);
      }
      catch (NumberFormatException localNumberFormatException)
      {
        ct.v("Could not parse float from " + paramString + " header: " + str);
      }
    }
    return -1L;
  }

  private static List<String> b(Map<String, List<String>> paramMap, String paramString)
  {
    List localList = (List)paramMap.get(paramString);
    if ((localList != null) && (!localList.isEmpty()))
    {
      String str = (String)localList.get(0);
      if (str != null)
        return Arrays.asList(str.trim().split("\\s+"));
    }
    return null;
  }

  private void e(Map<String, List<String>> paramMap)
  {
    List localList = (List)paramMap.get("X-Afma-Ad-Size");
    if ((localList != null) && (!localList.isEmpty()))
      this.hP = ((String)localList.get(0));
  }

  private void f(Map<String, List<String>> paramMap)
  {
    List localList = b(paramMap, "X-Afma-Click-Tracking-Urls");
    if (localList != null)
      this.hS = localList;
  }

  private void g(Map<String, List<String>> paramMap)
  {
    List localList = b(paramMap, "X-Afma-Tracking-Urls");
    if (localList != null)
      this.hT = localList;
  }

  private void h(Map<String, List<String>> paramMap)
  {
    long l = a(paramMap, "X-Afma-Interstitial-Timeout");
    if (l != -1L)
      this.hU = l;
  }

  private void i(Map<String, List<String>> paramMap)
  {
    List localList = (List)paramMap.get("X-Afma-Mediation");
    if ((localList != null) && (!localList.isEmpty()))
      this.hV = Boolean.valueOf((String)localList.get(0)).booleanValue();
  }

  private void j(Map<String, List<String>> paramMap)
  {
    List localList = b(paramMap, "X-Afma-Manual-Tracking-Urls");
    if (localList != null)
      this.hX = localList;
  }

  private void k(Map<String, List<String>> paramMap)
  {
    long l = a(paramMap, "X-Afma-Refresh-Rate");
    if (l != -1L)
      this.hY = l;
  }

  private void l(Map<String, List<String>> paramMap)
  {
    List localList = (List)paramMap.get("X-Afma-Orientation");
    String str;
    if ((localList != null) && (!localList.isEmpty()))
    {
      str = (String)localList.get(0);
      if (!"portrait".equalsIgnoreCase(str))
        break label53;
      this.mOrientation = co.av();
    }
    label53: 
    while (!"landscape".equalsIgnoreCase(str))
      return;
    this.mOrientation = co.au();
  }

  public void a(String paramString1, Map<String, List<String>> paramMap, String paramString2)
  {
    this.hQ = paramString1;
    this.hR = paramString2;
    d(paramMap);
  }

  public cb aq()
  {
    return new cb(this.hQ, this.hR, this.hS, this.hT, this.hU, this.hV, -1L, this.hX, this.hY, this.mOrientation, this.hP);
  }

  public void d(Map<String, List<String>> paramMap)
  {
    e(paramMap);
    f(paramMap);
    g(paramMap);
    h(paramMap);
    i(paramMap);
    j(paramMap);
    k(paramMap);
    l(paramMap);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ch
 * JD-Core Version:    0.6.2
 */