package com.google.android.gms.internal;

import org.json.JSONObject;

public abstract interface dn
{
  public abstract void a(long paramLong, int paramInt, JSONObject paramJSONObject);

  public abstract void g(long paramLong);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.dn
 * JD-Core Version:    0.6.2
 */