package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class eo
  implements Parcelable.Creator<en>
{
  static void a(en paramen, Parcel paramParcel, int paramInt)
  {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1, paramen.getVersionCode());
    b.a(paramParcel, 2, paramen.ce(), paramInt, false);
    b.D(paramParcel, i);
  }

  public en[] O(int paramInt)
  {
    return new en[paramInt];
  }

  public en q(Parcel paramParcel)
  {
    int i = a.n(paramParcel);
    int j = 0;
    ep localep = null;
    while (paramParcel.dataPosition() < i)
    {
      int k = a.m(paramParcel);
      switch (a.M(k))
      {
      default:
        a.b(paramParcel, k);
        break;
      case 1:
        j = a.g(paramParcel, k);
        break;
      case 2:
        localep = (ep)a.a(paramParcel, k, ep.CREATOR);
      }
    }
    if (paramParcel.dataPosition() != i)
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    return new en(j, localep);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.eo
 * JD-Core Version:    0.6.2
 */