package com.google.android.gms.internal;

public final class ay
{
  public final int ga;
  public final at gb;
  public final bc gc;
  public final String gd;
  public final aw ge;

  public ay(int paramInt)
  {
    this(null, null, null, null, paramInt);
  }

  public ay(at paramat, bc parambc, String paramString, aw paramaw, int paramInt)
  {
    this.gb = paramat;
    this.gc = parambc;
    this.gd = paramString;
    this.ge = paramaw;
    this.ga = paramInt;
  }

  public static abstract interface a
  {
    public abstract void f(int paramInt);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ay
 * JD-Core Version:    0.6.2
 */