package com.google.android.gms.internal;

public abstract interface bq
{
  public abstract void z();
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.bq
 * JD-Core Version:    0.6.2
 */