package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface cd extends IInterface
{
  public abstract cb b(bz parambz)
    throws RemoteException;

  public static abstract class a extends Binder
    implements cd
  {
    public a()
    {
      attachInterface(this, "com.google.android.gms.ads.internal.request.IAdRequestService");
    }

    public static cd q(IBinder paramIBinder)
    {
      if (paramIBinder == null)
        return null;
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.google.android.gms.ads.internal.request.IAdRequestService");
      if ((localIInterface != null) && ((localIInterface instanceof cd)))
        return (cd)localIInterface;
      return new a(paramIBinder);
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default:
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
        paramParcel2.writeString("com.google.android.gms.ads.internal.request.IAdRequestService");
        return true;
      case 1:
      }
      paramParcel1.enforceInterface("com.google.android.gms.ads.internal.request.IAdRequestService");
      bz localbz;
      if (paramParcel1.readInt() != 0)
      {
        localbz = bz.CREATOR.f(paramParcel1);
        cb localcb = b(localbz);
        paramParcel2.writeNoException();
        if (localcb == null)
          break label105;
        paramParcel2.writeInt(1);
        localcb.writeToParcel(paramParcel2, 1);
      }
      while (true)
      {
        return true;
        localbz = null;
        break;
        label105: paramParcel2.writeInt(0);
      }
    }

    private static class a
      implements cd
    {
      private IBinder dU;

      a(IBinder paramIBinder)
      {
        this.dU = paramIBinder;
      }

      public IBinder asBinder()
      {
        return this.dU;
      }

      public cb b(bz parambz)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("com.google.android.gms.ads.internal.request.IAdRequestService");
            if (parambz != null)
            {
              localParcel1.writeInt(1);
              parambz.writeToParcel(localParcel1, 0);
              this.dU.transact(1, localParcel1, localParcel2, 0);
              localParcel2.readException();
              if (localParcel2.readInt() != 0)
              {
                cb localcb2 = cb.CREATOR.g(localParcel2);
                localcb1 = localcb2;
                return localcb1;
              }
            }
            else
            {
              localParcel1.writeInt(0);
              continue;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          cb localcb1 = null;
        }
      }
    }
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cd
 * JD-Core Version:    0.6.2
 */