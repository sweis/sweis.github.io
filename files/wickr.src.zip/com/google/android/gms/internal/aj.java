package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class aj
  implements Parcelable.Creator<ai>
{
  static void a(ai paramai, Parcel paramParcel, int paramInt)
  {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1, paramai.versionCode);
    b.c(paramParcel, 2, paramai.eZ);
    b.c(paramParcel, 3, paramai.backgroundColor);
    b.c(paramParcel, 4, paramai.fa);
    b.c(paramParcel, 5, paramai.fb);
    b.c(paramParcel, 6, paramai.fc);
    b.c(paramParcel, 7, paramai.fd);
    b.c(paramParcel, 8, paramai.fe);
    b.c(paramParcel, 9, paramai.ff);
    b.a(paramParcel, 10, paramai.fg, false);
    b.c(paramParcel, 11, paramai.fh);
    b.a(paramParcel, 12, paramai.fi, false);
    b.c(paramParcel, 13, paramai.fj);
    b.c(paramParcel, 14, paramai.fk);
    b.a(paramParcel, 15, paramai.fl, false);
    b.D(paramParcel, i);
  }

  public ai c(Parcel paramParcel)
  {
    int i = a.n(paramParcel);
    int j = 0;
    int k = 0;
    int m = 0;
    int n = 0;
    int i1 = 0;
    int i2 = 0;
    int i3 = 0;
    int i4 = 0;
    int i5 = 0;
    String str1 = null;
    int i6 = 0;
    String str2 = null;
    int i7 = 0;
    int i8 = 0;
    String str3 = null;
    while (paramParcel.dataPosition() < i)
    {
      int i9 = a.m(paramParcel);
      switch (a.M(i9))
      {
      default:
        a.b(paramParcel, i9);
        break;
      case 1:
        j = a.g(paramParcel, i9);
        break;
      case 2:
        k = a.g(paramParcel, i9);
        break;
      case 3:
        m = a.g(paramParcel, i9);
        break;
      case 4:
        n = a.g(paramParcel, i9);
        break;
      case 5:
        i1 = a.g(paramParcel, i9);
        break;
      case 6:
        i2 = a.g(paramParcel, i9);
        break;
      case 7:
        i3 = a.g(paramParcel, i9);
        break;
      case 8:
        i4 = a.g(paramParcel, i9);
        break;
      case 9:
        i5 = a.g(paramParcel, i9);
        break;
      case 10:
        str1 = a.m(paramParcel, i9);
        break;
      case 11:
        i6 = a.g(paramParcel, i9);
        break;
      case 12:
        str2 = a.m(paramParcel, i9);
        break;
      case 13:
        i7 = a.g(paramParcel, i9);
        break;
      case 14:
        i8 = a.g(paramParcel, i9);
        break;
      case 15:
        str3 = a.m(paramParcel, i9);
      }
    }
    if (paramParcel.dataPosition() != i)
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    return new ai(j, k, m, n, i1, i2, i3, i4, i5, str1, i6, str2, i7, i8, str3);
  }

  public ai[] e(int paramInt)
  {
    return new ai[paramInt];
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.aj
 * JD-Core Version:    0.6.2
 */