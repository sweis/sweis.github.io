package com.google.android.gms.internal;

import android.content.Context;
import android.view.MotionEvent;

public abstract interface d
{
  public abstract String a(Context paramContext);

  public abstract String a(Context paramContext, String paramString);

  public abstract void a(int paramInt1, int paramInt2, int paramInt3);

  public abstract void a(MotionEvent paramMotionEvent);
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.d
 * JD-Core Version:    0.6.2
 */