package com.google.android.gms.internal;

import android.content.Context;

public final class bu
{
  public static cm a(Context paramContext, bz.a parama, h paramh, cw paramcw, bb parambb, a parama1)
  {
    bv localbv = new bv(paramContext, parama, paramh, paramcw, parambb, parama1);
    localbv.start();
    return localbv;
  }

  public static abstract interface a
  {
    public abstract void a(cj paramcj);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.bu
 * JD-Core Version:    0.6.2
 */