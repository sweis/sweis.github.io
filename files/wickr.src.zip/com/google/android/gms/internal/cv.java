package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class cv
  implements Parcelable.Creator<cu>
{
  static void a(cu paramcu, Parcel paramParcel, int paramInt)
  {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1, paramcu.versionCode);
    b.a(paramParcel, 2, paramcu.iJ, false);
    b.c(paramParcel, 3, paramcu.iK);
    b.c(paramParcel, 4, paramcu.iL);
    b.a(paramParcel, 5, paramcu.iM);
    b.D(paramParcel, i);
  }

  public cu h(Parcel paramParcel)
  {
    boolean bool = false;
    int i = a.n(paramParcel);
    String str = null;
    int j = 0;
    int k = 0;
    int m = 0;
    while (paramParcel.dataPosition() < i)
    {
      int n = a.m(paramParcel);
      switch (a.M(n))
      {
      default:
        a.b(paramParcel, n);
        break;
      case 1:
        m = a.g(paramParcel, n);
        break;
      case 2:
        str = a.m(paramParcel, n);
        break;
      case 3:
        k = a.g(paramParcel, n);
        break;
      case 4:
        j = a.g(paramParcel, n);
        break;
      case 5:
        bool = a.c(paramParcel, n);
      }
    }
    if (paramParcel.dataPosition() != i)
      throw new a.a("Overread allowed size end=" + i, paramParcel);
    return new cu(m, str, k, j, bool);
  }

  public cu[] o(int paramInt)
  {
    return new cu[paramInt];
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.cv
 * JD-Core Version:    0.6.2
 */