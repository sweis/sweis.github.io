package com.google.android.gms.internal;

import android.content.Context;
import android.os.Handler;
import android.os.RemoteException;
import java.util.Iterator;
import java.util.List;

public final class as
{
  private final bb ed;
  private ax fA;
  private final bz fw;
  private final Object fx = new Object();
  private final au fy;
  private boolean fz = false;
  private final Context mContext;

  public as(Context paramContext, bz parambz, bb parambb, au paramau)
  {
    this.mContext = paramContext;
    this.fw = parambz;
    this.ed = parambb;
    this.fy = paramau;
  }

  public ay a(long paramLong1, long paramLong2)
  {
    ct.r("Starting mediation.");
    Iterator localIterator1 = this.fy.fI.iterator();
    while (localIterator1.hasNext())
    {
      at localat = (at)localIterator1.next();
      ct.t("Trying mediation network: " + localat.fD);
      Iterator localIterator2 = localat.fE.iterator();
      while (localIterator2.hasNext())
      {
        String str = (String)localIterator2.next();
        final ay localay2;
        synchronized (this.fx)
        {
          if (this.fz)
          {
            ay localay1 = new ay(-1);
            return localay1;
          }
          this.fA = new ax(this.mContext, str, this.ed, this.fy, localat, this.fw.hr, this.fw.em, this.fw.ej);
          localay2 = this.fA.b(paramLong1, paramLong2);
          if (localay2.ga == 0)
          {
            ct.r("Adapter succeeded.");
            return localay2;
          }
        }
        if (localay2.gc != null)
          cs.iI.post(new Runnable()
          {
            public void run()
            {
              try
              {
                localay2.gc.destroy();
                return;
              }
              catch (RemoteException localRemoteException)
              {
                ct.b("Could not destroy mediation adapter.", localRemoteException);
              }
            }
          });
      }
    }
    return new ay(1);
  }

  public void cancel()
  {
    synchronized (this.fx)
    {
      this.fz = true;
      if (this.fA != null)
        this.fA.cancel();
      return;
    }
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.as
 * JD-Core Version:    0.6.2
 */