package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.a.a;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.ArrayList;

public class ef
  implements Parcelable.Creator<dt.a>
{
  static void a(dt.a parama, Parcel paramParcel, int paramInt)
  {
    int i = b.o(paramParcel);
    b.a(paramParcel, 1, parama.getAccountName(), false);
    b.c(paramParcel, 1000, parama.getVersionCode());
    b.a(paramParcel, 2, parama.bH(), false);
    b.c(paramParcel, 3, parama.bG());
    b.a(paramParcel, 4, parama.bJ(), false);
    b.D(paramParcel, i);
  }

  public dt.a[] L(int paramInt)
  {
    return new dt.a[paramInt];
  }

  public dt.a l(Parcel paramParcel)
  {
    int i = 0;
    String str1 = null;
    int j = a.n(paramParcel);
    ArrayList localArrayList = null;
    String str2 = null;
    int k = 0;
    while (paramParcel.dataPosition() < j)
    {
      int m = a.m(paramParcel);
      switch (a.M(m))
      {
      default:
        a.b(paramParcel, m);
        break;
      case 1:
        str2 = a.m(paramParcel, m);
        break;
      case 1000:
        k = a.g(paramParcel, m);
        break;
      case 2:
        localArrayList = a.y(paramParcel, m);
        break;
      case 3:
        i = a.g(paramParcel, m);
        break;
      case 4:
        str1 = a.m(paramParcel, m);
      }
    }
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel);
    return new dt.a(k, str2, localArrayList, i, str1);
  }
}

/* Location:           /tmp/apk/wickr/classes_dex2jar.jar
 * Qualified Name:     com.google.android.gms.internal.ef
 * JD-Core Version:    0.6.2
 */