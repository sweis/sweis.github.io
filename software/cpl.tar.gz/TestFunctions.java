import cpl.runtime.*;

public class TestFunctions {
    static CPLZ square(CPLZ z) {
	return CPLZ.mul(z, z);
    }

    static CPLPolyZ getArray(int n) {
	CPLPolyZ res = new CPLPolyZ();
	for (int i=0; i<n; i++)
	    res.set(i*2, CPLZ.get(i));
	return res;
    }

    static CPLZ weird(CPLZ z, CPLPolyZ p, int n) {
	return CPLZ.mul(CPLZ.get(n), p.calc(z));
    }
}
