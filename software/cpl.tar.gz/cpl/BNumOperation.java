package cpl;

public class BNumOperation extends BOperation {
    private String javaFunc;
    private String symbol;
    private String latexSymbol;

    public BNumOperation(String symbol, String javaFunc, String latexSymbol) {
	this.javaFunc = javaFunc;
	this.symbol = symbol;
	this.latexSymbol = latexSymbol;
    }

    public String getSymbol() {
	return symbol;
    }

    public String getJavaCode(Field field, String left, String right) {
	if (field.isInteger())
	    return left + symbol + right;
	return field.getJavaType() + "." + javaFunc + "(" + left + "," + right + ")";
    }

    public String getLatexCode(String left, String right) { 
	// hackish. Should probably change it.
	if (symbol.equals("/"))
	    return "\\frac{" + left + "}{" + right + "}";
	        
	return left + latexSymbol + right;
    }

    public Field[] getFields(Field field, Field left, Field right) {
	Field[] res = new Field[2];

	if (field.isZ()) {
	    if (left.isZ() || left.isInteger())
		res[0] = Field.getZ();
	    else if (left.isZMod())
		res[0] = left;
	    else
		return null;

	    if (right.isZ() || right.isInteger())
		res[1] = Field.getZ();
	    else if (right.isZMod())
		res[1] = right;
	    else
		return null;

	    return res;
	}

	if (field.isZMod()) {
	    if (left.isNumber())
		res[0] = field;
	    else
		return null;

	    if (right.isNumber())
		res[1] = field;
	    else
		return null;

	    return res;
	}
	
	if (field.isPolyZ()) {
	    if (left.isZ() || left.isInteger())
		res[0] = Field.getZ();
	    else if (left.isZMod())
		res[0] = left;
	    else if (left.isPolyZ())
		res[0] = Field.getPolyZ();
	    else if (left.isPolyZMod())
		res[0] = left;
	    else
		return null;

	    if (right.isZ() || right.isInteger())
		res[1] = Field.getZ();
	    else if (right.isZMod())
		res[1] = right;
	    else if (right.isPolyZ())
		res[1] = Field.getPolyZ();
	    else if (right.isPolyZMod())
		res[1] = right;		
	    else
		return null;

	    return res;
	}

	if (field.isPolyZMod()) {
	    if (left.isNumber())
		res[0] = field.getPolyCoefField();
	    else if (left.isPoly())
		res[0] = field;
	    else
		return null;

	    if (right.isNumber())
		res[1] = field.getPolyCoefField();
	    else if (right.isPoly())
		res[1] = field;
	    else
		return null;

	    return res;
	}

	if (field.isInteger()) {
	    if (left.isInteger())
		res[0] = Field.getInteger();
	    else
		return null;

	    if (right.isInteger())
		res[1] = Field.getInteger();
	    else
		return null;

	    return res;
	}

	throw new RuntimeException("Can't do operation " + this + " in field " + field);
    }

    public Field getReturnField(Field left, Field right) {
	if (left.equals(right))
	    return left;

	if (left.isZ() || left.isInteger()) {
	    if (right.isNumber())
		return Field.getZ();
	    if (right.isPoly())
		return Field.getPolyZ();
	}

	if (left.isZMod()) {
	    if (right.isNumber())
		return Field.getZ();
	    if (right.isPolyZ())
		return Field.getPolyZ();
	    if (right.isPolyZMod())
		return left.getMod().equals(right.getMod()) ?
			right : Field.getPolyZ();
	}

	if (left.isPolyZ()) {
	    if (right.isNumber() || right.isPoly())
		return Field.getPolyZ();
	}

	if (left.isPolyZMod()) {
	    if (right.isZ() || right.isInteger() || right.isPolyZ())
		return Field.getPolyZ();
	    if (right.isMod())
		return right.getMod().name.equals(left.getMod().name) ?
		    left : Field.getPolyZ();
	}

	throw new RuntimeException("Can't do operation " + this + " between fields " + left + " and " + right);
    }
}
