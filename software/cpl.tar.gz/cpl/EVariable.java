/*
  Simple expression consisting only of a variable.
*/

package cpl;

public class EVariable extends Expression
{
    public Variable variable;

    private Field evalField = null;

    public EVariable(Variable variable) {
	super(VARIABLE);
	this.variable= variable;
    }

    public Field getReturnField() {
        return variable.field;
    }

    public String getJavaCode() {
	return evalField.getJavaCodeForConvert(variable.field, variable.getJavaName());
    }

    public String getLatexCode() {
	return variable.getLatexName();
    }

    public String toString() {
	return variable.name;
    }

    public void setDefaultField(Field field) {
	evalField = variable.field.convert(field);
    }

}
