package cpl;

class SendExpression {
    Expression value, index;
    String asName;

    public SendExpression(Expression value, String asName) {
	this.value = value;
	this.asName = asName;
	this.index = null;
    }

    public SendExpression(Expression value, String asName, Expression index) {
	this.value = value;
	this.asName = asName;
	this.index = index;
    }
}
