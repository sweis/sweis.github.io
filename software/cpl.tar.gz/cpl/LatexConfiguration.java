package cpl;

import java.util.*;
import java.lang.*;

public class LatexConfiguration {
    Map names = new HashMap();

    public void mapName(String from, String to) {
	System.out.println("Map " + from + " -> " + to);
	names.put(from, to);
    }

    public String getMapName(String name) {
	return (String) names.get(name);
    }
}
