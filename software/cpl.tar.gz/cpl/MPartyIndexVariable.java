package cpl;

public class MPartyIndexVariable extends Variable {

    public MPartyIndexVariable(String name, Protocol protocol) {
	super(name, Field.getInteger(), protocol);
    }

    public String getJavaName() {
	return "_$ID_";
    }
	     
}
