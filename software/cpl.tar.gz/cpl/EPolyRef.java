package cpl;

import java.util.*;

public class EPolyRef extends Expression {
    public Variable poly;
    public PolyIndex index;

    private Field evalField = null;

    public EPolyRef(Variable poly, PolyIndex index) {
	super(POLYREF);
	this.poly = poly;
	this.index = index;
    }

    public Field getReturnField() {
	return poly.field;
    }

    public String getJavaCode() {
	// FIXME: convert
	return poly.getJavaName() + ".getPart(" + index.getJavaCode() + ")";
    }

    public String getLatexCode() {
	return poly.name + "_{" + index.getLatexCode() + "}";
    }

    public String getLatexDefaultCode() {
	return poly.name;
    }
    
    public String toString() {
	return poly.name;
    }

    public void setDefaultField(Field field) {
	evalField = poly.field.convert(field);
    }

}
