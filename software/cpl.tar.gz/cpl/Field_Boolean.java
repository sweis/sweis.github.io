package cpl;


public class Field_Boolean extends Field {

    public Field_Boolean() {
	super(BOOLEAN);
    }

    public String getJavaCodeForConstant(String constant) {
	throw new InternalError("This should never been called: Field_Boolean.getJavaCodeForConstant");
    }

    public String getJavaCodeForSelect(String arg) {
	throw new RuntimeException("Select in Boolean not supported");
    }

    public String getJavaType() {
        return "boolean";
    }

    public String getJavaConstructor() {
	return "new " + getJavaType() + "()";
    }

    public String getJavaCodeForConvert(Field from, String arg) {
	if (from.equals(this))
	    return arg;

	throw new RuntimeException("This should never happen: Field_Boolean.getJavaCodeForConvert");
    }

    public String getLatexCodeForConstant(String constant) {
	throw new InternalError("This should never been called: Field_Boolean.getLatexCodeForConstant");
    }

    public String getLatexCodeForSelect() {
	throw new RuntimeException("Select in Boolean not supported");
    }

    public Field convert(Field field) {
	if (field == null)
	    return Field.getBoolean();

	switch (field.type) {
	case BOOLEAN:
	    return Field.getBoolean();
	default:
	    throw new RuntimeException("Cannot convert from field " + this + " to field " + field);
	}
    }

    public boolean isJavaPrimitiveType() {
	return true;
    }

    public String toString() {
	return "Boolean";
    }
}
