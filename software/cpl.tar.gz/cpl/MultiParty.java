package cpl;

import java.util.*;

public class MultiParty extends Party {
    MPartyIndexVariable index;
    Expression count;

    public MultiParty(String name, Expression count, Protocol protocol) {
	super(name, protocol);
	this.count = count;
    }

    public void setIndex(String index) {
	this.index = new MPartyIndexVariable(index, protocol);
    }

    public Variable findVariable(String name) {
	if (index != null)
	    if (index.name.equals(name))
		return index;
	//	    throw new InternalError("This should never happen: MultiParty.findVariable");

	return super.findVariable(name);
    }

    public void addCodeElement(CodeElement c) {
	super.addCodeElement(c);
	index = null;
    }

    public String getJavaCommunicationChannelType() {
	return "CommunicationChannel[]";
    }

    public boolean isMulti() {
	return true;
    }
}
