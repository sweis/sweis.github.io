package cpl;

import java.util.*;

public class CSends extends CodeElement {
    public Vector args;
    public PartyRef target;

    /* A Vector of variables */
    public CSends(Vector args, PartyRef target) {
	super(SENDS);

	this.args= args;
	this.target= target;
    }
}
