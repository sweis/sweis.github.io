package cpl;

import java.util.Vector;
import java.lang.String;

public class CFor extends CodeElement {
    public Variable var;
    public Expression from, to;
    public CodeElement ce;

    public CFor(Variable var, Expression from, Expression to, CodeElement ce) {
	super(FOR);
	this.var = var;
	this.from = from;
	this.to = to;
	this.ce = ce;
    }

    public String toString() {
	return "for " + var + " := " + from + " to " + to;
    }
}
