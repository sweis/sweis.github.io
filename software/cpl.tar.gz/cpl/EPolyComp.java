package cpl;

import java.util.*;

public class EPolyComp extends Expression {
    public Expression p;
    public Expression x;

    private Field evalField = null;

    public EPolyComp(Expression p, Expression x) {
	super(POLYCOMP);

	this.p = p;
	this.x = x;
    }

    public Field getReturnField() {
	return Field.getZ();
    }

    public String getJavaCode() {
	return evalField.getJavaCodeForConvert(getReturnField(), p.getJavaCode() + ".calc(" + x.getJavaCode() + ")");
    }

    public String getLatexCode() {
	return p.getLatexCode() + "\\left(" + x.getLatexCode() + "\\right)";
    }

    public String toString() {
	return p + "(" + x + ")";
    }

    public void setDefaultField(Field field) {
	evalField = Field.getZ().convert(field);
	p.setDefaultField(p.getReturnField());
	x.setDefaultField(Field.getZ());
    }

}

