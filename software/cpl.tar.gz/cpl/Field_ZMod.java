package cpl;

public class Field_ZMod extends Field_Z {
    Variable mod;

    public Field_ZMod(Variable mod) {
	super(ZMOD);
	this.mod= mod;
    }

    public static Field_ZMod getField_ZMod(Variable mod) {
	return new Field_ZMod(mod);
    }

    public String getJavaCodeForSelect(String arg) {
	return arg + ".select()";
    }

    public String getJavaCodeForConstant(String constant) {
	return getJavaType() + ".get(" + mod.getJavaName() + ",\"" + constant + "\")";
    }

    public String getJavaCodeForConvert(Field from, String arg) {
	if (from.equals(this))
	    return arg;

	switch(from.type) {
	case Z:
	case BITSTRING:
	case ZMOD:
	    return arg + ".mod(" + mod.name + ")";
	case INTEGER:
	    return getJavaType() + ".get(" + mod.name + "," + arg + ")";
	}
	System.out.println("from " + from + " to " + this.toString());
	throw new RuntimeException("This should never happen: Field_ZMod.getJavaCodeForConvert");
    }

    public String getLatexCodeForConstant(String constant) {
	return constant;
    }

    public String getLatexCodeForSelect() {
	return "\\in \\mathbb{Z}_{" + mod.getLatexName() + "}";
    }

    public boolean equals(Object obj) {
        return obj instanceof Field &&
            ((Field) obj).type == ZMOD &&
            ((Field_ZMod) obj).mod.equals(mod);
    }

    public String getJavaType() {
	return "CPLZMod";
    }

    public String getJavaConstructor() {
	return "new " + getJavaType() + "(" + mod.getJavaName() + ")";
    }

    public String toString() {
	return "Z(" + mod + ")";
    }
}
