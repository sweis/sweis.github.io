package cpl;

import java.util.*;

public class CReturns extends CodeElement {

    public Vector args;

    /*  A vector of variables*/
    public CReturns(Vector args) {
	super(RETURNS);

	this.args= args;
    }
}
