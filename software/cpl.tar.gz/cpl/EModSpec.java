package cpl;

public class EModSpec extends Expression {
    
    public Expression arg;
    public Variable mod;

    protected Field field = null;

    public EModSpec(Expression arg, Variable mod) {
	super(MOD_SPEC);
	this.arg = arg;
	this.field = arg.getReturnField().isPoly() ? (Field)Field.getPolyZMod(mod) : (Field)Field.getZMod(mod);
	
	arg.setDefaultField(this.field);
    }

    public Field getReturnField() {
	return this.field;
    }

    public String getJavaCode() {
	return arg.getJavaCode();
    }

    public String getLatexCode() {
	return arg.getLatexCode();
    }

    public String toString() {
        return arg + " (mod " + mod + ")";
    }

    public void setDefaultField(Field field) {
	
    }

}
