package cpl;

public class PartyRef {
    public Party party;
    public Variable index;

    public PartyRef(Party party) {
	this.party = party;
	this.index = null;
    }

    public PartyRef(Party party, Variable index) {
	this.party = party;
	this.index = index;
    }
}
