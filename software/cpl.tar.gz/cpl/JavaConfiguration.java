package cpl;

import java.util.*;
import java.lang.*;

public class JavaConfiguration {
    Map functions = new HashMap();
    Map names = new HashMap();

    public void mapName(String from, String to) {
	System.out.println("Map " + from + " -> " + to);
	names.put(from, to);
    }

    public void removeMap(String name) {
	names.remove(name);
    }


    //FIXME: check if the order of the params is correct!
    public void addFunction(String name, Field returnField, Vector params, String javaName) {
	System.out.println("external: " + returnField.getJavaType() + " " + name + "(" +
			   params + ") -> " + javaName);
	functions.put(name, new ExternalFunction(name, returnField, params, javaName));
    }

    public String getMapName(String name) {
	return (String) names.get(name);
    }

    public Function getFunction(String name) {
	return (Function) functions.get(name);
    }
}
