package cpl;

public class UNotOperation extends UOperation {
    public Field getReturnField(Field arg) {
	switch (arg.type) {
	case Field.BOOLEAN:
	    return arg;
	}

	return null;
    }
    
    public String getJavaCode(Field field, String arg) {
	return "not " + arg;
    }

    public String getLatexCode(String arg) {
	return "\\text{not} " + arg;
    }

    public String getSymbol() {
	return "not";
    }
}
