package cpl;

import java.util.*;

public class PolyIndex extends Vector {
    private static final int RANGE = 1;
    private static final int INDEX = 2;

    public boolean isSingleIndex() {
	if (size() != 1)
	    return false;
	
	return ((Integer)((Vector)elementAt(0)).elementAt(0)).intValue() == INDEX;
    }

    public Expression getSingleIndex() {
	return (Expression)(((Vector)elementAt(0)).elementAt(1));
    }

    static Vector getRangeIndex(Expression e1, Expression e2) {
	Vector v = new Vector();
	v.add(new Integer(RANGE));
	v.add(e1);
	v.add(e2);
	return v;
    }

    static Vector getIndex(Expression e) {
	Vector v = new Vector();
	v.add(new Integer(INDEX));
	v.add(e);
	return v;
    }
    
    public String getJavaCode() {
	String res = "(new CPLIndex())";

	for (Iterator i = iterator(); i.hasNext(); ) {
	    Vector v = (Vector)i.next();
	    switch (((Integer)v.elementAt(0)).intValue()) {
	    case RANGE:
		Expression e1 = (Expression)v.elementAt(1);
		Expression e2 = (Expression)v.elementAt(2);
		
		res += ".addRange(" + e1.getJavaCode() + ", " + e2.getJavaCode() + ")";
		break;
	    case INDEX:
		Expression e = (Expression)v.elementAt(1);
		res += ".addIndex(" + e.getJavaCode() + ")";
		break;
	    default:
		throw new InternalError("PolyIndex ID not found");
	    }
	}
	return res;
    }

    public String getLatexCode() {
	String res = "";

	for (Iterator i = iterator(); i.hasNext(); ) {
	    Vector v = (Vector)i.next();
	    switch (((Integer)v.elementAt(0)).intValue()) {
	    case RANGE:
		Expression e1 = (Expression)v.elementAt(1);
		Expression e2 = (Expression)v.elementAt(2);
		
		res = e1.getLatexCode() + ".." + e2.getLatexCode() + ")";
		break;
	    case INDEX:
		Expression e = (Expression)v.elementAt(1);
		res = e.getLatexCode();
		break;
	    default:
		throw new InternalError("PolyIndex ID not found");
	    }
	    if (i.hasNext())
		res += ".";
	}
	return res;
    }
}
