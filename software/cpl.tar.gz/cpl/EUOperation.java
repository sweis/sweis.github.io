/*
  This class represents a unary operation.
*/

package cpl;

public class EUOperation extends Expression {
    public UOperation op;

    public static final int U_MINUS= 0;
    public static final int NOT= 1;
    
    public Expression arg; // argument

    private Field returnField = null;

    private Field evalField = null;

    public EUOperation(UOperation op, Expression arg) {
	super(U_OPERATION);

	this.op=op;
	this.arg= arg;
    }

    public Field getReturnField() {
	if (returnField == null)
	    returnField = op.getReturnField(arg.getReturnField());

        return returnField;
    }

    public String getJavaCode() {
	// FIXME: convert
	return evalField.getJavaCodeForUnary(op, arg.getJavaCode());
    }

    public String getLatexCode() {
	return arg.getReturnField().getLatexCodeForUnary(op, arg.getLatexCode());
    }

    public String toString() {
      return "(" + op.getSymbol() + " " + arg + ")";
    }

    public void setDefaultField(Field field) {
	arg.setDefaultField(field);
	
	evalField = field;
    }

}
