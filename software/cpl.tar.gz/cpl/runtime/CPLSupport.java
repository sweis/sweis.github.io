/*
  This class contains static support functions executed at runtime from CPL code.
*/


package cpl.runtime;

import java.math.*;
import java.util.*;
import java.io.*;
import java.security.*;

public final class CPLSupport {
    
    public static void test(boolean condition, String message) {
	if (!condition) {
	    throw new CryptoProtocolException(CryptoProtocolException.TESTFAILED, message);
	}
    }

    public static void test(BigInteger condition, String message) {
	if (condition.signum() == 0) {
	    throw new CryptoProtocolException(CryptoProtocolException.TESTFAILED, message);
	}
    }
    public static void assert(boolean condition, String message) {
	if (!condition) {
	    throw new CryptoProtocolException(CryptoProtocolException.ASSERTFAILED, message);
	}
    }

    public static void assert(BigInteger condition, String message) {
	if (condition.signum() == 0) {
	    throw new CryptoProtocolException(CryptoProtocolException.ASSERTFAILED, message);
	}
    }

    public static CommunicationChannel[][] getPipedCommunicationChannels(int nChannels) {
	CommunicationChannel[][] result= new CommunicationChannel[nChannels][nChannels];
	
	try { 

	for (int i=0; i<nChannels; i++)
	    for (int j=i+1; j<nChannels; j++) {
		PipedOutputStream posA = new PipedOutputStream();
		PipedOutputStream posB = new PipedOutputStream();
		
		PipedInputStream pisA = new PipedInputStream(posB);
		PipedInputStream pisB = new PipedInputStream(posA);
		
		ObjectOutputStream ousA = new ObjectOutputStream(posA);
		ObjectOutputStream ousB = new ObjectOutputStream(posB);
		
		ObjectInputStream oisA = new ObjectInputStream(pisA);
		ObjectInputStream oisB = new ObjectInputStream(pisB);
		
		result[i][j] = new CommunicationChannel(oisA, ousA);
		result[j][i] = new CommunicationChannel(oisB, ousB);
		    
	    }
	} catch (Exception e) {
	    throw new RuntimeException("Unexpected exception: " + e);
	}
	
	return result;
	
    }

    static public BigInteger getRandom(int bitLength) {
	return new BigInteger(bitLength, secureRandom);
    }

    static public BigInteger getRandomBase(BigInteger base) {
        // Probability to find from each try is at least 50%
        // Distribution is random
	BigInteger value;

        do {
            value = new BigInteger(base.bitLength(), secureRandom);
        } while (value.compareTo(base) >= 0);
	
	return value;
    }

    static public BigInteger hash(BigInteger value) {
	messageDigest.update(value.toByteArray());
	return new BigInteger(messageDigest.digest());
    }

    static public BigInteger getPrime(int bitLength, int certainty) {
	return new BigInteger(bitLength, certainty, secureRandom);
    }

    // Default primality certainty to 1/2^15 (1/32000)
    static public BigInteger getPrime(int bitLength) {
	return new BigInteger(bitLength, 15, secureRandom);
    }

    static Random secureRandom;
    static MessageDigest messageDigest;

    static {
	try {
	    secureRandom = SecureRandom.getInstance("SHA1PRNG");
	    messageDigest = MessageDigest.getInstance("SHA");
	}
	catch (NoSuchAlgorithmException e) {
	    e.printStackTrace(System.err);
	    System.exit(1);
	}
    }    
}




