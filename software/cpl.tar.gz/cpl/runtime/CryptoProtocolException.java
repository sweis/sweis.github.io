package cpl.runtime;


public class CryptoProtocolException extends RuntimeException{

    private int type;
    
    public static final int IOFAILED= 0;
    public static final int ASSERTFAILED= 1;
    public static final int TESTFAILED= 2;
    public static final int COMPUTATIONERROR= 3;

    public CryptoProtocolException(int type, String message) {
	super(getMessageForType(type) + ": " + message);
	this.type= type;
    }

    public int getType() {
	return type;
    }

    public static String getMessageForType(int type) {
	switch(type) {
	case IOFAILED: return "I/O failed";
	case ASSERTFAILED: return "Assertion failed";
	case TESTFAILED: return "Test failed";
	case COMPUTATIONERROR: return "Computation error";
	default: return "Unknown protocol exception";
	}
    }

}
