package cpl.runtime;

import java.util.*;

public class CPLIndex {

    public Vector values;

    public CPLIndex() {
	values = new Vector();
    }

    private void addValue(int n) {
	if (!values.isEmpty())
	    if (((Integer)values.lastElement()).intValue() >= n)
		throw new CryptoProtocolException(CryptoProtocolException.COMPUTATIONERROR,
						  "Index values not in order");
	values.add(new Integer(n));
    }

    public CPLIndex addRange(int from, int to) {
	int i;
	for (i=from; i<=to; i++)
	    addValue(i);
	return this;
    }

    public CPLIndex addIndex(int index) {
	addValue(index);
	return this;
    }
}
