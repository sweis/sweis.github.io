package cpl.runtime;

import java.math.*;
import java.util.Random;

public class CPLZMod extends CPLZ {
    public CPLZ p; // The modulo

    public CPLZMod(CPLZ p) {
	super();
	this.p = p;
    }
    
    public CPLZMod(CPLZ p, BigInteger value) {
	super(value.mod(p.getValue()));
	this.p = p;
    }

    public CPLZMod(CPLZ p, String constant) {
	this(p, new BigInteger(constant));
    }

    public CPLZMod(CPLZ p, CPLZ z) {
	this(p, z.getValue());
    }

    public void set(CPLZ z) {
	value = z.getValue().mod(p.getValue());
    }

    public static CPLZMod get(CPLZ p, String constant) {
	return new CPLZMod(p, constant);
    }

    public static CPLZMod get(CPLZ p, int value) {
	return new CPLZMod(p, new BigInteger(Integer.toString(value)));
    }

    static public CPLZMod mod(CPLZMod left, CPLZMod right) {
	return new CPLZMod(left.p, left.getValue().mod(right.getValue()).mod(left.p.getValue()));
    }
    
    static public CPLZMod add(CPLZMod left, CPLZMod right) {
	return new CPLZMod(left.p, left.getValue().add(right.getValue()).mod(left.p.getValue()));
    }

    static public CPLZMod sub(CPLZMod left, CPLZMod right) {
	return new CPLZMod(left.p, left.getValue().subtract(right.getValue()).mod(left.p.getValue()));
    }

    static public CPLZMod mul(CPLZMod left, CPLZMod right) {
	return new CPLZMod(left.p, left.getValue().multiply(right.getValue()).mod(left.p.getValue()));
    }

    static public CPLZMod modInverse(CPLZMod left) {
	return new CPLZMod(left.p, left.getValue().modInverse(left.p.getValue()));
    }

    static public CPLZMod div(CPLZMod left, CPLZMod right) {
    	System.out.println(left + "/" + right + " mod " + left.p);
    	return new CPLZMod
	    (left.p, left.getValue().
	     multiply(right.getValue().modInverse(left.p.getValue())));
    }
    
    static public CPLZMod xor(CPLZMod left, CPLZMod right) {
	return new CPLZMod(left.p, left.getValue().xor(right.getValue()).mod(left.p.getValue()));
    }

    static public CPLZMod pow(CPLZMod left, CPLZ right) {
	if (left == null)
	    System.out.println("left is null");
	else if (right == null)
	    System.out.println("right is null");

	return new CPLZMod(left.p, left.getValue().modPow
			   (right.getValue(), left.p.getValue()));
    }

    public void select() {
	value = CPLSupport.getRandomBase(p.getValue());
    }

    public void send(CommunicationChannel cc) {
	cc.send(value);
	cc.send(p.getValue());
    }

    public void receive(CommunicationChannel cc) {
	value = (BigInteger)cc.receive();
	p = new CPLZ((BigInteger)cc.receive());
    }
}

