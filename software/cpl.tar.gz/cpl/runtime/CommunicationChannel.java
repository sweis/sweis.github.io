package cpl.runtime;

import java.io.*;
import java.util.*;
import java.math.*;
import java.security.*;
import java.net.*;

public class CommunicationChannel {
	protected ObjectInputStream is;
	protected ObjectOutputStream os;
	
	public CommunicationChannel(ObjectInputStream is, ObjectOutputStream os) 
		throws IOException, StreamCorruptedException {
		
		this.os = os;

		this.is = is;
	}

	public InputStream getInputStream() {
		return is;
	}
	
	public OutputStream getOutputStream() {
		return os;
	}
	
	public void send(Object obj) {
	    try {
		os.writeObject(obj);		
		os.flush();
	    }
	    catch (Exception e) {
		throw new CryptoProtocolException(CryptoProtocolException.IOFAILED, "Could not receive object: got " + e);
	    }
	}
	
	public Object receive()  {
	    try {
		return is.readObject();
	    }
	    catch (Exception e) {
		throw new CryptoProtocolException(CryptoProtocolException.IOFAILED, "Could not receive object: got " + e);
	    }
	}
}
