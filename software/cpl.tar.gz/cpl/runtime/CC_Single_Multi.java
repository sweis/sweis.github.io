package cpl.runtime;

import java.util.*;
import java.io.*;

public class CC_Single_Multi {
    private CommunicationChannel[] first;
    private CommunicationChannel[] second;
    
    public CC_Single_Multi(int n) throws Exception {
	int i;

	first = new CommunicationChannel[n];
	second = new CommunicationChannel[n];

	for (i=0; i<n; i++) {
	    PipedOutputStream posA = new PipedOutputStream();
	    PipedOutputStream posB = new PipedOutputStream();
	    
	    PipedInputStream pisA = new PipedInputStream(posB);
	    PipedInputStream pisB = new PipedInputStream(posA);
	    
	    ObjectOutputStream ousA = new ObjectOutputStream(posA);
	    ObjectOutputStream ousB = new ObjectOutputStream(posB);
	    
	    ObjectInputStream oisA = new ObjectInputStream(pisA);
	    ObjectInputStream oisB = new ObjectInputStream(pisB);
	    
	    first[i] = new CommunicationChannel(oisA, ousA);
	    second[i] = new CommunicationChannel(oisB, ousB);
	}
    }

    public CommunicationChannel[] getFirst() {
	return first;
    }

    public CommunicationChannel getSecond(int n) {
	return second[n];
    }
}
