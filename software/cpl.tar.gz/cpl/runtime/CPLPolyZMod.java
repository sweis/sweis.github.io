package cpl.runtime;

import java.math.*;
import java.util.*;

abstract class CPLZModOperation {
    abstract public CPLZMod operation(CPLZMod a, CPLZMod b);
}

public class CPLPolyZMod {
    TreeMap values;
    CPLZ p;

    public CPLPolyZMod(CPLZ p) {
	values = new TreeMap();;
	this.p = p;
    }
    
    public void select(CPLIndex index) {
	values = new TreeMap();

	for (Iterator i=index.values.iterator(); i.hasNext(); ) {
	    CPLZMod k = new CPLZMod(p, CPLSupport.getRandomBase(p.getValue()));
	    set((Integer)i.next(), k);
	}
    }

    public CPLPolyZMod put(CPLZMod value) {
	if (values.isEmpty())
	    values.put(new Integer(0), value);
	else
	    values.put(new Integer(((Integer)values.lastKey()).intValue()+1), value);
	return this;
    }

    public void set(int index, CPLZMod value) {
	set(new Integer(index), value);
    }

    public void set(Integer index, CPLZMod value) {
	if (!value.getValue().equals(BigInteger.ZERO)) {
	    values.put(index, value);
	}
    }

    public void set(CPLIndex index, CPLPolyZMod poly) {
	Iterator i, v;

	Vector values = poly.getRawValues();

	if (values.size() != index.values.size())
	    throw new CryptoProtocolException(CryptoProtocolException.COMPUTATIONERROR,
					      "The size of the index is different than the size of values");

	for (i=index.values.iterator(), v=values.iterator(); i.hasNext(); ) {
	    set((Integer)i.next(), (CPLZMod)v.next());
	}
    }

    public Vector getRawValues() {
	Vector res = new Vector();
	for (Iterator i = values.entrySet().iterator() ; i.hasNext() ;) {
	    Map.Entry me = (Map.Entry)i.next();
	    res.add(me.getValue());
	}
	return res;
    }

    public CPLZMod get(int index) {
	return (CPLZMod)values.get(new Integer(index));
    }

    public CPLPolyZMod getPart(CPLIndex index) {
	CPLPolyZMod res = new CPLPolyZMod(p);
	for (Iterator i=index.values.iterator(); i.hasNext(); ) {
	    Integer x = (Integer)i.next();
	    res.set(x, (CPLZMod)values.get(x));
	}
	return res;
    }

    static class AddOperation extends CPLZModOperation {
	public CPLZMod operation(CPLZMod a, CPLZMod b) {
	    return CPLZMod.add(a, b);
	}
    }

    static class SubtractOperation extends CPLZModOperation {
	public CPLZMod operation(CPLZMod a, CPLZMod b) {
	    return CPLZMod.sub(a, b);
	}
    }
    
    static class DivideOperation extends CPLZModOperation {
	public CPLZMod operation(CPLZMod a, CPLZMod b) {
	    return CPLZMod.div(a, b);
	}
    }
    
    static class MultiplyOperation extends CPLZModOperation {
	public CPLZMod operation(CPLZMod a, CPLZMod b) {
	    return CPLZMod.mul(a, b);
	}
    }

    static class ModOperation extends CPLZModOperation {
	public CPLZMod operation(CPLZMod a, CPLZMod b) {
	    return CPLZMod.mod(a, b);
	}
    }

    private static AddOperation addop;
    private static SubtractOperation subop;
    private static MultiplyOperation mulop;
    private static DivideOperation divop;
    private static ModOperation modop;

    static {
	addop = new AddOperation();
	subop = new SubtractOperation();
	mulop = new MultiplyOperation();
	divop = new DivideOperation();
	modop = new ModOperation();
    }


    private CPLPolyZMod numberOperation(CPLZModOperation op, CPLZMod n) {
	CPLPolyZMod res = new CPLPolyZMod(p);

	for (Iterator i = values.entrySet().iterator() ; i.hasNext() ;) {
	    Map.Entry me = (Map.Entry)i.next();
	    res.set((Integer)me.getKey(), op.operation((CPLZMod)me.getValue(), n));
	}
	return res;
    }

    public CPLPolyZMod add(CPLZMod n) {
	return numberOperation(addop, n);
    }

    public CPLPolyZMod sub(CPLZMod n) {
	return numberOperation(subop, n);
    }

    public CPLPolyZMod mul(CPLZMod n) {
	return numberOperation(mulop, n);
    }

    public CPLPolyZMod div(CPLZMod n) {
	return numberOperation(divop, n);
    }

    public CPLPolyZMod mod(CPLZMod n) {
	return numberOperation(modop, n);
    }

    public CPLPolyZMod arrayOperation(CPLZModOperation op, CPLPolyZMod a) {
	CPLPolyZMod res = new CPLPolyZMod(p);
	Iterator i, j;
	Map.Entry ie = null, je = null;

	i = values.entrySet().iterator();
	j = a.values.entrySet().iterator();
	if (i.hasNext())
	    ie = (Map.Entry)i.next();
	if (j.hasNext())
	    je = (Map.Entry)j.next();

	while (ie != null || je != null) {
	    if (ie == null) {
		res.set((Integer)je.getKey(), (CPLZMod)je.getValue());
	    }
	    else if (je == null) {
		res.set((Integer)ie.getKey(), (CPLZMod)ie.getValue());
	    }
	    else {
		int c = ((Integer)ie.getKey()).compareTo((Integer)je.getKey());
		if (c == 0) {
		    res.set((Integer)ie.getKey(), op.operation((CPLZMod)ie.getValue(), 
							       (CPLZMod)je.getValue()));
		    if (i.hasNext())
			ie = (Map.Entry)i.next();
		    else
			ie = null;

		    if (j.hasNext())
			je = (Map.Entry)j.next();
		    else
			je = null;
		}
		else if (c > 0) {
		    res.set((Integer)je.getKey(), (CPLZMod)je.getValue());
		    if (j.hasNext())
			je = (Map.Entry)j.next();
		    else
			je = null;		    
		}
		else {
		    res.set((Integer)ie.getKey(), (CPLZMod)ie.getValue());
		    if (i.hasNext())
			ie = (Map.Entry)i.next();
		    else
			ie = null;
		}
	    }
	}
	return res;
    }

    public CPLPolyZMod add(CPLPolyZMod a) {
	return arrayOperation(addop, a);
    }

    public CPLPolyZMod subtract(CPLPolyZMod a) {
	return arrayOperation(subop, a);
    }

    public CPLPolyZMod multiply(CPLPolyZMod a) {
	throw new RuntimeException("FIXME: polynomial multiplucation is not yet implemented");
    }

    public CPLPolyZMod divide(CPLPolyZMod a) {
	throw new RuntimeException("FIXME: polynomial division is not yet implemented");
    }

    public CPLZ calc(CPLZ n) {
	BigInteger sum = BigInteger.ZERO;
	for (Iterator i = values.entrySet().iterator() ; i.hasNext() ;) {
	    Map.Entry me = (Map.Entry)i.next();
	    
	    sum = sum.add(((CPLZ)me.getValue()).getValue().multiply(
                          n.getValue().pow(((Integer)me.getKey()).intValue())));
	}
	return new CPLZ(sum);
    }

    public void send(CommunicationChannel cc) {
	cc.send(new Integer(values.entrySet().size()));
	cc.send(p.getValue());
	for (Iterator i = values.entrySet().iterator() ; i.hasNext() ;) {
	    Map.Entry me = (Map.Entry)i.next();
	    cc.send((Integer)me.getKey());
	    cc.send(((CPLZMod)me.getValue()).getValue());
	}
    }
    public String toString() {
	String res = "";
	Iterator i = values.entrySet().iterator();
	while (i.hasNext()) {
	    Map.Entry me = (Map.Entry)i.next();
	    Integer p=(Integer)me.getKey();
	    CPLZMod val = (CPLZMod)me.getValue();

	    if (val.getValue().compareTo(BigInteger.ZERO) >= 0)
		res += "+";

	    if (p.intValue() == 0)
		res += val;
	    else if (p.intValue() == 1)
		res += val + "x";
	    else
		res += val + "x^" + p;
	}
	return res;	
    }
    

    public void receive(CommunicationChannel cc) {
	values = new TreeMap();
	int n = ((Integer)cc.receive()).intValue();
	p = new CPLZ((BigInteger)cc.receive());
	for (int i=0; i<n; i++) {
	    set((Integer)cc.receive(), new CPLZMod(p, (BigInteger)cc.receive()));
	}
    }

    public void receive_index(CommunicationChannel cc) {
	set((Integer)cc.receive(), new CPLZMod(p, (BigInteger)cc.receive()));
    }
}

