package cpl.runtime;

import java.util.*;
import java.io.*;

public class CC_Multi_Self {
    private CommunicationChannel[][] cc;
    
    public CC_Multi_Self(int n) throws Exception {
	int i, j;

	cc = new CommunicationChannel[n][n];

	for (i=0; i<n; i++)
	    for (j=0; j<n; j++)
		if (i == j)
		    cc[i][j] = null;
		else {
		    PipedOutputStream posA = new PipedOutputStream();
		    PipedOutputStream posB = new PipedOutputStream();
		    
		    PipedInputStream pisA = new PipedInputStream(posB);
		    PipedInputStream pisB = new PipedInputStream(posA);
		    
		    ObjectOutputStream ousA = new ObjectOutputStream(posA);
		    ObjectOutputStream ousB = new ObjectOutputStream(posB);
		    
		    ObjectInputStream oisA = new ObjectInputStream(pisA);
		    ObjectInputStream oisB = new ObjectInputStream(pisB);

		    cc[i][j] = new CommunicationChannel(oisA, ousA);
		}
    }

    public CommunicationChannel[] get(int n) {
	return cc[n];
    }
}
