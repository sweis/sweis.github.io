package cpl.runtime;

import java.math.*;
import java.util.*;

abstract class CPLZOperation {
    abstract public CPLZ operation(CPLZ a, CPLZ b);
}

public class CPLPolyZ {
    public TreeMap values;

    public CPLPolyZ() {
	values = new TreeMap();
    }

    public CPLPolyZ put(CPLZ value) {
	if (values.isEmpty())
	    values.put(new Integer(0), value);
	else
	    values.put(new Integer(((Integer)values.lastKey()).intValue()+1), value);
	return this;
    }

    public void set(CPLPolyZ p) {
	values = (TreeMap)p.values.clone();
    }

    public void set(int index, CPLZ value) {
	set(new Integer(index), value);
    }

    public void set(Integer index, CPLZ value) {
	if (!value.getValue().equals(BigInteger.ZERO)) {
	    values.put(index, value);
	}
    }

    public void set(CPLIndex index, CPLPolyZ poly) {
	Iterator i, v;

	Vector values = poly.getRawValues();

	if (values.size() != index.values.size())
	    throw new CryptoProtocolException(CryptoProtocolException.COMPUTATIONERROR,
					      "The size of the index is different than the size of values");

	for (i=index.values.iterator(), v=values.iterator(); i.hasNext(); ) {
	    set((Integer)i.next(), (CPLZ)v.next());
	}
    }

    public Vector getRawValues() {
	Vector res = new Vector();
	for (Iterator i = values.entrySet().iterator() ; i.hasNext() ;) {
	    Map.Entry me = (Map.Entry)i.next();
	    res.add(me.getValue());
	}
	return res;
    }

    public CPLZ get(int index) {
	return (CPLZ)values.get(new Integer(index));
    }

    public CPLPolyZ getPart(CPLIndex index) {
	CPLPolyZ res = new CPLPolyZ();
	for (Iterator i=index.values.iterator(); i.hasNext(); ) {
	    Integer x = (Integer)i.next();
	    res.set(x, (CPLZ)values.get(x));
	}
	return res;
    }

    static class AddOperation extends CPLZOperation {
	public CPLZ operation(CPLZ a, CPLZ b) {
	    return CPLZ.add(a, b);
	}
    }

    static class SubtractOperation extends CPLZOperation {
	public CPLZ operation(CPLZ a, CPLZ b) {
	    return CPLZ.sub(a, b);
	}
    }
    
    static class DivideOperation extends CPLZOperation {
	public CPLZ operation(CPLZ a, CPLZ b) {
	    return CPLZ.div(a, b);
	}
    }
    
    static class MultiplyOperation extends CPLZOperation {
	public CPLZ operation(CPLZ a, CPLZ b) {
	    return CPLZ.mul(a, b);
	}
    }

    static class ModOperation extends CPLZOperation {
	public CPLZ operation(CPLZ a, CPLZ b) {
	    return CPLZ.mod(a, b);
	}
    }

    private static AddOperation addop;
    private static SubtractOperation subop;
    private static MultiplyOperation mulop;
    private static DivideOperation divop;
    private static ModOperation modop;

    static {
	addop = new AddOperation();
	subop = new SubtractOperation();
	mulop = new MultiplyOperation();
	divop = new DivideOperation();
	modop = new ModOperation();
    }

    private CPLPolyZ numberOperation(CPLZOperation op, CPLZ n) {
	CPLPolyZ res = new CPLPolyZ();

	for (Iterator i = values.entrySet().iterator() ; i.hasNext() ;) {
	    Map.Entry me = (Map.Entry)i.next();
	    res.set((Integer)me.getKey(), op.operation((CPLZ)me.getValue(), n));
	}
	return res;
    }

    public CPLPolyZ add(CPLZ n) {
	return numberOperation(addop, n);
    }

    public CPLPolyZ sub(CPLZ n) {
	return numberOperation(subop, n);
    }

    public CPLPolyZ mul(CPLZ n) {
	return numberOperation(mulop, n);
    }

    public CPLPolyZ div(CPLZ n) {
	return numberOperation(divop, n);
    }

    public CPLPolyZ mod(CPLZ n) {
	return numberOperation(modop, n);
    }

    public CPLPolyZ arrayOperation(CPLZOperation op, CPLPolyZ a) {
	CPLPolyZ res = new CPLPolyZ();
	Iterator i, j;
	Map.Entry ie = null, je = null;

	i = values.entrySet().iterator();
	j = a.values.entrySet().iterator();
	if (i.hasNext())
	    ie = (Map.Entry)i.next();
	if (j.hasNext())
	    je = (Map.Entry)j.next();

	while (ie != null || je != null) {
	    if (ie == null) {
		res.set((Integer)je.getKey(), (CPLZ)je.getValue());
	    }
	    else if (je == null) {
		res.set((Integer)ie.getKey(), (CPLZ)ie.getValue());
	    }
	    else {
		int c = ((Integer)ie.getKey()).compareTo((Integer)je.getKey());
		if (c == 0) {
		    res.set((Integer)ie.getKey(), op.operation((CPLZ)ie.getValue(), 
							       (CPLZ)je.getValue()));
		    if (i.hasNext())
			ie = (Map.Entry)i.next();
		    else
			ie = null;

		    if (j.hasNext())
			je = (Map.Entry)j.next();
		    else
			je = null;
		}
		else if (c > 0) {
		    res.set((Integer)je.getKey(), (CPLZ)je.getValue());
		    if (j.hasNext())
			je = (Map.Entry)j.next();
		    else
			je = null;		    
		}
		else {
		    res.set((Integer)ie.getKey(), (CPLZ)ie.getValue());
		    if (i.hasNext())
			ie = (Map.Entry)i.next();
		    else
			ie = null;
		}
	    }
	}
	return res;
    }

    public CPLPolyZ add(CPLPolyZ a) {
	return arrayOperation(addop, a);
    }

    public CPLPolyZ subtract(CPLPolyZ a) {
	return arrayOperation(subop, a);
    }

    public CPLPolyZ multiply(CPLPolyZ a) {
	throw new RuntimeException("FIXME: polynomial multiplucation is not yet implemented");
    }

    public CPLPolyZ divide(CPLPolyZ a) {
	throw new RuntimeException("FIXME: polynomial division is not yet implemented");
    }

    public CPLZ calc(CPLZ n) {
	BigInteger sum = BigInteger.ZERO;
	for (Iterator i = values.entrySet().iterator() ; i.hasNext() ;) {
	    Map.Entry me = (Map.Entry)i.next();
	    
	    sum = sum.add(((CPLZ)me.getValue()).getValue().multiply(
                          n.getValue().pow(((Integer)me.getKey()).intValue())));
	}
	return new CPLZ(sum);
    }

    public String toString() {
	String res = "";
	Iterator i = values.entrySet().iterator();
	while (i.hasNext()) {
	    Map.Entry me = (Map.Entry)i.next();
	    Integer p=(Integer)me.getKey();
	    CPLZ val = (CPLZ)me.getValue();

	    if (val.getValue().compareTo(BigInteger.ZERO) >= 0)
		res += "+";

	    if (p.intValue() == 0)
		res += val;
	    else if (p.intValue() == 1)
		res += val + "x";
	    else
		res += val + "x^" + p;
	}
	return res;	
    }
    
    public void send(CommunicationChannel cc) {
	cc.send(new Integer(values.entrySet().size()));
	
	for (Iterator i = values.entrySet().iterator() ; i.hasNext() ;) {
	    Map.Entry me = (Map.Entry)i.next();
	    cc.send((Integer)me.getKey());
	    ((CPLZ)me.getValue()).send(cc);
	}
    }

    public void receive(CommunicationChannel cc) {
	values = new TreeMap();
	int n = ((Integer)cc.receive()).intValue();
	for (int i=0; i<n; i++) {
	    set((Integer)cc.receive(), new CPLZ((BigInteger)cc.receive()));
	}
    }

    public void receive_index(CommunicationChannel cc) {
	set((Integer)cc.receive(), new CPLZ((BigInteger)cc.receive()));
    }
}
