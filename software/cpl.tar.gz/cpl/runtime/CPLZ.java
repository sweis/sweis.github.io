package cpl.runtime;

import java.math.*;
import java.util.*;

public class CPLZ {
    final private static int defaultPrimeCertainty = 15;

    protected BigInteger value;

    public BigInteger getValue() {
	return value;
    }

    public CPLZ() {
	value = BigInteger.ZERO;
    }

    public CPLZ(BigInteger value) {
	this.value = value;
    }

    public CPLZ(String constant) {
	this(new BigInteger(constant));
    }
    
    public void set(CPLZ z) {
	value = z.getValue();
    }

    public void select(int length) {
	value = CPLSupport.getRandom(length);
    }

    static public CPLZ get(String constant) {
	return new CPLZ(constant);
    }

    static public CPLZ get(int value) {
	return new CPLZ(new BigInteger(Integer.toString(value)));
    }

    static public CPLZ getPrime(int bitLength, int certainty) {
	return new CPLZ(CPLSupport.getPrime(bitLength, certainty));
    }

    static public CPLZ getPrime(int bitLength) {
	return getPrime(bitLength, defaultPrimeCertainty);
    }

    static public CPLZ getRandom(int bitLength) {
	return new CPLZ(CPLSupport.getRandom(bitLength));
    }

    static public CPLZ mod(CPLZ left, CPLZ right) {
	return new CPLZ(left.getValue().mod(right.getValue()));
    }

    static public CPLZ add(CPLZ left, CPLZ right) {
	return new CPLZ(left.getValue().add(right.getValue()));
    }

    static public CPLZ sub(CPLZ left, CPLZ right) {
	return new CPLZ(left.getValue().subtract(right.getValue()));
    }

    static public CPLZ mul(CPLZ left, CPLZ right) {
	return new CPLZ(left.getValue().multiply(right.getValue()));
    }

    static public CPLZ div(CPLZ left, CPLZ right) {
	return new CPLZ(left.getValue().divide(right.getValue()));
    }

    // SW: Needed to add something to negate

    static public CPLZ xor(CPLZ left, CPLZ right) {
	return new CPLZ(left.getValue().xor(right.getValue()));
    }

    public CPLZ gcd(CPLZ right) {
	return new CPLZ(value.gcd(right.getValue()));
    }
    
    /*
    static public CPLZ neg(CPLZ value) {
	return new CPLZ(value.getValue().negate());
    }
    */

    static public CPLZ dot(CPLZ left, CPLZ right) {
	byte[] l, r, con;
	int i;

	l = left.getValue().toByteArray();
	r = right.getValue().toByteArray();
	con = new byte[l.length + r.length];
	for (i=0; i<l.length; i++)
	    con[i] = l[i];
	for (i=0; i<r.length; i++)
	    con[i+l.length] = r[i];
	return new CPLZ(new BigInteger(con));
    }

    public CPLZMod mod(CPLZ p) {
	return new CPLZMod(p, value);
    }

    public String toString() {
	return value.toString();
    }

    static public CPLZ hash(CPLZ z) {
	return new CPLZ(CPLSupport.hash(z.getValue()));
    }

    static public CPLZ time() {
	return new CPLZ(new BigInteger(Long.toString(System.currentTimeMillis())));
    }

    public void send(CommunicationChannel cc) {
	cc.send(value);
    }

    public void receive(CommunicationChannel cc) {
	value = (BigInteger)cc.receive();
    }

    public void send_index(CommunicationChannel cc, int index) {
	cc.send(new Integer(index));
	cc.send(getValue());
    }
}




