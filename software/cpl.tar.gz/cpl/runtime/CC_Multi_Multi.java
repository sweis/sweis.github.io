package cpl.runtime;

import java.util.*;
import java.io.*;

public class CC_Multi_Multi {
    private CommunicationChannel[][] first;
    private CommunicationChannel[][] second;
    
    public CC_Multi_Multi(int x, int y) throws Exception {
	int i, j;

	first = new CommunicationChannel[x][y];
	second = new CommunicationChannel[y][x];

	for (i=0; i<x; i++) {
	    for (j=0; j<y; j++) {
		PipedOutputStream posA = new PipedOutputStream();
		PipedOutputStream posB = new PipedOutputStream();
		
		PipedInputStream pisA = new PipedInputStream(posB);
		PipedInputStream pisB = new PipedInputStream(posA);
		
		ObjectOutputStream ousA = new ObjectOutputStream(posA);
		ObjectOutputStream ousB = new ObjectOutputStream(posB);
		
		ObjectInputStream oisA = new ObjectInputStream(pisA);
		ObjectInputStream oisB = new ObjectInputStream(pisB);
		first[i][j] = new CommunicationChannel(oisA, ousA);
		second[j][i] = new CommunicationChannel(oisB, ousB);
	    }
	}
    }

    public CommunicationChannel[] getFirst(int n) {
	return first[n];
    }

    public CommunicationChannel[] getSecond(int n) {
	return second[n];
    }
}
