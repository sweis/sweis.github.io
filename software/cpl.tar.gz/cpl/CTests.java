package cpl;

public class CTests extends CodeElement {
    public Expression test;

    public CTests(Expression test) {
	super(TESTS);

	this.test= test;
    }
}
