package cpl;

abstract public class UOperation {
    abstract public Field getReturnField(Field arg);
    
    abstract public String getJavaCode(Field field, String arg);

    abstract public String getLatexCode(String arg);

    abstract public String getSymbol();

    public String toString() {
	return getSymbol();
    }
}
