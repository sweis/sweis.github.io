package cpl;

import java.util.*;
import java.io.*;

public class GenerateJava {
    
    public static void main(String args[]) throws Exception {
	String config_file = "", source_file = "";
	boolean use_config = false;
	FileInputStream config_is = null, source_is = null;
	JavaConfiguration jc = null;

	try {
	    if (args[0].equals("-c")) {
		use_config = true;
		config_file = new String(args[1]);
		source_file = new String(args[2]);
	    }
	    else {
		source_file = new String(args[0]);
	    }
	} catch (Exception e) {
	    System.out.println("GenerateJava [-c config_filename] source_filename");
	    System.out.println("Arguments passed are not of the required format.");

	    return;
	}

	if (use_config)
	    try {
		config_is = new FileInputStream(config_file);
	    } catch (Exception e) {
		System.out.println("Cannot open configuration file " + config_file);
		System.out.println(e);
		return;
	    }

	try {
	    source_is = new FileInputStream(source_file);
	} catch (Exception e) {
	    System.out.println("Cannot open source file " + source_file);
	    System.out.println(e);
	    return;
	}
	
	if (use_config) {
	    System.out.println("Parsing configuration file " + config_file);
	    jc = JavaConfParser.parseJavaConf(config_is);
	}

	System.out.println("Parsing source file " + source_file);
	Protocol p= CPLParser.parseProtocol(source_is, jc, null);

	System.out.println("Parsing statistics:");
	System.out.println(p);
	genProtocol(p);
    }

    static String tabs(int level) {
	String s= "";
	for (int i= 0; i<level; i++) {
	    s= s+ "    ";
	}
	return s;
    }

    static void genProtocol(Protocol protocol) throws Exception {
	for (Iterator i= protocol.parties.iterator(); i.hasNext(); ) {
	    Party p= (Party) i.next();
	    genParty(protocol, p);
	}

	for (Iterator i= protocol.multiparties.iterator(); i.hasNext(); ) {
	    Party p= (Party) i.next();
	    genParty(protocol, p);
	}

	genBoilerPlate(protocol);
    }
    

    static void genParty(Protocol protocol, Party party) throws Exception {
	String className= protocol.name + "_party_" + party.name;
	PrintStream os;

	os= new PrintStream(new FileOutputStream(className+".java"));
	genHeader(protocol, party, os);
	genCode(protocol, party, os);
	genFooter(protocol, party, os);
    }

    static void genHeader(Protocol protocol, Party party, PrintStream os) {
	String className= protocol.name + "_party_" + party.name;
	/* write headers */

	os.println("/* This class was automatically generated from CPL code using cpl.GenerateJava */ \n");
	
	os.println("import java.io.*;");
	os.println("import java.math.BigInteger;");
	os.println("import cpl.runtime.*;");

	os.println();

	os.println("public class " + className + " implements Runnable {");
	os.println();

	if (protocol.parameters.size() > 0) {
	    os.println(tabs(1) + "/* global parameters */");

            genVariableDefs(protocol.parameters, false, os);
	}

	if (party.isMulti())
	    os.println(tabs(1) + "int _$ID_ = 0;");

	os.println();

	if (party.locals.size() > 0) {
	    os.println(tabs(1) + "/* locals */");
	    genVariableDefs(party.locals, false, os);
	}

	os.println();

	os.println(tabs(1) + "/* helper variable for for loops */");
	os.println(tabs(1) + "int _$index_ = 0;");
	os.println();

	/*	
	Vector otherParties= (Vector) protocol.parties.clone();
	otherParties.addAll(protocol.multiparties);

	if (!party.isMulti()) 
	    otherParties.remove(party);
	*/

	os.println(tabs(1) + "/* communication channel(s) */");
	genCommChannelDefs(party.connectedParties, false, os);
	os.println();

	os.println(tabs(1)+"/* constructor */");
	os.print(tabs(1)+"public "+className+"(");

	boolean written = false; // have we started outputting any parameters

	if (protocol.parameters.size() > 0) {
	    written = true;
	    genVariableDefs(protocol.parameters, true, os);
	}

	if (party.isMulti()) {
	    if (written)
		os.print(", ");
	    else 
		written = true;
	    os.print("int _$ID_");
	}

	if (party.parameters.size() > 0) {
	    if (written)
		os.print(", ");
	    else 
		written = true;
	    genVariableDefs(party.parameters, true, os);
	}

	if (party.connectedParties.size() > 0) {
	    if (written)
		os.print(", ");
	    else 
		written = true;
	    genCommChannelDefs(party.connectedParties, true, os);
	}
	os.println(") {");

	if (protocol.assert != null || party.assert != null) {
	    os.println(tabs(2) + "/* verify asserts */");

            if (protocol.assert != null) {
                os.println(tabs(2) + "CPLSupport.assert("
                           + protocol.assert.getJavaCode() 
                           + ", \"" + protocol.assert + "\");");
            }

            if (party.assert != null) {
                os.println(tabs(2) + "CPLSupport.assert("
                           + party.assert.getJavaCode() 
                           + ", \"" + party.assert + "\");");
            }
                 
        }


	for (Iterator i= protocol.parameters.iterator(); i.hasNext(); ) {
	    Variable param= (Variable) i.next();

	    os.println(tabs(2) + "this." + param.name + " = " + param.name + ";");
	}

	for (Iterator i= party.parameters.iterator(); i.hasNext(); ) {
	    Variable param= (Variable) i.next();

	    os.println(tabs(2) + "this." + param.name + " = " + param.name + ";");
	}

	for (Iterator i= party.connectedParties.iterator(); i.hasNext(); ) {
	    Party otherParty= (Party) i.next();

	    os.println(tabs(2) + "this." + getChannelName(otherParty) + " = "
		       + getChannelName(otherParty)+";");
	}

	if (party.isMulti())
	    os.println(tabs(2) + "this._$ID_ = _$ID_;");

	for (Iterator i= party.locals.iterator(); i.hasNext(); ) {
	    Variable var= (Variable) i.next();

	    os.println(tabs(2) + var.getJavaName() + " = " + var.field.getJavaConstructor() + ";");
	}

	os.println(tabs(1) + "}");
	
    }
    
    static void genVariableDefs(Collection variables, boolean inHeader, PrintStream os) {
	if (variables.size() == 0) return;


	for (Iterator i= variables.iterator(); i.hasNext(); ) {
	    Variable var= (Variable) i.next();

            if (!inHeader) os.print(tabs(1) + "private ");

            os.print(var.field.getJavaType() + " " + var.getJavaName());    

	    if (inHeader) {
                if (i.hasNext()) os.print(", ");
                else;
	    }
            else os.println(";");
	}

    }

    static void genCommChannelDefs(Collection parties,  boolean inHeader, PrintStream os) {

	for (Iterator i= parties.iterator(); i.hasNext(); ) {
	    Party party= (Party) i.next();

	    if (!inHeader)
		os.print(tabs(1)+"private ");

	    os.print(party.getJavaCommunicationChannelType() + " ");
	    
	    os.print(getChannelName(party));

	    if (inHeader) {
		if (i.hasNext())
		    os.print(", ");
	    }
	    else
		os.println(";");
		    
	}
    }
    
    static String getChannelName(Party dest) {
	return "cc_to_"+dest.name;
    }

    static void genCodeElementCode(Protocol protocol, Party party, PrintStream os, CodeElement statement, int tabs) {
	switch(statement.type) {
	    
 	case CodeElement.SELECTS:
	    CSelects csel= (CSelects) statement;
	    int ntabs = 2+tabs;

	    // accomodate "such that" tests
	    if (csel.test != null) {
		os.println(tabs(2+tabs) + "do {");
		ntabs = 3+tabs;
	    }
	    
	    for (Iterator j = csel.typed_var_list.iterator(); j.hasNext();) {
		Expression e = (Expression) j.next();
		switch (e.type) {
		case Expression.VARIABLE:
		    EVariable ev = (EVariable)e;
		    os.println(tabs(ntabs) + ev.variable.field.getJavaCodeForSelect(ev.variable.getJavaName()) + ";");
		    break;
		case Expression.POLYREF:
		    EPolyRef ear = (EPolyRef)e;
		    os.println(tabs(ntabs) + ear.poly.getJavaName() + ".select(" + ear.index.getJavaCode() + ");");
		    break;
		}
	    }
	    
	    // now write test
	    if (csel.test != null) {
		os.println(tabs(2+tabs) + "} while (!(" 
			   + csel.test.getJavaCode()
			   + "));");
	    }
	    break;

	case CodeElement.COMPUTESVARIABLE:
	    CComputesVariable ccompvar= (CComputesVariable) statement;
	    if (ccompvar.variable.field.isJavaPrimitiveType())
		os.println(tabs(2+tabs) + ccompvar.variable.getJavaName() +
			   " = " + ccompvar.value.getJavaCode() + ";");
	    else
		os.println(tabs(2+tabs) + ccompvar.variable.getJavaName() +
			   ".set(" + ccompvar.value.getJavaCode() + ");");
	    break;

	case CodeElement.COMPUTESPOLYREF:
	    CComputesPolyRef ccomparef= (CComputesPolyRef) statement;
	    os.println(tabs(2+tabs) + ccomparef.poly.getJavaName() +
		       ".set(" + ccomparef.index.getJavaCode() + ", " +
		       ccomparef.value.getJavaCode() + ");");
	    break;

	case CodeElement.COMPUTESPOLYVAR:
	    CComputesPolyVar ccompavar= (CComputesPolyVar) statement;
	    os.println(tabs(2+tabs) + ccompavar.poly.getJavaName() +
		       ".set(" + ccompavar.index.getJavaCode() + ", " +
		       ccompavar.value.getJavaCode() + ");");

	    break;

	case CodeElement.SENDS:
	    CSends csends= (CSends) statement;
	    if (csends.target.party.isMulti()) {
		String i = (csends.target.index == null) ? "_$index_" : csends.target.index.getJavaName(); 
		os.print(tabs(2+tabs) + "for (" + i + "=0; " +
			   i + "<" + ((MultiParty)csends.target.party).count.getJavaCode() +
			   "; " + i + "++) ");
		if (csends.target.party == party)
		    os.println("if (" + i + "!=_$ID_) {");
		else
		    os.println("{");

		for (Iterator j= csends.args.iterator(); j.hasNext(); ) {
		    SendExpression v= (SendExpression) j.next(); 
		    if (v.index == null) {
			os.println(tabs(3+tabs) + v.value.getJavaCode() + ".send(" + 
				   getChannelName(csends.target.party) + "[" + i + "]);");
		    }
		    else {
			os.println(tabs(3+tabs) + v.value.getJavaCode() + ".send_index(" + 
				   getChannelName(csends.target.party) + "[" + i + "], " +
				   v.index.getJavaCode() + ");");
		    }
		}
		os.println(tabs(2+tabs) + "}");
	    }
	    else {
		for (Iterator j= csends.args.iterator(); j.hasNext(); ) {
		    SendExpression v= (SendExpression) j.next(); 
		    if (v.index == null) {
			os.println(tabs(2+tabs) + v.value.getJavaCode() + ".send(" + 
				   getChannelName(csends.target.party) + ");");
		    }
		    else {
			os.println(tabs(2+tabs) + v.value.getJavaCode() + ".send_index(" + 
				   getChannelName(csends.target.party) + ", " +
				   v.index.getJavaCode() + ");");
		    }
		}
	    }
	    break;
	    
	    
	case CodeElement.RECEIVES:
	    CReceives creceives= (CReceives) statement;
	    if (creceives.source.isMulti()) {
		String index;
		index = (creceives.sourceVar == null) ? "_$index_" : creceives.sourceVar.name;

		os.print(tabs(2+tabs) + "for (" + index + " = 0; " + index + " < " +
			 ((MultiParty)creceives.source).count.getJavaCode() + "; " + index + "++) ");
		
		if (creceives.source == party)
		    os.println("if (" + index + "!=_$ID_) {");
		else
		    os.println("{");

		
		for (Iterator j= creceives.args.iterator(); j.hasNext(); ) {
		    SendExpression v = (SendExpression) j.next();
		    if (v.index == null) {
			os.println(tabs(3+tabs) + v.asName + ".receive(" + getChannelName(creceives.source) + 
				   "[" + index + "]);");
		    }
		    else {
			os.println(tabs(3+tabs) + v.asName + ".receive_index(" + getChannelName(creceives.source) + 
				   "[" + index + "]);");
		    }
		}

		os.println(tabs(2+tabs) + "}");
	    }
	    else {
		for (Iterator j= creceives.args.iterator(); j.hasNext(); ) {
		    SendExpression v = (SendExpression) j.next(); 
		    if (v.index == null) {
			os.println(tabs(2+tabs) + v.asName + ".receive(" + getChannelName(creceives.source) + ");");
		    }
		    else {
			os.println(tabs(2+tabs) + v.asName + ".receive_index(" + getChannelName(creceives.source) + ");");
		    }
		}
	    }
	    break;
	    
	case CodeElement.TESTS:
	    Expression expr= ((CTests) statement).test;
	    os.println(tabs(2+tabs) + "CPLSupport.test("
		       + expr.getJavaCode() +", \"" + expr + "\");");
	    break;
	    
	case CodeElement.FOR:
	    CFor cfor = (CFor) statement;
	    os.println(tabs(2+tabs) + "for (" + cfor.var.getJavaName() +
		       "= "  + cfor.from.getJavaCode() +
		       "; "  + cfor.var.getJavaName() + " <= " + cfor.to.getJavaCode() + 
		       " ; " + cfor.var.getJavaName() + "++) {");
	    genCodeElementCode(protocol, party, os, cfor.ce, tabs+1);
	    os.println(tabs(2+tabs) + "}");
		       
	    break;

	case CodeElement.RETURNS:
	    CReturns cr = (CReturns) statement;
	    
	    for (Iterator j= cr.args.iterator(); j.hasNext(); ) {
		ReturnArg v= (ReturnArg) j.next(); 
		if (v.value != null) {
		    if (v.var.field.isJavaPrimitiveType())
			os.println(tabs(2+tabs) + v.var.getJavaName() +
				   " = " + v.value.getJavaCode() + ";");
		    else
			os.println(tabs(2+tabs) + v.var.getJavaName() +
				   ".set(" + v.value.getJavaCode() + ");");
		}
	    }
	    
	    break;

//  	case CodeElement.DEFINES:
//  	    CDefines cdefines = (CDefines) statement;
//  	    for (Iterator i = cdefines.vars.iterator(); i.hasNext(); ) {
//  		AbsVarDef v = (AbsVarDef) i.next();
//  		switch (v.type) {
//  		case AbsVarDef.VAR:
//  		    Variable var = (Variable)v;
//  		    // do nothing
//  		    break;

//  		case AbsVarDef.POLY:
//  		    Poly poly = (Poly)v;
//  		    os.println(tabs(2+tabs) + poly.name + " = new " + poly.field.getJavaPolyType() + "("
//  			       + poly.from.getJavaCode() + ", "
//  			       + poly.to.getJavaCode() + ");");
//  		    break;
//  		}
//  	    }
	    //	    break;
	}
    }
    
    static void genCode(Protocol protocol, Party party, PrintStream os) {

	os.println();
	os.println(tabs(1)+"/* main function */");
	os.println(tabs(1)+"public void run() {");
	

	for (Iterator i= party.codeElements.iterator(); i.hasNext(); ) {
	    CodeElement statement= (CodeElement) i.next();

	    genCodeElementCode(protocol, party, os, statement, 0);
	}

       os.println(tabs(1)+"}");
    }

	
    static void genFooter(Protocol protocol, Party party, PrintStream os) {
	// functions to grab return values

	for (Iterator i= party.returns.iterator(); i.hasNext(); ) {
	    ReturnArg v= (ReturnArg) i.next();
	    
	    os.println();
	    os.println(tabs(1) + "/* get function for result " + v.var.getJavaName() + " */");
	    os.println(tabs(1) + "public " + v.var.field.getJavaType() + " getResult_" + v.var.getJavaName() + "() {");
	    os.println(tabs(2) + "return " + v.var.getJavaName() + ";");
	    os.println(tabs(1) + "}");
	}

	// and ... we're done
	os.println("}");
    }

    static void genBoilerPlate(Protocol protocol) throws Exception {
	String className= protocol.name + "_BoilerPlate";
	PrintStream os;
	Iterator it;
	int i, j;
	Party[] party;
	MultiParty[] mparty;
	
	os= new PrintStream(new FileOutputStream(className + ".java"));

	party = new Party[protocol.parties.size()];
	for (i=0, it=protocol.parties.iterator(); it.hasNext(); i++)
	    party[i] = (Party)it.next();

	mparty = new MultiParty[protocol.multiparties.size()];
	for (i=0, it=protocol.multiparties.iterator(); it.hasNext(); i++)
	    mparty[i] = (MultiParty)it.next();

	os.println("import cpl.runtime.*;");
	os.println("import java.util.*;");
	os.println();
	os.println("public class " + className + "{");

	os.println(tabs(1) + "/* Protocol's " + 
		   protocol.name + " parameters */");
	for (it = protocol.parameters.iterator(); it.hasNext(); ) {
	    Variable var = (Variable)it.next();
	    os.println(tabs(1) + "private " + var.field.getJavaType() + 
		       " " + var.getJavaName() + ";");
	}

	os.println();

	for (i=0; i<party.length; i++) {
	    if (!party[i].parameters.isEmpty()) {
		os.println(tabs(1) + "/* Party's " + 
			   party[i].name + " parameters */");
		for (it = party[i].parameters.iterator(); it.hasNext(); ) {
		    Variable var = (Variable)it.next();
		    os.println(tabs(1) + "private " + 
			       var.field.getJavaType() + " " +
			       party[i].name + "_" + var.getJavaName() + ";");
		}
		os.println();
	    }
	}

	for (i=0; i<mparty.length; i++) {
	    if (!mparty[i].parameters.isEmpty()) {
		os.println(tabs(1) + "/* Party's " + 
			   mparty[i].name + " parameters */");
		for (it = mparty[i].parameters.iterator(); it.hasNext(); ) {
		    Variable var = (Variable)it.next();
		    os.println(tabs(1) + "private " + 
			       var.field.getJavaType() + "[] " +
			       mparty[i].name + "_" + var.getJavaName() + ";");
		}
		os.println();
	    }
	}
	
	/* InitParameter method */      

	os.println(tabs(1) + "private void InitParameters(String[] args) {");
	os.println(tabs(2) + "/* Protocol's " 
		   + protocol.name + " parameters */");
	os.println(tabs(2) + "int i = 0;");
	
	for (it = protocol.parameters.iterator(); it.hasNext(); ) {
	    Variable var = (Variable)it.next();
	    os.println(tabs(2) + "if (i < args.length)");
	    
	    if (var.getField().getJavaType().equals("CPLZ")) {
		os.println(tabs(3) + var.getJavaName() + 
			   " = new CPLZ(args[i]);");
		os.println(tabs(2) + "else");
		os.println(tabs(3) + var.getJavaName() + " = null;");
	    }
	    else if (var.getField().getJavaType().equals("int")) {
		os.println(tabs(3) + var.getJavaName() + 
			   " = Integer.parseInt(args[i]);");
		os.println(tabs(2) + "else");
		os.println(tabs(3) + var.getJavaName() + " = 0;");
	    }
	    // os.println(tabs(2) + "/* Boiler plate instantiation for type " 
	    //      + var.getField().getJavaType() + " not supported");
	    //ps.println(tabs(2) + "Please hand code a value here */");
	    //" + var.field.getJavaConstructor() + ";");
	    os.println(tabs(2) + "i++;");
	}

	os.println();

	for (i=0; i<party.length; i++) {
	    if (!party[i].parameters.isEmpty()) {
		os.println(tabs(2) + "/* Party's " + party[i].name + " parameters */");
		for (it = party[i].parameters.iterator(); it.hasNext(); ) {
		    Variable var = (Variable)it.next();
		    os.println(tabs(2) + party[i].name + "_" + var.getJavaName() + " = ;");
		    //			       + var.field.getJavaConstructor() + ";");
		}
		os.println();
	    }
	}

	for (i=0; i<mparty.length; i++) {
	    if (!mparty[i].parameters.isEmpty()) {
		os.println(tabs(2) + "/* Multiple Parties' " + mparty[i].name + " parameters */");
		for (it = mparty[i].parameters.iterator(); it.hasNext(); ) {
		    Variable var = (Variable)it.next();
		    os.println(tabs(2) + mparty[i].name + "_" + var.getJavaName() + " = new " + 
			       var.field.getJavaType() + "[" + mparty[i].count.getJavaCode() + "];");
		    os.println(tabs(2) + "for (int i=0; i<" + mparty[i].count.getJavaCode() + "; i++)");
		    os.println(tabs(3) + mparty[i].name + "_" + var.getJavaName() + "[i] = ;");
		    //		    + var.field.getJavaConstructor() + ";");
		}
		os.println();
	    }
	}

	os.println(tabs(1) + "}");
	os.println();
	os.println(tabs(1) + "public void run() throws Exception {");
	os.println(tabs(2) + "/* Print parameters */");
	if (!protocol.parameters.isEmpty()) {
	    os.println(tabs(2) + "System.out.println(\"Protocol " + protocol.name + " parameters\");");
	    for (it=protocol.parameters.iterator(); it.hasNext(); ) {
		Variable var = (Variable)it.next();
		os.println(tabs(2) + "System.out.println(\"" + var.getJavaName() + " = \" + " +
			   var.getJavaName() + ");");
	    }
	    os.println();
	}

	for (i=0; i<party.length; i++) {
	    if (!party[i].parameters.isEmpty()) {
		os.println(tabs(2) + "System.out.println(\"" + party[i].name + " parameters\");");
		for (it=party[i].parameters.iterator(); it.hasNext(); ) {
		    Variable var = (Variable)it.next();
		    os.println(tabs(2) + "System.out.println(\"" + var.getJavaName() + " = \" + " +
			       party[i].name + "_" + var.getJavaName() + ");");
		}
		os.println(tabs(2) + "System.out.println();");
		os.println();
	    }
	}
	
	for (i=0; i<mparty.length; i++) {
	    if (!mparty[i].parameters.isEmpty()) {
		os.println(tabs(2) + "for (int i=0; i<" + mparty[i].count.getJavaCode() + "; i++) {");
		os.println(tabs(3) + "System.out.println(\"" + mparty[i].name + " + [\" + i + \"] parameters\");");
		for (it=mparty[i].parameters.iterator(); it.hasNext(); ) {
		    Variable var = (Variable)it.next();
		    os.println(tabs(3) + "System.out.println(\"" + var.getJavaName() + " = \" + " +
			       mparty[i].name + "_" + var.getJavaName() + "[i]);");
		}
		os.println(tabs(2) + "}");
		os.println(tabs(2) + "System.out.println();");
		os.println();
	    }
	}

	
	os.println(tabs(2) + "/* CommunicationChannels' construction */");
	for (i=0; i<party.length-1; i++)
	    for (j=i+1; j<party.length; j++)
		if (party[i].connectedParties.contains(party[j])) {
		    os.println(tabs(2) + "CC_Single_Single cc_" + party[i].name + "_" + party[j].name +
			       " = new CC_Single_Single();");
		}

	for (i=0; i<party.length; i++)
	    for (j=0; j<mparty.length; j++)
		if (party[i].connectedParties.contains(mparty[j])) {
		    os.println(tabs(2) + "CC_Single_Multi cc_" + party[i].name + "_" + mparty[j].name +
			       " = new CC_Single_Multi(" + mparty[j].count.getJavaCode() + ");");		    
		}


	for (i=0; i<mparty.length-1; i++)
	    for (j=i+1; j<mparty.length; j++)
		if (mparty[i].connectedParties.contains(mparty[j])) {
		    os.println(tabs(2) + "CC_Multi_Multi cc_" + 
			       mparty[i].name + "_" + mparty[j].name +
			       " = new CC_Multi_Multi(" + 
			       mparty[i].count.getJavaCode() + ", " +
			       mparty[j].count.getJavaCode() + ");"); 
		}

	for (i=0; i<mparty.length; i++)
	    if (mparty[i].connectedParties.contains(mparty[i])) {
		os.println(tabs(2) + "CC_Multi_Self cc_" + mparty[i].name + 
			   "_" + mparty[i].name + "= new CC_Multi_Self(" + 
			   mparty[i].count.getJavaCode() + ");");
	    }

	os.println();
	os.println(tabs(2) + "/* Parties construction */");

	for (i=0; i<party.length; i++) {
	    os.print(tabs(2) + protocol.name + "_party_" + party[i].name + 
		     " " + party[i].name + " = new " + protocol.name + 
		     "_party_" + party[i].name + "(");
	    boolean written = false;
	    for (it = protocol.parameters.iterator(); it.hasNext(); ) {
		if (written)
		    os.print(", ");
		else 
		    written = true;
		Variable var = (Variable)it.next();
		os.print(var.getJavaName());
	    }
	    
	    for (it = party[i].parameters.iterator(); it.hasNext(); ) {
		if (written)
		    os.print(", ");
		else 
		    written = true;
		Variable var = (Variable)it.next();
		os.print(party[i].name + "_" + var.getJavaName() + ", ");
	    }

	    for (it = party[i].connectedParties.iterator(); it.hasNext(); ) {
		Party p = (Party)it.next();
		if (p.isMulti() || 
		    (protocol.parties.indexOf(p) > 
		     protocol.parties.indexOf(party[i]))) {
		    if (written)
			os.print(", ");
		    else 
			written = true;
		    os.print("cc_" + party[i].name + "_" + 
			     p.name + ".getFirst()");
		}
		else {
		    if (written)
			os.print(", ");
		    else 
			written = true;
		    os.print("cc_" + p.name + "_" + 
			     party[i].name + ".getSecond()");
		}
		//		if (it.hasNext())
		//		    os.print(", ");
	    }

	    os.println(");");
	}

	for (i=0; i<mparty.length; i++) {
	    os.println(tabs(2) + protocol.name + "_party_" + mparty[i].name +
		       "[] " + mparty[i].name + " = new " +
		       protocol.name + "_party_" + mparty[i].name + "[" + 
		       mparty[i].count.getJavaCode() + "];");
	    
	    boolean written = false;
	    
	    os.println(tabs(2) + "for (int i=0; i<" + 
		       mparty[i].count.getJavaCode() + "; i++)");
	    os.print(tabs(3) + mparty[i].name + "[i] = new " + 
		     protocol.name + "_party_" + mparty[i].name + "(");

	    for (it = protocol.parameters.iterator(); it.hasNext(); ) {
		if (written)
		    os.print(", ");
		else 
		    written = true;
		Variable var = (Variable)it.next();
		os.print(var.getJavaName());
	    }
	    
	    if (written)
		os.print(", ");
	    written = true;
	    os.print("i");

	    for (it = mparty[i].parameters.iterator(); it.hasNext(); ) {
		os.print(", ");
		Variable var = (Variable)it.next();
		os.print(mparty[i].name + "_" + var.getJavaName() + "[i]");
	    }

	    for (it = mparty[i].connectedParties.iterator(); it.hasNext(); ) {
		Party p = (Party)it.next();
		 os.print(", ");
		if (p == mparty[i]) 
		    os.print("cc_" + p.name + "_" + p.name + ".get(i)");
		else 
		    if (!p.isMulti()) 
			os.print("cc_" + p.name + "_" + 
				 mparty[i].name + ".getSecond(i)");
		    else if (protocol.multiparties.indexOf(p) > 
			     protocol.multiparties.indexOf(mparty[i])) 
			os.print("cc_" + mparty[i].name + "_" + 
				 p.name + ".getFirst(i)");
		    else 
			os.print("cc_" + p.name + "_" + 
				 mparty[i].name + ".getSecond(i)");
	    }
	    
	    os.println(");");
	    os.println();
	}
	os.println(tabs(2) + "/* Threads */");
	for (i=0; i<party.length; i++) {
	    os.println(tabs(2) + "Thread thread_" + party[i].name + " = new Thread(" + party[i].name + ");");
	}
	for (i=0; i<mparty.length; i++) {
	    os.println(tabs(2) + "Thread[] thread_" + mparty[i].name + " = new Thread[" +
		       mparty[i].count.getJavaCode() + "];");
	    os.println(tabs(2) + "for (int i=0; i<" + mparty[i].count.getJavaCode() + "; i++)");
	    os.println(tabs(3) + "thread_" + mparty[i].name + "[i] = new Thread(" + mparty[i].name + "[i]);");
	}
	    
	os.println();
	os.println(tabs(2) + "/* Start threads */");
	for (i=0; i<party.length; i++) {
	    os.println(tabs(2) + "thread_" + party[i].name + ".start();");
	}
	for (i=0; i<mparty.length; i++) {
	    os.println(tabs(2) + "for (int i=0; i<" + mparty[i].count.getJavaCode() + "; i++)");
	    os.println(tabs(3) + "thread_" + mparty[i].name + "[i].start();");
	}
	
	os.println();
	os.println(tabs(2) + "/* Wait until all threads finish */");
	os.println(tabs(2) + "try {");
	for (i=0; i<party.length; i++) {
	    os.println(tabs(3) + "thread_" + party[i].name + ".join();");
	}
	for (i=0; i<mparty.length; i++) {
	    os.println(tabs(3) + "for (int i=0; i<" + mparty[i].count.getJavaCode() + "; i++)");
	    os.println(tabs(4) + "thread_" + mparty[i].name + "[i].join();");
	}
	os.println(tabs(2) + "}");
	os.println(tabs(2) + "catch (Exception e) {");
	os.println(tabs(3) + "e.printStackTrace(System.err);");
	os.println(tabs(3) + "System.exit(1);");
	os.println(tabs(2) + "}");
	os.println();
	os.println(tabs(2) + "/* Print parties' results */");
	for (i=0; i<party.length; i++) {
	    if (!party[i].returns.isEmpty()) {
		os.println(tabs(2) + "System.out.println(\"" + party[i].name + " results\");");
		for (it=party[i].returns.iterator(); it.hasNext(); ) {
		    ReturnArg rarg = (ReturnArg)it.next();
		    os.println(tabs(2) + "System.out.println(\"" + rarg.var.getJavaName() + " = \" + " +
			       party[i].name + ".getResult_" + rarg.var.getJavaName() + "());");
		}
		os.println(tabs(2) + "System.out.println();");
		os.println();
	    }
	}
	
	for (i=0; i<mparty.length; i++) {
	    if (!mparty[i].returns.isEmpty()) {
		os.println(tabs(2) + "for (int i=0; i<" + mparty[i].count.getJavaCode() + "; i++) {");
		os.println(tabs(3) + "System.out.println(\"" + mparty[i].name + "[\" + i + \"] results\");");
		for (it=mparty[i].returns.iterator(); it.hasNext(); ) {
		    ReturnArg rarg = (ReturnArg)it.next();
		    os.println(tabs(3) + "System.out.println(\"" + rarg.var.getJavaName() + " = \" + " +
			       mparty[i].name + "[i].getResult_" + rarg.var.getJavaName() + "());");
		}
		os.println(tabs(2) + "}");
		os.println(tabs(2) + "System.out.println();");
		os.println();
	    }
	}
	os.println(tabs(1) + "}");
	os.println();
	os.println(tabs(1) + "public static void main(String[] args) throws Exception {");
	os.println(tabs(2) + className + " boilerplate = new " + className + "();");
	os.println(tabs(2) + "boilerplate.InitParameters(args);");
	os.println(tabs(2) + "boilerplate.run();");
	os.println(tabs(1) + "}");
	os.println("}");
    }
}


