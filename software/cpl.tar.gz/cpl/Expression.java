/*
  Abstract class, represents expressions in our language.
*/

package cpl;

public abstract class Expression
{

    /* 
       definitions related to expression types.
    */
    public int type;
    public static final int VARIABLE = 0;
    public static final int U_OPERATION = 1;
    public static final int B_OPERATION = 2;
    public static final int CONSTANT = 3;
    public static final int FUNCTION = 4;
    public static final int PARENS = 5;
    public static final int FIELD_SPEC = 6;
    public static final int POLY = 7;
    public static final int POLYREF = 8;
    public static final int POLYVAR = 9;
    public static final int POLYCOMP = 10;
    public static final int MOD_SPEC = 11;

    public Expression(int type)
    {
	this.type= type;
    }

    /*
      This function should compute the return type of this expression,
    */  
    public abstract Field getReturnField();

    public abstract String getJavaCode();

    public abstract String getLatexCode();

    public abstract void setDefaultField(Field field);
}
