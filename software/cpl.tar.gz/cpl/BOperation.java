package cpl;

abstract public class BOperation {
    abstract public Field[] getFields(Field field, Field left, Field right);
    
    abstract public Field getReturnField(Field left, Field right);
    
    abstract public String getJavaCode(Field field, String left, String right);

    abstract public String getLatexCode(String left, String right);

    abstract public String getSymbol();

    public String toString() {
	return getSymbol();
    }
}
