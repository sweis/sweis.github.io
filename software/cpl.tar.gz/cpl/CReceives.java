package cpl;

import java.util.*;

public class CReceives extends CodeElement {

    public Vector args;
    public Party source;
    public Variable sourceVar;

    /*  A vector of variables*/
    public CReceives(Vector args, Variable sourceVar, Party source) {
	super(RECEIVES);

	this.args= args;
	this.sourceVar= sourceVar;
	this.source= source;
    }
}
