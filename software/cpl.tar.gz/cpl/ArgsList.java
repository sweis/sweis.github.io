/*
  represents a list of arguments to a function or a protocol
*/

package cpl;

import java.util.Vector;

public class ArgsList {
    // for now, only expose a vector of Variables

    public Vector args;

    public ArgsList(Vector args) {
	this.args= args;
    }
}
