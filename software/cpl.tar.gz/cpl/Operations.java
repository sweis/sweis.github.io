package cpl;

public class Operations {
    public static BOperation addOperation;
    public static BOperation mulOperation;
    public static BOperation subOperation;
    public static BOperation divOperation;
    public static BOperation powOperation;
    public static BOperation dotOperation;
    public static BOperation modOperation;
    public static BOperation xorOperation;
    public static BOperation LEOperation;
    public static BOperation GROperation;
    public static BOperation LEEOperation;
    public static BOperation GREOperation;
    public static BOperation EQOperation;
    public static BOperation NEQOperation;
    public static BOperation orOperation;
    public static BOperation andOperation;

    public static UOperation uminusOperation;
    public static UOperation unotOperation;


    static {
	addOperation = new BNumOperation("+", "add", "+");
	subOperation = new BNumOperation("-", "sub", "-");
	mulOperation = new BNumOperation("*", "mul", " ");
	divOperation = new BNumOperation("/", "div", "");
	modOperation = new BNumOperation("%", "mod", "\\%");
	xorOperation = new BNumOperation("^", "xor", "xor");
	powOperation = new BPowOperation();
	dotOperation = new BDotOperation();
	LEOperation = new BCompOperation("<", "le", "\\le");
	GROperation = new BCompOperation(">", "gr", "\\gr");
	LEEOperation = new BCompOperation("<=", "lee", "\\lee");
	GREOperation = new BCompOperation(">=", "gre", "\\gre");
	EQOperation = new BCompOperation("=", "eq", "\\eq");
	NEQOperation = new BCompOperation("!=", "neq", "\\neq");
	orOperation = new BBoolOperation("or", "or", "or");
	andOperation = new BBoolOperation("and", "and", "and");
	
	uminusOperation = new UMinusOperation();
	unotOperation = new UNotOperation();
    }    
}
