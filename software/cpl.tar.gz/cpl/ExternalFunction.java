package cpl;

import java.util.*;

public class ExternalFunction implements Function {
    String name;
    Field returnField;
    Vector params;
    String javaName;

    public ExternalFunction (String name, Field returnField, Vector params, String javaName) {
	this.name = name;
	this.returnField = returnField;
	this.params = params;
	this.javaName = javaName;
    }

    public String getName() {
	return name;
    }

    public boolean argsSuitable(Vector args) {
	if (args.size() != params.size())
	    return false;
	
	int i;

	// FIXME: parameters checking:
	/*
	for (i=0; i<params.size(); i++)
	    if (!((Field)params.elementAt(i)).isCompatible(((Expression)args.elementAt(i)).getReturnField())) {
		return false;
	    }
	*/
	return true;
    }

    public String getJavaCodeForCall(Vector args) {
	String res = javaName + "(";
	for (Iterator i=args.iterator(); i.hasNext(); ) {
	    String s = (String)i.next();
	    res += s;
	    if (i.hasNext())
		res += ", ";
	}
	res += ")";
	return res;
    }

    public String getLatexCodeForCall(Vector args) {
	String res = name + "\\left(";
	for (Iterator i=args.iterator(); i.hasNext(); ) {
	    String s = (String)i.next();
	    res += s;
	    if (i.hasNext())
		res += ", ";
	}
	res += "\\right)";
	return res;
    }

    public Field getReturnField() {
	return returnField;
    }

    public Field getArgField(int arg) {
	return (Field)params.elementAt(arg);
    }
    
}
