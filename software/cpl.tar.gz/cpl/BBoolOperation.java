package cpl;

public class BBoolOperation extends BOperation {
    private String javaFunc;
    private String latexSymbol;
    private String symbol;

    public BBoolOperation(String symbol, String javaFunc, String latexSymbol) {
	this.javaFunc = javaFunc;
	this.symbol = symbol;
	this.latexSymbol = latexSymbol;
    }

    public String getJavaCode(Field field, String left, String right) {
	return left + " " + javaFunc + " " + right;
    }

    public String getLatexCode(String left, String right) {
	return left + " \\text{" + latexSymbol + "} " + right;
    }
							       
    public String getSymbol() {
	return symbol;
    }

    public Field[] getFields(Field field, Field left, Field right) {
	Field[] res = new Field[2];
	
	if (field.isBoolean()) {
	    if (left.isBoolean())
		res[0] = Field.getBoolean();
	    else
		return null;

	    if (right.isBoolean())
		res[1] = Field.getBoolean();
	    else
		return null;
	}

	throw new RuntimeException("Can't do operation " + this + " in field " + field);
    }

    public Field getReturnField(Field left, Field right) {
	if (left.isBoolean() && right.isBoolean())
	    return Field.getBoolean();

	throw new RuntimeException("Can't do operation " + this + " between fields " + left + " and " + right);
    }

}

