package cpl;

import java.util.*;


public class Party {
    
    String name;
    Protocol protocol;

    public Collection locals= new Vector();

    // parameters points to variables in locals
    public Vector parameters = new Vector();
    public Expression assert;
    public Vector codeElements = new Vector();
    public Collection returns = new Vector();
    public Vector undefinedVars = new Vector();
    public HashSet connectedParties = new HashSet();

    public Party(String name, Protocol protocol)
    {
	this.name= name;
	this.protocol= protocol;
    }

    public void addCodeElement(CodeElement c) {
	c.party = this;

	protocol.codeElements.add(c);

	codeElements.add(c);

	if (c.type == CodeElement.RETURNS) {
	    returns.addAll( ((CReturns) c).args);
	}

	if (!undefinedVars.isEmpty())
	    throw new RuntimeException("Undefined variable: " + undefinedVars.get(0));
    }

    public void setParameters(Vector params) {
        for (Iterator i = params.iterator(); i.hasNext(); ) {
	    Vector v = (Vector)i.next();
	    addParameter((String)v.elementAt(0), (Field)v.elementAt(1));
        }
    }

    public Variable addParameter(String name, Field field) {
	if (findVariable(name) != null)
            throw new RuntimeException("Duplicate party parameter found: " + name);
	
	Variable res = createVariable(name, field);

	parameters.add(res);
	
	return res;
    }


    public void setAssert(Expression assert) {
        this.assert = assert;
    }
    
    public Variable getVariable(String name) {
        Variable var = findVariable(name);

        if (var == null)
	    throw new RuntimeException("Undefined variable: " + name);
	    
	return var;

	//	undefinedVars.add(new String(name));
	//	return createVariable(name, Field.getInteger());
    }

    public Variable getPoly(String name) {
	Variable var = findVariable(name);
	if (var == null)
	    throw new RuntimeException("Undefined variable: " + name);
	if (!var.field.isPoly())
	    throw new RuntimeException(name + " is not a polynomial");
	return var;
    }


    public Variable createVariable(String name, Field field)
    {
        if (findVariable(name) != null) {
            throw new RuntimeException("Duplicate assignment to " + name + " detected");
        }

        Variable newv = new Variable(name, field, protocol);
        locals.add(newv);

        return newv;
        
    }

    public Variable findVariable(String name) {
        Variable var;
	Iterator i;

	var= protocol.getParameter(name);
	if (var != null) return var;
	
	for (i= parameters.iterator(); i.hasNext(); ) {
	    var = (Variable) i.next();
	    
	    if (var.name.equals(name))
                return var;
	}
	
	for (i= locals.iterator(); i.hasNext(); ) {
	    var = (Variable) i.next();
	    
	    if (var.name.equals(name))
                return var;
	}

        return null;
    }

    public void removeVariable(String name) {
	locals.remove(findVariable(name));
    }

    public boolean isParameter(Variable var) {
	Iterator i;

	if (protocol.getParameter(var.name) != null)
	    return true;

	for (i= parameters.iterator(); i.hasNext(); ) {
		if (var.name.equals(((Variable)i.next()).name))
		    return true;
	}
	return false;
    }

    public Vector translateVars(Vector vars) {
        // create a Vector of vars with the same names and types as
        // the argument vector, which comes from the context of another
        // Party
        
        for (Iterator i = vars.iterator(); i.hasNext(); ) {
	    SendExpression v= (SendExpression) i.next(); 
	    Variable var = findVariable(v.asName);

	    // FIXME: variables with parameter's name should not be able to be received

	    if (v.index == null) {
		if (var != null) {
		    if (!v.value.getReturnField().equals(var.field)) {
			throw new RuntimeException("Variable " + var + " has already been defined in target party "+
						   "in field " + var.field + " and can't be converted to " +
						   "field " + v.value.getReturnField());
		    }
		}
		else
		    createVariable(v.asName, v.value.getReturnField());
	    }
	    else {
		if (var != null) {
		    if (!var.field.isPoly() &&
			!var.field.getPolyCoefField().equals(v.value.getReturnField())) {
			throw new RuntimeException("Variable " + var + " has already been defined in target party and" +
						   "it is of different field");
		    }
			
		}
		else
		    createVariable(v.asName, Field.getPoly(v.value.getReturnField()));
	    }
        };
	
        return vars;
    }

    public void addPartyConnection(Party party) {
	connectedParties.add(party);
    }
    
    public String toString() {
	Variable v;
	String locals_str = "[";
	Iterator i;

	for (i = locals.iterator(); i.hasNext(); ) {
	    v = (Variable)i.next();
	    locals_str = locals_str + v.name;
	    if (i.hasNext())
		locals_str = locals_str + " ";
	}
	locals_str = locals_str + "]";

	return "  party " + name + "\n"
	    + "    " + locals.size() + " locals: " + locals_str + "\n"
	    + "    " + codeElements.size() + " code elements\n";
    }

    public String getJavaCommunicationChannelType() {
	return "CommunicationChannel";
    }

    public boolean isMulti() {
	return false;
    }

}
