package cpl;

/*
  The Field_Integer class represents a field. By default, the var type is Integer.
*/

public class Field_Integer extends Field {

    public Field_Integer() {
	super(INTEGER);
    }

    /* hackish constructor for fields that inherit from this */
    protected Field_Integer(int type) {
        super(type);
    }

    public String getJavaCodeForConstant(String constant) {
	// Check if constant is a proper Integer value. Do that by checking if
	// parseInt throws en error

	try {
	    int k = Integer.parseInt(constant);
	    return constant;
	}
	catch (Exception e) {
	    throw new RuntimeException(constant + " is not a proper Integer constant");
	}
    }

    public String getJavaCodeForSelect(String arg) {
	throw new RuntimeException("Select in integers is not allowed");
    }

    public String getJavaType() {
        return "int";
    }

    public String getJavaConstructor() {
	return "0";
	//	throw new InternalError("This should never been called: Field_Integer.getJavaConstructor");
    }

    public String getLatexCodeForSelect() {
	throw new RuntimeException("FIXME: select in Integers not supported");
    }

    public String getLatexCodeForConstant(String constant) {
	return constant;
    }

    public Field convert(Field field) {
	if (field == null)
	    return this;
	
	switch (field.type) {
	case Z:
	case BITSTRING:
	case ZMOD:
	case INTEGER:
	    return field;
	default:
	    throw new RuntimeException("Cannot convert from field " + this + " to field " + field);
	}
    }

    public String getJavaCodeForConvert(Field from, String arg) {
	switch(from.type) {
	case INTEGER:
	    return arg;
	}
	throw new RuntimeException("This should never happen: Field_Integer.getJavaCodeForConvert");
    }

    public boolean isJavaPrimitiveType() {
	return true;
    }

    public String toString() {
	return "Integer";
    }

}
