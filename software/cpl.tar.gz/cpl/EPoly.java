package cpl;

import java.util.*;

public class EPoly extends Expression
{
    public Vector expr_list;
    public Field field = Field.getPolyZ();

    private Field evalField = null;

    public EPoly(Vector expr_list) {
	super(POLY);
	this.expr_list = expr_list;
    }

    public Field getReturnField() {
        return field;
    }

    public String getJavaCode() {
	String res;

	Iterator i;

	res = "(" + field.getJavaConstructor() + ")";

	for (i= expr_list.iterator(); i.hasNext(); ) {
	    Expression expr = (Expression) i.next();
	    res = res + ".put(" + expr.getJavaCode() + ")";
	}
	
	return evalField.getJavaCodeForConvert(getReturnField(), res);
    }

    public String getLatexCode() {
	Iterator i;
	String res = "";

	res = "{";
	for (i= expr_list.iterator(); i.hasNext(); ) {
	    Expression expr = (Expression) i.next();
	    res = res + expr.getLatexCode();
	    if (i.hasNext())
		res = res + ", ";
	}
	res = res + "}";

	return res;
    }

    public void setDefaultField(Field field) {
	evalField = getReturnField().convert(field);
	this.field = evalField;
	
	for (Iterator i= expr_list.iterator(); i.hasNext(); ) {
	    Expression expr = (Expression) i.next();
	    expr.setDefaultField(this.field.getPolyCoefField());
	}
    }

    public int getSize() {
	return expr_list.size();
    }

    public String toString() {
	Iterator i;
	String res = "";

	res = "{";
	for (i= expr_list.iterator(); i.hasNext(); ) {
	    Expression expr = (Expression) i.next();
	    res = res + expr;
	    if (i.hasNext())
		res = res + ", ";
	}
	res = res + "}";

	return res;
    }
}
