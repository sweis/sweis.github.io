package cpl;

import java.util.*;

public class MemberFunction implements Function {
    
    private String name;
    private int minArgs, maxArgs;
    
    private String javaCall;
    private String latexCall;

    private Field returnField;
    
    public MemberFunction(Field returnField, String name, int nArgs,
                          String javaCall, String latexCall) {
	this(returnField, name, nArgs, nArgs, javaCall, latexCall);

    }

    public MemberFunction(Field returnField, String name, int minArgs, int maxArgs, String javaCall, String latexCall) {
	
	if (minArgs < 1) throw new InternalError("Member functions should have at least 1 argument");

        this.returnField = returnField;
	this.name= name;
	this.minArgs= minArgs;
	this.maxArgs= maxArgs;
	this.javaCall= javaCall;
	this.latexCall= latexCall;
    }

    public String getName() {
	return name;
    }

    public Field getReturnField() {
        return returnField;
    }

    public boolean argsSuitable(Vector args) {
	return args.size() >= minArgs && (maxArgs == -1 || args.size() <= maxArgs);
    }

    public String getJavaCodeForCall(Vector args) {

	Iterator i= args.iterator();
	String code= (String) i.next();

	// stackable?
	if (minArgs == 2 && maxArgs == -1) {
	    // special case, assume stackable
	    while(i.hasNext()) {
		code= code + "." + javaCall + "(" + (String) i.next() + ")";
	    }
	    
	} else {
	    code= code + "." + javaCall + "(";

	    while (i.hasNext()) {
		code = code + (String) i.next();
		if (i.hasNext()) {
		    code= code + ", ";
		}
	    }
	}

	return code;
    }

    public String getLatexCodeForCall(Vector args) {
	Iterator i= args.iterator();


	String code= latexCall + "\\left("; 

	    while (i.hasNext()) {
		code= code + (String) i.next();
		if (i.hasNext()) {
		    code = code + ", ";
		}
	    }
	
	return code + "\\right)";
    }

    public Field getArgField(int arg) {
	return Field.getZ();
    }
}
