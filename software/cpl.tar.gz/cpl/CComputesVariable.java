package cpl;

public class CComputesVariable extends CodeElement {
    public Variable variable;
    public Expression value;

    public CComputesVariable(Variable variable, Expression value) {
	super(COMPUTESVARIABLE);
	this.variable = variable;
	this.value = value;
    }

    public String toString() {
	return "computes " + variable + " := " + value;
    }
}
