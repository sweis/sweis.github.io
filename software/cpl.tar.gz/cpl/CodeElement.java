/*
  A class that represents one basic code element, such as a simple computation, assignment, etc.

  It should contain all data about types, etc.
*/

package cpl;

public abstract class CodeElement {
    Party party;

    // types of code elements
    public final static int SELECTS= 0;
    public final static int COMPUTESVARIABLE= 1;
    public final static int SENDS= 2;
    public final static int RECEIVES= 3;
    public final static int TESTS= 4;
    public final static int RETURNS= 5;
    public final static int ASSERT= 6;
    public final static int DEFAULTS= 7;
    public final static int FOR= 8;
    public final static int COMPUTESPOLYREF= 9;
    public final static int COMPUTESPOLYVAR= 10;
    //    public final static int DEFINES= 10;

    public int type;

    public CodeElement(int type) {
	this.type = type;
	this.party = null;
    }

}
