package cpl;

public class CComputesPolyRef extends CodeElement {
    public Variable poly;
    public PolyIndex index;
    public Expression value;

    public CComputesPolyRef(Variable poly, PolyIndex index, Expression value) {
	super(COMPUTESPOLYREF);
	this.poly = poly;
	this.index = index;
	this.value = value;
    }

    public String toString() {
	return "computes " + poly + "[" + index + "] := " + value;
    }
}
