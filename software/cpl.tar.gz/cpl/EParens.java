package cpl;

public class EParens extends Expression {
    public Expression arg;

    public EParens(Expression arg) {
	super(PARENS);
	this.arg= arg;
    }
    
    public Field getReturnField() {
        return arg.getReturnField();
    }

    public String getJavaCode() {
        return "(" + arg.getJavaCode() + ")";
    }
    
    public String getLatexCode() {
	return "\\left(" + arg.getLatexCode() + "\\right)";
    }

    public String toString() {
	return "(" + arg +")";
    }

    public void setDefaultField(Field field) {
	arg.setDefaultField(field);
    }

}
