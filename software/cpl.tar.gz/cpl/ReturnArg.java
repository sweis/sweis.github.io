package cpl;

public class ReturnArg {
    public Variable var;
    public Expression value;

    public ReturnArg(Variable var) {
	this.var = var;
	this.value = null;
    }

    public ReturnArg(Expression value, Variable var) {
	this.var = var;
	this.value = value;
    }
}
