/*
  Simple expression consisting only of a variable.
*/

package cpl;

public class EPolyVar extends Expression
{
    public Variable poly;
    public Expression index;

    private Field evalField = null;

    public EPolyVar(Variable poly, Expression index) {
	super(POLYVAR);
	this.poly= poly;
	this.index= index;
    }

    public Field getReturnField() {
	return poly.field.getPolyCoefField();
    }

    public String getJavaCode() {
	return evalField.getJavaCodeForConvert(getReturnField(), poly.getJavaName() + ".get(" + index.getJavaCode() + ")");
    }

    public String getLatexCode() {
	return poly.name + "_{" + index.getLatexCode() + "}";
    }

    public String getLatexDefaultCode() {
	return poly.name;
    }
    
    public String toString() {
	return poly.name;
    }

    public void setDefaultField(Field field) {
	evalField = getReturnField().convert(field);
    }
}
