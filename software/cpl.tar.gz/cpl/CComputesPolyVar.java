package cpl;

public class CComputesPolyVar extends CodeElement {
    public Variable poly;
    public Expression index;
    public Expression value;

    public CComputesPolyVar(Variable poly, Expression index, Expression value) {
	super(COMPUTESPOLYVAR);
	this.poly = poly;
	this.index = index;
	this.value = value;
    }

    public String toString() {
	return "computes " + poly + "[" + index + "] := " + value;
    }
}
