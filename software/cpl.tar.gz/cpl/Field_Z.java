package cpl;

/* The Field_Z class represents a field. By default, the var type is BigInteger,
   and the operations are those in Z. This is to make writing new fields easier 

   (for ex. ZMOD overwrites only a limited set of the operations)
*/

import java.math.*;

public class Field_Z extends Field {

    public Field_Z() {
	super(Z);
    }

    /* hackish constructor for fields that inherit from this */
    protected Field_Z(int type) {
        super(type);
    }

    public String getJavaCodeForSelect(String arg) {
	throw new RuntimeException("Select in Z is not allowed");
    }

    public String getJavaCodeForConstant(String constant) {
	return getJavaType() + ".get(\"" + constant + "\")";
    }

    public String getJavaType() {
        return "CPLZ";
    }

    public String getJavaConstructor() {
	return "new " + getJavaType() + "()";
    }

    public String getJavaCodeForConvert(Field from, String arg) {
	switch(from.type) {
	case Z:
	case BITSTRING:
	case ZMOD:
	    return arg;
	case INTEGER:
	    return getJavaType() + ".get(" + arg + ")";
	}
	throw new RuntimeException("This should never happen: Field_Z.getJavaCodeForConvert");
    }

    public String getLatexCodeForConstant(String constant) {
	return constant;
    }

    public String getLatexCodeForSelect() {
	throw new RuntimeException("FIXME: select in Z not supported");
    }

    public Field convert(Field field) {
	if (field == null)
	    return this;
	
	switch (field.type) {
	case Z:
	case BITSTRING:
	case ZMOD:
	    return field;
	default:
	    throw new RuntimeException("Cannot convert from field " + this + " to field " + field);
	}
    }

    public boolean isJavaPrimitiveType() {
	return false;
    }

    public String toString() {
	return "Z";
    }
}
