package cpl;

public class Field_PolyZMod extends Field_PolyZ {
    Variable mod;

    public Field_PolyZMod(Variable mod) {
	super(POLYZMOD);
	this.mod= mod;
    }

    /*
    public String getJavaCodeForUnary(UOperation unary_op, String arg) {
	String r = unary_op.getJavaCode(arg);

	return getJavaType() + "." + r.substring(0, r.length()-1) + "," + mod.getJavaName() + ")";
	return getJavaType() + "." + unary_op.getJavaCode(arg);
    }

    public String getLatexCodeForSelect() {
	return "\\in \\mathbb{Z}_{" + mod.getLatexName() + "}";
    }
    */

    public boolean equals(Object obj) {
        return obj instanceof Field &&
            ((Field) obj).type == POLYZMOD &&
            ((Field_PolyZMod)obj).mod.equals(mod);
    }

    public String getJavaType() {
	return "CPLPolyZMod";
    }

    public String getJavaConstructor() {
	return "new " + getJavaType() + "(" + mod.getJavaName() + ")";
    }

    public String toString() {
	return "poly(" + mod + ")";
    }

    public String getJavaCodeForConvert(Field from, String arg) {
	if (from.equals(this))
	    return arg;

	switch(from.type) {
	case POLYZ:
	case POLYZMOD:
	    return arg + ".mod(" + mod.name + ")";
	}
	throw new RuntimeException("This should never happen: Field_PolyZMod.getJavaCodeForConvert");
    }


}
