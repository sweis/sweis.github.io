package cpl;

import java.util.*;

public final class KnownFunctions {
    private static Map functions= new HashMap();

    static {
	addKnownFunctions();
    }
    
    private static void addKnownFunctions() {
	/*	
	// isPrime
	addFunction(new Function() {
		public String getName() {
		    return "prime";
		}
		
                public Field getReturnField() {
                    return Field.getBoolean();
                }
		
		public boolean argsSuitable(Vector args) {
		    return args.size() == 1 && ((Expression)args.elementAt(0)).getReturnField.isBigNumber();
		}
		
		public String getJavaCodeForCall(Vector args) {
		    return args.elementAt(0) + ".isProbablePrime(100)"; 
		}
		
		public String getLatexCodeForCall(Vector args) {
		    return "IsPrime \\left(" + args.elementAt(0) + "\\right)";
		}
		
		
		
		public Field getArgField(int arg) {
		    return Field.getZ();
		}
	    });
	*/
	
	// FIXME: getLatexCodeForCall fix for MemberFunction
	
	// gcd, stackable
	addFunction(new MemberFunction(Field.getZ(), "gcd", 2, -1, "gcd", ""));
	
	// modInv, non-stackable
	Vector modinv_params = new Vector();
	modinv_params.add(Field.getZ());
	addFunction(new ExternalFunction("modinv", Field.getZ(), modinv_params,
					 "CPLZMod.modInverse"));

	Vector prime_params = new Vector();
	prime_params.add(Field.getInteger());
	addFunction(new ExternalFunction("prime", Field.getZ(), 
					 prime_params, "CPLZ.getPrime"));
    
	Vector hash_params = new Vector();
	hash_params.add(Field.getZ());

	addFunction(new ExternalFunction("hash", Field.getZ(), hash_params, "CPLZ.hash"));

	addFunction(new ExternalFunction("H", Field.getZ(), hash_params, "CPLZ.hash"));

	addFunction(new ExternalFunction("G", Field.getZ(), hash_params, "CPLZ.hash"));
	
	Vector time_params = new Vector();
	
	addFunction(new ExternalFunction("time", Field.getZ(), time_params, "CPLZ.time"));
    }

    private static void addFunction(Function f) {
	functions.put(f.getName(), f);
    }

    public static Function getFunction(String name) {
	return (Function) functions.get(name);
    }
}

