package cpl;

public class Field_BitString extends Field_Z {
    public String length;

    public Field_BitString(String length) {
        super(BITSTRING);
        this.length= new String(length);
    }

    /*
      Operations are the same as Field (i.e. Z) ...
      ... except:
    */

    public Field getFieldForVariable(){
        return Field.getZ();
    }

    public String getJavaCodeForSelect(String arg) {
	return arg + ".select(" + length + ")";
	//	throw new RuntimeException("Select in Z is not allowed");
    }

    public String getJavaCodeForSelect() {
	return getJavaType() + ".select(" + length + ")";
    }

    public String getLatexCodeForSelect() {
	if (length.equals("1"))
	    return "\\in \\{0,1\\}";
	else
	    return "\\in \\{0,1\\}^{" + length + "}";
    }

    public boolean equals(Object obj) {
        return obj instanceof Field &&
            ((Field)obj).type == BITSTRING &&
            ((Field_BitString) obj).length.equals(length);
    }

    public String toString() {
        return "2^" + length;
    }

}
