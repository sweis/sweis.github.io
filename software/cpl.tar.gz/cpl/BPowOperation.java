package cpl;

public class BPowOperation extends BOperation {
    public String getSymbol() {
	return "^";
    }

    public String getJavaCode(Field field, String left, String right) {
	return field.getJavaType() + ".pow(" + left + "," + right + ")";
    }

    public String getLatexCode(String left, String right) {
	if (left.indexOf('_') > 0)
	    return "\\left("+left + "\\right)^{" + right + "}";
	else
	    return left + "^{" + right + "}";		
    }

    public Field[] getFields(Field field, Field left, Field right) {
	Field[] res = new Field[2];

	if (field.isZ()) {
	    if (left.isZ() || left.isInteger())
		res[0] = Field.getZ();
	    else if (left.isZMod())
		res[0] = left;
	    else {
		System.out.println("C1: " + field + ":" + left + "," + right);
		return null;
	    }
	    if (right.isInteger())
		res[1] = Field.getInteger();
	    else if (right.isZMod()) // SW?
		res[1] = right; // SW?
	    else {
		System.out.println("C2: " + field + ":" + left + "," + right);
		return null;
	    }

	    return res;
	}

	if (field.isZMod()) {
	    if (left.isNumber())
		res[0] = field;
	    else {
		System.out.println("C3: " + field + ":" + left + "," + right);
		return null;
	    }
	    
	    if (right.isNumber())
		res[1] = field;
	    else {
		System.out.println("C4: " + field + ":" + left + "," + right);
		return null;
	    }
	    return res;
	}

	if (field.isPolyZ()) {
	    if (left.isPoly())
		res[0] = left;
	    else
		return null;

	    if (right.isInteger())
		res[1] = Field.getInteger();
	    else
		return null;

	    return res;
	}

	if (field.isPolyZMod()) {
	    if (left.isPoly())
		res[0] = field;
	    else
		return null;

	    if (right.isNumber())
		res[1] = field.getPolyCoefField();
	    else
		return null;

	    return res;
	}

	throw new RuntimeException("Can't do operation " + this + " in field " + field);
    }

    public Field getReturnField(Field left, Field right) {
	if (left.isInteger() || left.isZ()) {
	    if (right.isInteger() || right.isZ() || right.isZMod())
		return Field.getZ();
	}

	System.out.println(left + ","+ right);
	if (left.isZMod()) {
	    if (right.isNumber())
		return left;
	}

	if (left.isPolyZ()) {
	    if (right.isInteger())
		return Field.getZ();
	}

	if (left.isPolyZMod()) {
	    if (right.isZMod() && left.getMod().equals(right.getMod()))
		return left;
	    if (right.isInteger())
		return Field.getPolyZ();
	}
	
	throw new RuntimeException("Can't do operation " + this + " between fields " + left + " and " + right);
    }

}
