package cpl;

public class EFieldSpec extends Expression {
    
    public Expression arg;
    public Field field;

    protected Field returnField = null;

    public EFieldSpec(Expression arg, Field field) {
	super(FIELD_SPEC);
	this.arg= arg;
	this.field= field;
	
	arg.setDefaultField(this.field);
    }

    public Field getReturnField() {
	return field;
    }

    public String getJavaCode() {
	return arg.getJavaCode();
    }

    public String getLatexCode() {
	return arg.getLatexCode();
    }

    public String toString() {
        return arg + " (in " + field + ")";
    }

    public void setDefaultField(Field field) {

    }

}
