/*
  This class represents a constant of a certain field;
*/

package cpl;

public class EConstant extends Expression {

    /*
      An object that represents the constant.
      Could even be a string.
    */
    public String constant;

    /* this is somewhat redundant, since it should *always* be
       aliased to returnType and evaluateIn.
       But I think this adds clarity to the code.
    */
    public Field field;

    private Field evalField = null;

    public EConstant(String constant, Field field) {
	super(CONSTANT);
	this.constant = constant;
        this.field = field;
    }

    public Field getReturnField() {
        return field;
    }

    public String getJavaCode() {
	return evalField.getJavaCodeForConstant(constant);
    }

    public String getLatexCode() {
	return evalField.getLatexCodeForConstant(constant);
    }

    public String toString() {
	return constant;
    }

    public void setDefaultField(Field field) {
	evalField = getReturnField().convert(field);
    }
}
