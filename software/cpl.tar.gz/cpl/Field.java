package cpl;

/*
  The Field class represents a field (numeric or non-numeric).
   It must provide the following:
     - the Java class that represents the field
     - Java code converting to / from another field
     - Java code for doing different types of operations

*/

import java.util.*;

public abstract class Field {

    public int type;

    public final static int Z = 0;
    public final static int ZMOD = 1;
    public final static int BITSTRING = 2;
    public final static int BOOLEAN = 3;
    public final static int INTEGER = 4;
    public final static int POLYZ = 5;
    public final static int POLYZMOD = 6;
     
    public Field(int type) {
	this.type= type;
    }

    /*
      This returns the Field in which a variable selected in this field should
      be counted. Should generally return this, but there are exceptions,
      most notably BitString. Conceptually, the field has some property that
      counts only for selection; after that, it should be considered the same
      as another, more general field. In the case of BitString, this is the
      specified bit length.
    */
    public Field getFieldForVariable() {
        return this;
    }

    /*
      This should return the Java code for obtaining the specified constant.
    */
    public abstract String getJavaCodeForConstant(String constant);

    //    public abstract String getJavaCodeForConstant(String constant);

    /*
      Returns Java code for carrying out the specified unary operation
    */
    public String getJavaCodeForUnary(UOperation unary_op, String arg) {
	return unary_op.getJavaCode(this, arg);
    }

    /*
      Returns Java code for carrying out the specified binary operation
    */
    public String getJavaCodeForBinary(BOperation binary_op, String left, String right) {
	return binary_op.getJavaCode(this, left, right);
    }


    /*
      Returns Java code for randomly selecting the specified argument in this
      field.
    */
    public abstract String getJavaCodeForSelect(String arg);

    /*
      Returns the Java type corresponding to this field.
    */
    public abstract String getJavaType();

    /*
      Returns the Java code for the constructor
    */
    public abstract String getJavaConstructor();

    /*
      Returns the code to convert *from* a specific field
    */
    public abstract String getJavaCodeForConvert(Field from, String arg);

    /*
      This should return the Latex code for obtaining the specified constant.
    */
    public abstract String getLatexCodeForConstant(String constant);

    /*
      Returns Latex code for carrying out the specified unary operation
    */
    public String getLatexCodeForUnary(UOperation unary_op, String arg) {
	return unary_op.getLatexCode(arg);
    }

    /*
      Returns Latex code for carrying out the specified binary operation
    */
    public String getLatexCodeForBinary(BOperation binary_op, String left, String right) {
	return binary_op.getLatexCode(left, right);
    }

    /*
      Returns Latex code for randomly selecting the specified argument in this
      field.
    */
    public abstract String getLatexCodeForSelect();
    
    /*
      Tries to convert to another field and returns the converted field
    */
    abstract public Field convert(Field field);

    /*
      Return true if the field is represented in Java as a simple primitive
      type
    */
    abstract public boolean isJavaPrimitiveType();

    /*
      Standard equals primitive. Default implementation: check whether
      the two fields are of the same type. Parameterized fields should
      override this.
    */

    public boolean equals(Object obj) {
        return obj instanceof Field &&
            ((Field) obj).type == this.type;
    }
    
    public abstract String toString();

    public boolean isZMod() {
	return (type == ZMOD);
    }

    public boolean isInteger() {
	return type == INTEGER;
    }

    public boolean isZ() {
	return (type == Z) || (type == BITSTRING);
    }

    public boolean isNumber() {
	return (type == Z) || (type == BITSTRING) || (type == ZMOD) || (type == INTEGER);
    }

    public boolean isBigNumber() {
	return (type == Z) || (type == BITSTRING) || (type == ZMOD);
    }

    public boolean isNumNotZMOD() {
	return (type == Z) || (type == BITSTRING) || (type == INTEGER);
    }

    public boolean isPoly() {
	return (type == POLYZ) || (type == POLYZMOD);
    }

    public boolean isPolyZ() {
	return (type == POLYZ);
    }

    public boolean isPolyZMod() {
	return (type == POLYZMOD);
    }

    public boolean isMod() {
	return (type == POLYZMOD) || (type == ZMOD);
    }

    public boolean isBoolean() {
	return (type == BOOLEAN);
    }

    public Variable getMod() {
	switch (type) {
	case ZMOD:
	    return ((Field_ZMod)this).mod;
	case POLYZMOD:
	    return ((Field_PolyZMod)this).mod;
	default:
	    throw new InternalError("Cannot getMod() from field " + this);
	}
    }

    static private Field_Z fieldz_instance;
    static private Field_Integer fieldinteger_instance;
    static private Field_Boolean fieldboolean_instance;
    static private Field_PolyZ fieldpolyz_instance;
    static private TreeMap fieldzmods;
    static private TreeMap fieldpolyzmods;

    static {
	fieldz_instance = new Field_Z();
	fieldinteger_instance = new Field_Integer();
	fieldboolean_instance = new Field_Boolean();
	fieldpolyz_instance = new Field_PolyZ();
	fieldzmods = new TreeMap();
	fieldpolyzmods = new TreeMap();
    }

    static Field_Z getZ() {
	return fieldz_instance;
    }

    static Field_Integer getInteger() {
	return fieldinteger_instance;
    }

    static Field_Boolean getBoolean() {
	return fieldboolean_instance;
    }

    static Field_PolyZ getPolyZ() {
	return fieldpolyz_instance;
    }

    // cached fields
    static Field_PolyZMod getPolyZMod(Variable mod) {
	Field_PolyZMod f = (Field_PolyZMod)fieldpolyzmods.get(mod.name);
	if (f == null) {
	    f = new Field_PolyZMod(mod);
	    fieldpolyzmods.put(mod.name, f);
	}
	return f;
    }

    // cached fields
    static Field_ZMod getZMod(Variable mod) {
	if (mod.field.type != Z && 
	    mod.field.type != BITSTRING && 
	    mod.field.type != ZMOD)
	    throw new RuntimeException("Only variables of fields Z and ZMod are allowed for modulos");

	Field_ZMod f = (Field_ZMod)fieldzmods.get(mod.name);
	if (f == null) {
	    f = new Field_ZMod(mod);
	    fieldzmods.put(mod.name, f);
	}
	return f;
    }

    static Field getPoly(Field field) {
	switch (field.type) {
	case Z:
	case BITSTRING:
	case INTEGER:
	    return getPolyZ();

	case ZMOD:
	    return getPolyZMod(((Field_ZMod)field).mod);
	default:
	    throw new RuntimeException("Cannot get polynomial in field " + field);
	}
    }

    public static Field_BitString getBitString(String length) {
        return new Field_BitString(length);
    }

    public  Field getPolyCoefField() {
	switch (type) {
	case POLYZ:
	    return getZ();
	case POLYZMOD:
	    return getZMod(((Field_PolyZMod)this).mod);
	default:
	    throw new RuntimeException("getPolyCoefField: field " + this + " is not a polynomial");
	}
    }

}
