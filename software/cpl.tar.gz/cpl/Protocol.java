package cpl;

import java.util.*;

public class Protocol {

    public String name;

    public Vector parties= new Vector();

    public Vector multiparties= new Vector();

    public Vector parameters= new Vector();

    public Expression assert;
    
    public boolean valid= true;

    public Vector codeElements= new Vector();

    public JavaConfiguration javaConf;
    
    public LatexConfiguration latexConf;

    public Protocol(JavaConfiguration javaConf, LatexConfiguration latexConf) {
	this.javaConf = javaConf;
	this.latexConf = latexConf;
    }

    public Party getParty(String name) {
	for (Iterator i= parties.iterator(); i.hasNext();)  {
	    Party p= (Party) i.next();

	    if (p.name.equals(name))
		return p;
	}
	
	return null;
    }

    public MultiParty getMultiParty(String name) {
	for (Iterator i= multiparties.iterator(); i.hasNext();)  {
	    MultiParty p= (MultiParty) i.next();

	    if (p.name.equals(name))
		return p;
	}
	
	return null;
    }

    public Party createParty(String name) {
	if (getParty(name) != null || getMultiParty(name) != null)
	    throw new RuntimeException("Party " + name + " has already been declared");
	Party p = new Party(name, this);
	parties.add(p);

	return p;
    }

    public MultiParty createMultiParty(String name, Expression count) {
	if (getParty(name) != null || getMultiParty(name) != null)
	    throw new RuntimeException("Party " + name + " has already been declared");

	MultiParty p = new MultiParty(name, count, this);
	multiparties.add(p);

	return p;
    }


    public void setName(String name) {
        this.name = name;
    }

    public void setParameters(Vector params) {
        for (Iterator i = params.iterator(); i.hasNext(); ) {
	    Vector v = (Vector) i.next();
            addParameter((String)v.elementAt(0), (Field)v.elementAt(1));
        }
    }

    public void addParameter(String name, Field field) {
        if (getParameter(name) != null)
            throw new RuntimeException("Duplicate protocol parameter found: " + name);

        parameters.add(new Variable(name, field, this));

    }

    /* returns null if not found */
    public Variable getParameter(String name) {

	for (Iterator i= parameters.iterator(); i.hasNext(); ) {
	    Variable v= (Variable) i.next();
	    
	    if (v.name.equals(name)) return v;
	}

	return null;
    }

    public void setAssert(Expression assert) {
	this.assert = assert;
    }

    public String toString() {
	Variable v;
	String params_str = "[";
	Iterator i;

	for (i = parameters.iterator(); i.hasNext(); ) {
	    v = (Variable)i.next();
	    params_str = params_str + v.name;
	    if (i.hasNext())
		params_str = params_str + " ";
	}
	params_str = params_str + "]";

	String s= "Protocol: "+name + "\n"
	    + "  " + (parties.size() + multiparties.size()) + " parties\n"
	    + "  " + parameters.size() + " parameters: " + params_str +"\n";

	for (i= parties.iterator(); i.hasNext(); ) {
	    s= s + i.next();
	}

	for (i= multiparties.iterator(); i.hasNext(); ) {
	    s= s + i.next();
	}

	return s;
	
    }

    public Function getFunction(String name) {
	Function f= KnownFunctions.getFunction(name);

	if (f != null)
	    return f;

	if (javaConf != null) {
	    f = javaConf.getFunction(name);
	    if (f != null)
		return f;
	}

	throw new RuntimeException("Unknown function: " + name);
    }
    
}
