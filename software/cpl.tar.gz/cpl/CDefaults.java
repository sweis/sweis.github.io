package cpl;

public class CDefaults extends CodeElement {

    public Field field;

    public CDefaults(Field field) {
	super(DEFAULTS);
	this.field= field;
    }
}
