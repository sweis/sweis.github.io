package cpl;

import java.util.Vector;

public class CSelects extends CodeElement {
    public Vector typed_var_list;
    public Expression test;

    public CSelects(Vector typed_var_list) {
        this(typed_var_list, null);
    }

    public CSelects(Vector typed_var_list, Expression test)
    {
	super(SELECTS);
        this.typed_var_list = typed_var_list;
        this.test= test;
    }
}
