package cpl;

public class Variable {
    public int type;
    public String name;
    public Field field;
    private Protocol protocol;

    public Variable(String name, Field field, Protocol protocol) {
	this.protocol = protocol;
	this.name = name;
	this.field = field;
    }

    public String getJavaName() {
	if (protocol.javaConf != null) {
	    String res = protocol.javaConf.getMapName(name);
	    
	    if (res != null)
		return res;
	}
	return name;
    }

    public Field getField() {
	return this.field;
    }

    public String getLatexName() {
	String res = protocol.latexConf.getMapName(name);
	if (res != null)
	    return res;

	res = "";
	String t = "";

	for (int i=0; i<name.length(); i++) {
	    char c = name.charAt(i);
	    res = res + c;
	    if (c == '_') {
		res = res + "{";
		t = t + "}";
	    }
	}
	res = res + t;

    	return res;
    }

    public String toString() {
	return name;
    }
    
}
