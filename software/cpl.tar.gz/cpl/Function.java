/*
  
  This class represents a function recognizable by the protocol.
  
  The class KnownFunction contains a repository of the currently
    known Functions.

 */


package cpl;

import java.util.*;

public interface Function { 
    public String getName();

    // args is vector of expressions
    public boolean argsSuitable(Vector args);

    /* args is vector of strings
       the strings are generated from a vector of expressions that
       have previously passed argsSuitable */
    public String getJavaCodeForCall(Vector args);

    public String getLatexCodeForCall(Vector args);

    public Field getReturnField();

    public Field getArgField(int arg);
}
