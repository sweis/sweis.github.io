package cpl;

public class UMinusOperation extends UOperation {
    public Field getReturnField(Field arg) {
	switch (arg.type) {
	case Field.Z:
	case Field.BITSTRING:
	case Field.ZMOD: 
	case Field.INTEGER:
	case Field.POLYZ:
	case Field.POLYZMOD:
	    return arg;
	}

	return null;
    }
    
    public String getJavaCode(Field field, String arg) {
	switch (field.type) {
	case Field.INTEGER:
	    return "-" + arg;
	case Field.Z:
	case Field.BITSTRING:
	case Field.POLYZ:
	    return field.getJavaType() + ".neg(" + arg + ")";
	case Field.ZMOD:
	case Field.POLYZMOD:
	    return field.getJavaType() + ".neg(" + arg + "," + field.getMod().getJavaName() + ")";
	}
	return null;
    }

    public String getLatexCode(String arg) {
	return "-" + arg;
    }

    public String getSymbol() {
	return "-";
    }
}
