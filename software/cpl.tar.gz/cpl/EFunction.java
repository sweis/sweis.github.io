package cpl;

import java.util.*;

public class EFunction extends Expression {

    public Function function;

    public Vector args;

    private Field evalField = null;

    public EFunction(Function function, Vector args) {
	super(FUNCTION);

	if (!function.argsSuitable(args)) {
	    throw new RuntimeException("Invalid arguments for function "+function.getName());
	}

	this.function= function;
	this.args= args;
    }

    public Field getReturnField() {
	return function.getReturnField();
    }

    public String getJavaCode() {
        Vector argstrings= new Vector(); 
	int i;

        for (i = 0; i < args.size(); i++) {
	    Expression e = (Expression)args.elementAt(i);
	    Field f = function.getArgField(i);
            argstrings.add(e.getJavaCode());
        }

	return evalField.getJavaCodeForConvert(getReturnField(), function.getJavaCodeForCall(argstrings));
    }

    public String getLatexCode() {
        Vector argstrings= new Vector(); 
        for (Iterator i= args.iterator(); i.hasNext(); ) {
            argstrings.add(((Expression) i.next()).getLatexCode());
        }

        return function.getLatexCodeForCall(argstrings);
    }

    public String toString() {
	return function.getName() + "()";
    }

    public void setDefaultField(Field field) {
	evalField = getReturnField().convert(field);

	int n = 0;
        for (Iterator i= args.iterator(); i.hasNext(); n++) {
            ((Expression) i.next()).setDefaultField(function.getArgField(n));
	}

	//FIXME: args check
	
    }

}

