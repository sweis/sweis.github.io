package cpl;

public class EBOperation extends Expression {

    public BOperation op;
  
    public Expression left, right;

    private Field returnField = null;

    private Field evalField = null;

    public EBOperation(BOperation op, Expression left, Expression right) {
        super(B_OPERATION);
    
        this.op= op;
        this.left= left;
        this.right= right;
    }

    public Field getReturnField() {
	if (returnField == null)
	    returnField = op.getReturnField(left.getReturnField(), right.getReturnField());
	return returnField;
    }

    public String getJavaCode() {
	return op.getJavaCode(evalField, left.getJavaCode(), right.getJavaCode());
    }

    public String getLatexCode() {
	return op.getLatexCode(left.getLatexCode(), right.getLatexCode());
    }

    public String toString() {
        return "(" + left + ")" + op + "(" + right + ")";
    }

    public void setDefaultField(Field field) {
	evalField = getReturnField().convert(field);

	Field[] f;
	Field lf = left.getReturnField();
	Field rf = right.getReturnField();

	f = op.getFields(field, lf, rf);
	if (f == null) {
	    System.out.println(lf + " " + op.getSymbol() + " " + rf);
	    throw new InternalError("This should never happen: EBOperation.setDefaultField");
	}
	left.setDefaultField(f[0]);
	right.setDefaultField(f[1]);
	
    }
}
    
