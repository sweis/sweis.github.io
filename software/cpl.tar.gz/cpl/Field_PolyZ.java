package cpl;

import java.math.*;

public class Field_PolyZ extends Field {

    public Field_PolyZ() {
	super(POLYZ);
    }

    /* hackish constructor for fields that inherit from this */
    protected Field_PolyZ(int type) {
        super(type);
    }

    public String getJavaCodeForConstant(String constant) {
	throw new InternalError("This should never been called: Field_PolyZ.getJavaCodeForConstant");
    }

    public String getJavaCodeForSelect(String arg) {
	throw new RuntimeException("FIXME: select in Polynomials is not supported");
    }

    public String getLatexCodeForConstant(String constant) {
	throw new InternalError("This should never been called: Field_PolyZ.getLatexCodeForConstant");
    }

    public String getLatexCodeForSelect() {
	throw new RuntimeException("FIXME: select in Polynomials is not supported");
    }

    public String getJavaCodeForConvert(Field from, String arg) {
	switch(from.type) {
	case POLYZ:
	case POLYZMOD:
	    return arg;
	}
	throw new RuntimeException("This should never happen: Field_PolyZ.getJavaCodeForConvert");
    }

    public Field convert(Field field) {
	if (field == null)
	    return this;
	
	switch (field.type) {
	case POLYZ:
	case POLYZMOD:
	    return field;
	default:
	    throw new RuntimeException("Cannot convert from field " + this + " to field " + field);
	}
    }

    public String getJavaType() {
	return "CPLPolyZ";
    }

    public String getJavaConstructor() {
	return "new " + getJavaType() + "()";
    }

    public boolean isJavaPrimitiveType() {
	return false;
    }

    public String toString() {
	return "poly";
    }

}
