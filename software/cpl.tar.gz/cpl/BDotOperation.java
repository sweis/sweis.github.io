package cpl;

public class BDotOperation extends BOperation {
    public String getJavaCode(Field field, String left, String right) {
	if (!field.isZ())
	    throw new InternalError("Field should have been " + Field.getZ() + " and not "
				    + field + " : BDotOperation.getJavaCode()");
	return field.getJavaType() + ".dot(" + left + "," + right + ")";
    }

    public String getLatexCode(String left, String right) {
	return left + " . " + right;
    }
	
    public String getSymbol() {
	return ".";
    }

    public Field[] getFields(Field field, Field left, Field right) {
	Field[] res = new Field[2];

	if (field.isZ()) {
	    if (left.isZ() || left.isZMod())
		res[0] = Field.getZ();
	    else
		return null;

	    if (right.isZ() || right.isZMod())
		res[1] = Field.getZ();
	    else
		return null;

	    return res;
	}

	throw new RuntimeException("Can't do operation " + this + " in field " + field);
    }

    public Field getReturnField(Field left, Field right) {
	if (left.isZ() || left.isZMod())
	    if (right.isZ() || right.isZMod())
		return Field.getZ();

	throw new RuntimeException("Can't do operation " + this + " between fields " + left + " and " + right);
    }

}
