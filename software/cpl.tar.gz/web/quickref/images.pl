# LaTeX2HTML 99.2beta8 (1.46)
# Associate images original text with physical files.


$key = q/(x+1)*[frac{y_i}{-2}]^3bmodp;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="165" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="$ (x+1)*[\frac{y_i}{-2}]^3 \bmod p$">|; 

$key = q/n;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="$ n$">|; 

$key = q/mathbb{Z}_p;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="24" HEIGHT="32" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="$ \mathbb{Z}_p$">|; 

$key = q/x;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="$ x$">|; 

$key = q/nomath_inline}framebox{vbox{textbf{protocol}Exampleparameters(textit{g1,g2,...}))}textit{textbf{party}Bobtextit{(b1,b2,...)}}}}nomath_inline};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="579" HEIGHT="203" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\framebox{
\vbox{
\textbf{protocol} Example \\\\
parameters (\textit{g1,g2,...}) ...
...e \textit{(a1,a2,...)} \\\\
\textit{\textbf{party} Bob \textit{(b1,b2,...)}}
}
}">|; 

$key = q/nomath_inline}framebox{vbox{textbf{protocol}Example2parameters(n,p)textbf{party}turns}ztextbf{every}Player[i]textbf{returns}w}}nomath_inline};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="579" HEIGHT="636" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="\framebox{
\vbox{
\textbf{protocol} Example2 \\\\
parameters (n, p) \\\\
\textbf{p...
...Player[i] \textbf{returns} z \\\\
\textbf{every} Player[i] \textbf{returns} w
}
}">|; 

$key = q/i;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="10" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="$ i$">|; 

1;

