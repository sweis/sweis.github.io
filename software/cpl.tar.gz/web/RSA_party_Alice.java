/* This class was automatically generated from CPL code using cpl.GenerateJava */ 

import java.io.*;
import java.math.BigInteger;
import cpl.runtime.*;

public class RSA_party_Alice implements Runnable {

    /* global parameters */
    private CPLZ m;
    private CPLZ e;
    private CPLZ d;
    private CPLZ n;

    /* locals */
    private CPLZMod c;

    /* helper variable for for loops */
    int _$index_ = 0;

    /* communication channel(s) */
    private CommunicationChannel cc_to_Bob;

    /* constructor */
    public RSA_party_Alice(CPLZ m, CPLZ e, CPLZ d, CPLZ n, CommunicationChannel cc_to_Bob) {
        this.m = m;
        this.e = e;
        this.d = d;
        this.n = n;
        this.cc_to_Bob = cc_to_Bob;
        c = new CPLZMod(n);
    }

    /* main function */
    public void run() {
        c.set(CPLZMod.pow(m.mod(n),e.mod(n)));
        c.send(cc_to_Bob);
    }

    /* get function for result c */
    public CPLZMod getResult_c() {
        return c;
    }
}
