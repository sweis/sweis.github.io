/* This class was automatically generated from CPL code using cpl.GenerateJava */ 

import java.io.*;
import java.math.BigInteger;
import cpl.runtime.*;

public class SimpleDH_party_B implements Runnable {

    /* global parameters */
    private CPLZ p;
    private CPLZ g;

    /* locals */
    private CPLZMod y;
    private CPLZMod g_y;
    private CPLZMod g_x;
    private CPLZMod k;

    /* helper variable for for loops */
    int _$index_ = 0;

    /* communication channel(s) */
    private CommunicationChannel cc_to_A;

    /* constructor */
    public SimpleDH_party_B(CPLZ p, CPLZ g, CommunicationChannel cc_to_A) {
        this.p = p;
        this.g = g;
        this.cc_to_A = cc_to_A;
        y = new CPLZMod(p);
        g_y = new CPLZMod(p);
        g_x = new CPLZMod(p);
        k = new CPLZMod(p);
    }

    /* main function */
    public void run() {
        y.select();
        g_y.set(CPLZMod.pow(g.mod(p),y));
        g_x.receive(cc_to_A);
        g_y.send(cc_to_A);
        k.set(CPLZMod.pow(g_x,y));
    }

    /* get function for result k */
    public CPLZMod getResult_k() {
        return k;
    }
}
