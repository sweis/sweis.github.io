/* This class was automatically generated from CPL code using cpl.GenerateJava */ 

import java.io.*;
import java.math.BigInteger;
import cpl.runtime.*;

public class SimpleDH_party_A implements Runnable {

    /* global parameters */
    private CPLZ p;
    private CPLZ g;

    /* locals */
    private CPLZMod x;
    private CPLZMod g_x;
    private CPLZMod g_y;
    private CPLZMod k;

    /* helper variable for for loops */
    int _$index_ = 0;

    /* communication channel(s) */
    private CommunicationChannel cc_to_B;

    /* constructor */
    public SimpleDH_party_A(CPLZ p, CPLZ g, CommunicationChannel cc_to_B) {
        this.p = p;
        this.g = g;
        this.cc_to_B = cc_to_B;
        x = new CPLZMod(p);
        g_x = new CPLZMod(p);
        g_y = new CPLZMod(p);
        k = new CPLZMod(p);
    }

    /* main function */
    public void run() {
        x.select();
        g_x.set(CPLZMod.pow(g.mod(p),x));
        g_x.send(cc_to_B);
        g_y.receive(cc_to_B);
        k.set(CPLZMod.pow(g_y,x));
    }

    /* get function for result k */
    public CPLZMod getResult_k() {
        return k;
    }
}
