import cpl.runtime.*;
import java.util.*;

public class SecretShare_BoilerPlate{
    /* Protocol's SecretShare parameters */
    private CPLZ p;
    private int n;
    private int t;
    private CPLZ s;

    private void InitParameters(String[] args) {
        /* Protocol's SecretShare parameters */
        int i = 0;
        if (i < args.length)
            p = new CPLZ(args[i]);
        else
            p = null;
        i++;
        if (i < args.length)
            n = Integer.parseInt(args[i]);
        else
            n = 0;
        i++;
        if (i < args.length)
            t = Integer.parseInt(args[i]);
        else
            t = 0;
        i++;
        if (i < args.length)
            s = new CPLZ(args[i]);
        else
            s = null;
        i++;

    }

    public void run() throws Exception {
        /* Print parameters */
        System.out.println("Protocol SecretShare parameters");
        System.out.println("p = " + p);
        System.out.println("n = " + n);
        System.out.println("t = " + t);
        System.out.println("s = " + s);

        /* CommunicationChannels' construction */
        CC_Single_Multi cc_Dealer_Player = new CC_Single_Multi(n);

        /* Parties construction */
        SecretShare_party_Dealer Dealer = new SecretShare_party_Dealer(p, n, t, s, cc_Dealer_Player.getFirst());
        SecretShare_party_Player[] Player = new SecretShare_party_Player[n];
        for (int i=0; i<n; i++)
            Player[i] = new SecretShare_party_Player(p, n, t, s, i, cc_Dealer_Player.getSecond(i));

        /* Threads */
        Thread thread_Dealer = new Thread(Dealer);
        Thread[] thread_Player = new Thread[n];
        for (int i=0; i<n; i++)
            thread_Player[i] = new Thread(Player[i]);

        /* Start threads */
        thread_Dealer.start();
        for (int i=0; i<n; i++)
            thread_Player[i].start();

        /* Wait until all threads finish */
        try {
            thread_Dealer.join();
            for (int i=0; i<n; i++)
                thread_Player[i].join();
        }
        catch (Exception e) {
            e.printStackTrace(System.err);
            System.exit(1);
        }

        /* Print parties' results */
    }

    public static void main(String[] args) throws Exception {
        SecretShare_BoilerPlate boilerplate = new SecretShare_BoilerPlate();
        boilerplate.InitParameters(args);
        boilerplate.run();
    }
}
