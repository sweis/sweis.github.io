import cpl.runtime.*;
import java.util.*;

public class SimpleDH_BoilerPlate{
    /* Protocol's SimpleDH parameters */
    private CPLZ p;
    private CPLZ g;

    private void InitParameters(String[] args) {
        /* Protocol's SimpleDH parameters */
        int i = 0;
        if (i < args.length)
            p = new CPLZ(args[i]);
        else
            p = null;
        i++;
        if (i < args.length)
            g = new CPLZ(args[i]);
        else
            g = null;
        i++;

    }

    public void run() throws Exception {
        /* Print parameters */
        System.out.println("Protocol SimpleDH parameters");
        System.out.println("p = " + p);
        System.out.println("g = " + g);

        /* CommunicationChannels' construction */
        CC_Single_Single cc_A_B = new CC_Single_Single();

        /* Parties construction */
        SimpleDH_party_A A = new SimpleDH_party_A(p, g, cc_A_B.getFirst());
        SimpleDH_party_B B = new SimpleDH_party_B(p, g, cc_A_B.getSecond());
        /* Threads */
        Thread thread_A = new Thread(A);
        Thread thread_B = new Thread(B);

        /* Start threads */
        thread_A.start();
        thread_B.start();

        /* Wait until all threads finish */
        try {
            thread_A.join();
            thread_B.join();
        }
        catch (Exception e) {
            e.printStackTrace(System.err);
            System.exit(1);
        }

        /* Print parties' results */
        System.out.println("A results");
        System.out.println("k = " + A.getResult_k());
        System.out.println();

        System.out.println("B results");
        System.out.println("k = " + B.getResult_k());
        System.out.println();

    }

    public static void main(String[] args) throws Exception {
        SimpleDH_BoilerPlate boilerplate = new SimpleDH_BoilerPlate();
        boilerplate.InitParameters(args);
        boilerplate.run();
    }
}
