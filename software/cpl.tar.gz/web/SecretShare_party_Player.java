/* This class was automatically generated from CPL code using cpl.GenerateJava */ 

import java.io.*;
import java.math.BigInteger;
import cpl.runtime.*;

public class SecretShare_party_Player implements Runnable {

    /* global parameters */
    private CPLZ p;
    private int n;
    private int t;
    private CPLZ s;
    int _$ID_ = 0;

    /* locals */
    private CPLPolyZ k;

    /* helper variable for for loops */
    int _$index_ = 0;

    /* communication channel(s) */
    private CommunicationChannel cc_to_Dealer;

    /* constructor */
    public SecretShare_party_Player(CPLZ p, int n, int t, CPLZ s, int _$ID_, CommunicationChannel cc_to_Dealer) {
        this.p = p;
        this.n = n;
        this.t = t;
        this.s = s;
        this.cc_to_Dealer = cc_to_Dealer;
        this._$ID_ = _$ID_;
        k = new CPLPolyZ();
    }

    /* main function */
    public void run() {
        k.receive(cc_to_Dealer);
    }
}
