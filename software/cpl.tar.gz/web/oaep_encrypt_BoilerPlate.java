import cpl.runtime.*;
import java.util.*;

public class oaep_encrypt_BoilerPlate{
    /* Protocol's oaep_encrypt parameters */
    private CPLZ m;
    private CPLZ e;
    private CPLZ n;

    private void InitParameters(String[] args) {
        /* Protocol's oaep_encrypt parameters */
        int i = 0;
        if (i < args.length)
            m = new CPLZ(args[i]);
        else
            m = null;
        i++;
        if (i < args.length)
            e = new CPLZ(args[i]);
        else
            e = null;
        i++;
        if (i < args.length)
            n = new CPLZ(args[i]);
        else
            n = null;
        i++;

    }

    public void run() throws Exception {
        /* Print parameters */
        System.out.println("Protocol oaep_encrypt parameters");
        System.out.println("m = " + m);
        System.out.println("e = " + e);
        System.out.println("n = " + n);

        /* CommunicationChannels' construction */

        /* Parties construction */
        oaep_encrypt_party_Alice Alice = new oaep_encrypt_party_Alice(m, e, n);
        /* Threads */
        Thread thread_Alice = new Thread(Alice);

        /* Start threads */
        thread_Alice.start();

        /* Wait until all threads finish */
        try {
            thread_Alice.join();
        }
        catch (Exception e) {
            e.printStackTrace(System.err);
            System.exit(1);
        }

        /* Print parties' results */
        System.out.println("Alice results");
        System.out.println("c = " + Alice.getResult_c());
        System.out.println();

    }

    public static void main(String[] args) throws Exception {
        oaep_encrypt_BoilerPlate boilerplate = new oaep_encrypt_BoilerPlate();
        boilerplate.InitParameters(args);
        boilerplate.run();
    }
}
