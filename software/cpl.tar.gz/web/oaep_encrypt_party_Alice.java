/* This class was automatically generated from CPL code using cpl.GenerateJava */ 

import java.io.*;
import java.math.BigInteger;
import cpl.runtime.*;

public class oaep_encrypt_party_Alice implements Runnable {

    /* global parameters */
    private CPLZ m;
    private CPLZ e;
    private CPLZ n;

    /* locals */
    private CPLZMod r;
    private CPLZ a;
    private CPLZ b;
    private CPLZ x;
    private CPLZMod c;

    /* helper variable for for loops */
    int _$index_ = 0;

    /* communication channel(s) */

    /* constructor */
    public oaep_encrypt_party_Alice(CPLZ m, CPLZ e, CPLZ n) {
        this.m = m;
        this.e = e;
        this.n = n;
        r = new CPLZMod(n);
        a = new CPLZ();
        b = new CPLZ();
        x = new CPLZ();
        c = new CPLZMod(n);
    }

    /* main function */
    public void run() {
        r.select();
        a.set(CPLZ.xor(m,CPLZ.hash(r)));
        b.set(CPLZ.xor(r,CPLZ.hash(a)));
        x.set(CPLZ.dot(a,b.mod(n)));
        c.set(CPLZMod.pow(x.mod(n),e.mod(n)));
    }

    /* get function for result c */
    public CPLZMod getResult_c() {
        return c;
    }
}
