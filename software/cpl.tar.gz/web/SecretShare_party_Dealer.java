/* This class was automatically generated from CPL code using cpl.GenerateJava */ 

import java.io.*;
import java.math.BigInteger;
import cpl.runtime.*;

public class SecretShare_party_Dealer implements Runnable {

    /* global parameters */
    private CPLZ p;
    private int n;
    private int t;
    private CPLZ s;

    /* locals */
    private CPLPolyZMod P;
    private int i;
    private CPLPolyZ k;

    /* helper variable for for loops */
    int _$index_ = 0;

    /* communication channel(s) */
    private CommunicationChannel[] cc_to_Player;

    /* constructor */
    public SecretShare_party_Dealer(CPLZ p, int n, int t, CPLZ s, CommunicationChannel[] cc_to_Player) {
        this.p = p;
        this.n = n;
        this.t = t;
        this.s = s;
        this.cc_to_Player = cc_to_Player;
        P = new CPLPolyZMod(p);
        i = 0;
        k = new CPLPolyZ();
    }

    /* main function */
    public void run() {
        P.select((new CPLIndex()).addRange(1, t));
        P.set(0, s.mod(p));
        for (i= 0; i <= n ; i++) {
            k.set(i, P.calc(CPLZ.add(CPLZ.get(i),CPLZ.get("1"))));
        }
        for (i=0; i<n; i++) {
            k.getPart((new CPLIndex()).addIndex(i)).send(cc_to_Player[i]);
        }
    }
}
