import cpl.runtime.*;
import java.util.*;

public class RSA_BoilerPlate{
    /* Protocol's RSA parameters */
    private CPLZ m;
    private CPLZ e;
    private CPLZ d;
    private CPLZ n;

    private void InitParameters(String[] args) {
        /* Protocol's RSA parameters */
        int i = 0;
        if (i < args.length)
            m = new CPLZ(args[i]);
        else
            m = null;
        i++;
        if (i < args.length)
            e = new CPLZ(args[i]);
        else
            e = null;
        i++;
        if (i < args.length)
            d = new CPLZ(args[i]);
        else
            d = null;
        i++;
        if (i < args.length)
            n = new CPLZ(args[i]);
        else
            n = null;
        i++;

    }

    public void run() throws Exception {
        /* Print parameters */
        System.out.println("Protocol RSA parameters");
        System.out.println("m = " + m);
        System.out.println("e = " + e);
        System.out.println("d = " + d);
        System.out.println("n = " + n);

        /* CommunicationChannels' construction */
        CC_Single_Single cc_Alice_Bob = new CC_Single_Single();

        /* Parties construction */
        RSA_party_Alice Alice = new RSA_party_Alice(m, e, d, n, cc_Alice_Bob.getFirst());
        RSA_party_Bob Bob = new RSA_party_Bob(m, e, d, n, cc_Alice_Bob.getSecond());
        /* Threads */
        Thread thread_Alice = new Thread(Alice);
        Thread thread_Bob = new Thread(Bob);

        /* Start threads */
        thread_Alice.start();
        thread_Bob.start();

        /* Wait until all threads finish */
        try {
            thread_Alice.join();
            thread_Bob.join();
        }
        catch (Exception e) {
            e.printStackTrace(System.err);
            System.exit(1);
        }

        /* Print parties' results */
        System.out.println("Alice results");
        System.out.println("c = " + Alice.getResult_c());
        System.out.println();

        System.out.println("Bob results");
        System.out.println("x = " + Bob.getResult_x());
        System.out.println();

    }

    public static void main(String[] args) throws Exception {
        RSA_BoilerPlate boilerplate = new RSA_BoilerPlate();
        boilerplate.InitParameters(args);
        boilerplate.run();
    }
}
