/* This class was automatically generated from CPL code using cpl.GenerateJava */ 

import java.io.*;
import java.math.BigInteger;
import cpl.runtime.*;

public class RSA_party_Bob implements Runnable {

    /* global parameters */
    private CPLZ m;
    private CPLZ e;
    private CPLZ d;
    private CPLZ n;

    /* locals */
    private CPLZMod c;
    private CPLZMod x;

    /* helper variable for for loops */
    int _$index_ = 0;

    /* communication channel(s) */
    private CommunicationChannel cc_to_Alice;

    /* constructor */
    public RSA_party_Bob(CPLZ m, CPLZ e, CPLZ d, CPLZ n, CommunicationChannel cc_to_Alice) {
        this.m = m;
        this.e = e;
        this.d = d;
        this.n = n;
        this.cc_to_Alice = cc_to_Alice;
        c = new CPLZMod(n);
        x = new CPLZMod(n);
    }

    /* main function */
    public void run() {
        c.receive(cc_to_Alice);
        x.set(CPLZMod.pow(c,d.mod(n)));
    }

    /* get function for result x */
    public CPLZMod getResult_x() {
        return x;
    }
}
