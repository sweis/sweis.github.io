#!/bin/sh
echo "----------"
echo "Diffe-Helman Test Case"
echo "Compiling from CPL to Java..."
./gjava-s examples/dh.cpl
echo "Compiling Java..."
javac SimpleDH*.java
echo "Running test..."
java SimpleDH_BoilerPlate 997 3
echo "----------"
echo "RSA Encryption Test Case"
echo "Compiling from CPL to Java..."
./gjava-s examples/rsa.cpl
echo "Compiling Java..."
javac RSA_*.java
echo "Running test..."
java RSA_BoilerPlate 688 79 1019 3337
echo "----------"
