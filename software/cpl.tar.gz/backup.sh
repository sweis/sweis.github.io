#!/bin/sh
tar cvfR web/backup.tar *
gzip web/backup.tar
