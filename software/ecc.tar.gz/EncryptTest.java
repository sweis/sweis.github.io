import java.security.*;
import javax.crypto.KeyAgreement;
import java.security.spec.*;
import java.util.Random;
import java.math.BigInteger;


import cryptix.provider.*;
import cryptix.provider.cipher.*;
import cryptix.provider.key.*;


class EncryptTest {
    public static void main(String[] args) {

	/* Dynamically Install dummy ECC Provider */
	ECDummyProvider.install();

	String provider = "ECC";
	KeyPairGenerator kpgen;
	KeyPair kp1, kp2, kp3;
	KeyAgreement ka;
	BigInteger v1, v2;
	byte[] value1, value2;

	try {
	    kpgen = 
		KeyPairGenerator.getInstance("ECDSA",provider);
	    
	    kpgen.initialize(160);

	    kp1 = kpgen.generateKeyPair();
	    kp2 = kpgen.generateKeyPair();

	    ka = KeyAgreement.getInstance("ECDH",provider);

	    ka.init(kp1.getPrivate());
	    ka.doPhase(kp2.getPublic(),true);
	    value1 = ka.generateSecret();

	    Cipher c = Cipher.getInstance("Blowfish", "Cryptix");

	    SecureRandom random = new SecureRandom(value1);
	    ExtendedKeyGenerator kgen = (ExtendedKeyGenerator) 
		KeyGenerator.getInstance ("Blowfish", "Cryptix");
	    
	    kgen.initialize (random);
	    Key key1 = kgen.generateKey ();


	    c.initEncrypt(key1);
	    
	    String message = "blah blah blah blah";
	    byte cleartext [] = 
		zero_pad (message.getBytes(), c.blockSize ());

	    byte[] ciphertext = c.doFinal(cleartext);

	    c.initDecrypt(key1);
	    byte[] plaintext = c.doFinal(ciphertext);
	    String out = new String(plaintext);
	    System.out.println(out);

	}
	
	catch (Exception e) {
	    e.printStackTrace();
            System.out.println(e.toString());
	}
    }

 protected static byte [] zero_pad (byte [] original, int block_size) {
    int orig_sz = original.length;
    byte [] result;

    if (orig_sz % block_size == 0) 
      result = original;
    else {
      int new_size = round_up (orig_sz, block_size);
      result = new byte [new_size];
      for (int i = 0; i < new_size; ++i) {
	if (i < orig_sz)
	  result[i] = original[i];
	else
	  result[i] = 0;
      }
    }

    return result;
  }

 protected static int round_up (int value, int multiple) {
    return (((value - 1) / multiple) + 1) * multiple;
  }

}



