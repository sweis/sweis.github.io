import java.util.Random;
import java.math.BigInteger;

import java.security.Signature;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.KeyPair;
import java.security.PublicKey;
import java.security.PrivateKey;

import java.security.ProviderException;
import java.security.SignatureException;
import java.security.InvalidKeyException;
import java.security.InvalidParameterException;

/**
 * Implementation of Elliptic Curve Signatures
 * 
 * <BR>
 * Signature and Verification Methods ontains code from 
 * Cryptix Elliptix Package:<BR>
 * <BR>
 * Copyright (C) 1995-2000 Systemics Ltd.<BR>
 * on behalf of the Cryptix Development Team. All rights reserved.<BR>
 * <BR>
 * Use, modification, copying and distribution of this software is subject to
 * the terms and conditions of the Cryptix General Licence. You should have 
 * received a copy of the Cryptix General License along with this library; 
 * if not, you can download a copy from http://www.cryptix.org/ . <BR>
 * <BR>
 * @author  Paulo S. L. M. Barreto (pbarreto@cryptix.org)  <BR>
 *          Modifications by Steve Weis (sweis@cs.berkeley.edu)
 */
public class ECSignature 
extends Signature {

// Constants and variables
//............................................................................

    public static final String COPYRIGHT = "Copyright &copy 1995-2000 Systemics Ltd. on behalf of the Cryptix Development Team. All rights reserved. ";

   public static final String UC_COPYRIGHT = "Copyright &copy 2000 The Regents of the University of California. All Rights Reserved. ";

    protected MessageDigest md;

    /**
     * A cryptographically secure source of randomness for this key-generator.
     */    
    private SecureRandom random;

    private ECPrivateKey secret = null;
    private ECPublicKey pub = null;

    private int algorithmType;

// Constructor
//............................................................................

    /**
     * Constructor for an ECSignature.
     *
     * @param  mdAlgorithm  the standard JCA algorithm name of the message
     *                      digest to be used.
     */
    protected ECSignature(String algorithm) { 
	super(algorithm);

	// Default to SHA-1/ECDSA
	String mdAlgorithm = "SHA-1";
	String ecAlgorithm = "ECDSA";
	
	/* 
	 * Attempt to parse the algorithm name, which is in the form of
	 * DIGEST/ALGORITHM. Valid digests are MD5 and SHA-1. 
	 * Valid Algorithms are ECDSA and ECNR
	 */
	if (algorithm.indexOf("/")!=-1){
	    mdAlgorithm = algorithm.substring(0,algorithm.indexOf("/"));
	    ecAlgorithm = algorithm.substring(algorithm.indexOf("/")+1,
					      algorithm.length());
	}
	
	try { 
	    this.md = MessageDigest.getInstance(mdAlgorithm); }
        catch (Exception e) {
            throw new ProviderException
		(getAlgorithm() +
		 ": Unable to instantiate the " + mdAlgorithm +
		 " MessageDigest\n" + e);
        }

	if (ecAlgorithm.equals("ECDSA"))
	    algorithmType = ECAlgorithm.ECDSA;
	else if (ecAlgorithm.equals("ECNR"))
	    algorithmType = ECAlgorithm.ECNR;
	else
            throw new ProviderException
		(getAlgorithm() +
		 ": Unable to instantiate the " + ecAlgorithm +
		 " Signature Algorithm\n");
    }

// Signature method implementation
//............................................................................

    /**
     * Initialize for signing with the given key
     *
     * @param priv      ECPrivate key for signing
     * @exception InvalidKeyException if !(key instanceof ECPrivateKey)
     */
    protected void engineInitSign(PrivateKey priv) 
	throws InvalidKeyException {
	if (! (priv instanceof ECPrivateKey))
	    throw new InvalidKeyException("Key is not an ECPrivateKey");
	
	secret = (ECPrivateKey)priv;
	
	/* Initialize random number generator */
	byte[] randSeed = new byte[20];
	(new Random()).nextBytes(randSeed);
	random = new SecureRandom(randSeed);
    }

    /**
     * Initialize for signing with the given key
     *
     * @param priv      ECPrivate key for signing
     * @param rand      SecureRandom psuedo-random number generator
     * @exception InvalidKeyException if !(key instanceof ECPrivateKey)
     */
    protected void engineInitSign(PrivateKey priv, SecureRandom rand) 	
	throws InvalidKeyException {	
	if (! (priv instanceof ECPrivateKey))
	    throw new InvalidKeyException("Key is not an ECPrivateKey");
	
	secret = (ECPrivateKey)priv;
	random = rand;
    }
       
    /**
     * Initialize for verification with the given key
     *
     * @param pub       ECPublic key for verification
     * @exception InvalidKeyException if !(key instanceof ECPublicKey)
     */
    protected void engineInitVerify(PublicKey pub) 
	throws InvalidKeyException {
	if (! (pub instanceof ECPublicKey))
	    throw new InvalidKeyException("Key is not an ECDSA key");

	this.pub = (ECPublicKey)pub;
    }

    /**
     * Update digest with bytes
     *
     * @param b  single byte      
     * @exception SignatureException if the engine is not initialised properly.
     */
    protected void engineUpdate(byte b) 
    throws SignatureException { 
	if (state != VERIFY && state != SIGN)
            throw new SignatureException(getAlgorithm() + ": Not initialized");
	md.update(b); 
    }          

    /**
     * Update digest with bytes
     *
     * @param data  array of bytes      
     * @exception SignatureException if the engine is not initialised properly.
     */
    protected void engineUpdate(byte[] data)    
	throws SignatureException { 
	if (state != VERIFY && state != SIGN)
            throw new SignatureException(getAlgorithm() + ": Not initialized");
 	md.update(data); 
    }

    /**
     * Update digest with bytes
     *
     * @param data  array of bytes
     * @param off   offset from start of array
     * @param len   length of array to add to digest
     */
    protected void engineUpdate(byte[] data, int off, int len) 
	throws SignatureException { 
	if (state != VERIFY && state != SIGN)
            throw new SignatureException(getAlgorithm() + ": Not initialized");
	    md.update(data,off,len);
    }


    /**
     * EC signature generation
     *
     * Supports both ECDSA and Nyberg-Rueppel signature generation:
     *
     * @return byte array representing the signature
     * @exception SignatureException if the engine is not initialised properly.
     */
    protected byte[] engineSign() 
	throws SignatureException {
	if (state != SIGN) throw new SignatureException
	    (getAlgorithm() + ": Not initialized for signing");
	
	ECurve E = secret.getCurve();
	BigInteger x = secret.getD();
	byte[] d = md.digest();		

	return ECAlgorithm.sign(E,x,d,random, ECAlgorithm.ECDSA);
    }    


    /**
     * Verify a signature.
     *
     * Supports both ECDSA and Nyberg-Rueppel signature verification:
     *
     * @return	true if the signature is valid, otherwise false.
     */
    protected boolean engineVerify(byte[] sig) throws SignatureException {
	if (state != VERIFY)
	    throw new 
		SignatureException("Public Key not initialized for verification.");
	ECurve E = pub.getCurve();
	EPoint Y = pub.getQ();
	byte[] d = md.digest();
	return ECAlgorithm.verify(E,Y,sig,d,random,ECAlgorithm.ECDSA);
    }    

// Unimplemented
//............................................................................
    
    protected Object engineGetParameter(String param) { return null; }

    protected void engineSetParameter(String param, Object value) { }
}












