import java.io.PrintWriter;
import java.io.PrintStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;
import java.security.*;

public class ECDummyProvider
extends Provider
{

// Constants
//...........................................................................

   public static final String UC_COPYRIGHT = "Copyright &copy 2000 The Regents of the University of California. All Rights Reserved. ";

    static final long serialVersionUID = 0xd81L;


// Constructor
//...........................................................................

    public ECDummyProvider() {
        super("ECC", getVersionAsDouble(),"blah");         // name, version
	put("Signature.SHA-1/ECDSA", "SHA1_ECDSA_Signature");
	put("Signature.SHA-1/ECNR", "SHA1_ECNR_Signature");
	put("Signature.MD5/ECDSA", "MD5_ECDSA_Signature");
	put("Signature.MD5/ECNR", "MD5_ECNR_Signature");
	put("KeyPairGenerator.ECDSA", "ECKeyPairGenerator");
	put("KeyPairGenerator.ECNR", "ECKeyPairGenerator");
	put("KeyAgreement.ECDH", "ECKeyAgreement");
    }

    private static double getVersionAsDouble() {
	return 1.0d;
    }

    public String toString() {
	return "ECC";
    }
    public static void install() {
	Provider temp = new ECDummyProvider();
	Security.addProvider(temp);
    }
}

