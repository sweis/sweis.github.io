import java.io.InputStream;
import java.math.BigInteger;
import java.security.SecureRandom;

/**
 * Implementation of Elliptic Curves over GF(p)
 *
 * @author  Paulo S. L. M. Barreto <pbarreto@cryptix.org>
 */
public class ECurve {

// Constants and variables
//............................................................................

    public static final String COPYRIGHT = "Copyright &copy 1995-2000 Systemics Ltd. on behalf of the Cryptix Development Team. All rights reserved. ";

    /**
     * Convenient BigInteger constants
     */
    protected static final BigInteger
        $0 = BigInteger.valueOf(0L),
        $1 = BigInteger.valueOf(1L),
        $3 = BigInteger.valueOf(3L),
        $5 = BigInteger.valueOf(5L);
    
    /**
     * Rabin-Miller certainty used for primality testing
     */
    protected static final int PRIMALITY_CERTAINTY = 50;
    
    /**
     * Invalid ECurve parameters error message
     */
    public static final String invalidECParams =
        "The specified parameters do not properly define a suitable elliptic curve";

    /**
     * Size of the underlying finite field GF(q)
     */
    private BigInteger q;

    /**
     * Coefficient of the elliptic curve equation
     */
    private BigInteger a;

    /**
     * Coefficient of the elliptic curve equation
     */
    private BigInteger b;

    /**
     * Cofactor of the base point (curve order u = h*n)
     */
    private BigInteger h;

    /**
     * Prime order of the base point (curve order u = h*n)
     */
    private BigInteger n;

    /**
     * The base point of large prime order n
     */
    private EPoint G;

    /**
     * The point at infinity
     */
    private EPoint infinity;

    /**
     * Multiples of the base point G 
     */
    protected EPoint[] AG;

    /**
     * Multiples of the base point G 
     */
    protected EPoint[] BG;

    /**
     * Size of window used by kG(). Default to 16 <BR>
     * <BR>
     * Reducing the window size in half reduces kG() run time 
     * in half at the cost of computing and storing
     * 2^^(keyLen/(2*WINDOWG)) points. 
     * i.e. 160 bit keys will precompute 32 points with a window of 16
     * and 1024 points with a window of 8
     */
    private final static int WINDOWG = 16;

    /**
     * Supported bit lengths of standard curves
     * Used by key generation
     */
    private final static int[] supportedSizes = {160,192,224,256,384,521 };

// Constructors & Internal Methods
//............................................................................
    
    /**
     * Create a full description of the elliptic curve over GF(p) satisfying
     * the equation y^2 = x^3 + ax + b with near-prime group order u = h*r
     * with a specified base point of prime order r.
     *
     * @param   p   an approximation for the size q of the underlying
     *              finite field GF(q) (q is taken to be the nearest odd prime
     *              not smaller than p or 3)
     * @param   a   curve equation coefficient
     * @param   b   curve equation coefficient
     * @param   h   cofactor of the curve group order
     * @param   n   prime order of the cryptographic subgroup
     * @param	Gx	x-coordinate of the base point of the curve
     * @param	Gy	x-coordinate of the base point of the curve
     * 
     * @exception	IllegalArgumentException	
     *              if the selected parameters don't define a proper curve
     */
    private ECurve(BigInteger p, BigInteger a, BigInteger b, 
		   BigInteger h, BigInteger n, BigInteger Gx, BigInteger Gy) {
        if (!p.isProbablePrime(PRIMALITY_CERTAINTY)) {
            throw new IllegalArgumentException
		(invalidECParams + ": " + 
		 "The underlying field size is not prime");
        }
        if (!n.isProbablePrime(PRIMALITY_CERTAINTY)) {
            throw new IllegalArgumentException
		(invalidECParams + ": " + 
		 "The order of the base point is not prime");
        }
        this.q = p;

	infinity = new EPoint(this); // caveat: must be set *after* this.q
        this.a = a;
        this.b = b;
        this.h = h;
        this.n = n;
        this.G = new EPoint(this, Gx, Gy);
	
	if (!G.multiply(n).isZero()) {
            throw new IllegalArgumentException
		(invalidECParams + ": " + "Wrong order");
        }

	/* Precompute multiples of G for use by kG() */
	precomputeG(WINDOWG);
	
	// Old implementation:
	//p2G = new EPoint[n.bitLength()];
	//	p2G[0] = G;
	//	for (int m = 1; m < p2G.length; m++) 	
	//	    p2G[m] = p2G[m - 1].twice(1);
	
    }
    
    /**
     * Precomputes multiples of G in AG[] and BG[] for kG()
     *
     * @param   windowG   Window Size to precompute
     */
    private void precomputeG(int windowG) {
        /*
         * This method implements the fixed point exponentiation algorithm
         * 
         * References:
         * 
         * Atsuko Miyaji, Takatioshi Ono and Henri Cohen,
	 * "Effecient Elliptic Curve Exponentiation", 
	 * Lecture Notes in Computer Science 1334, ICICS (1997),
	 * Session 9, Section 3.1
	 * 
         */

	/* Order of the sliding window (2*windowG) */
	int orderG = (n.bitLength()/(2*windowG));

	/* Size of the array to contain pre-computed multiples of G */
	int arrSize = (1<<orderG);
	
	/* Initialize local arrays used in computing AG and BG */
	EPoint[] G1 = new EPoint[orderG];
	EPoint[] G2 = new EPoint[orderG];
	
	/* Calculate & Store G, (windowG)G, 2*(windowG)G... */
	G1[0] = G;
	G2[0] = G.twice(windowG);
	for (int i = 1; i<orderG; i++) {
	    G1[i] = G1[i-1].twice(2*windowG);
	    G2[i] = G2[i-1].twice(2*windowG);
	}

	/* Initialize class arrays to contain multiples of G */
	AG = new EPoint[arrSize];
	BG = new EPoint[arrSize];
	AG[0] = infinity;
	BG[0] = infinity;	
	for (int s = 1; s < arrSize; s++) {
	    int as = 0;
	    BG[s] = AG[s] = infinity;
	    for (int j=0; j<orderG; j++) {
		as = (s>>>j)&1;
		if (as != 0) {
		    AG[s] =  AG[s].add(G1[j]);
		    BG[s] =  BG[s].add(G2[j]);
		}
	    }
	}
	
    }

// Public Methods
//............................................................................
    
    /**
     * Get a random nonzero point on this curve, given a fixed base point.
     * 
     * @param   rand    a cryptographically strong PRNG
     * 
     * @return  a random nonzero point on this curve
     */
    public EPoint pointFactory(SecureRandom rand) {
	BigInteger k;
	do {
	    k = new BigInteger(q.bitLength(), rand).mod(q);
	} while (k.signum() == 0);

	//       return G.multiply(k);
	return this.kG(k);
    }
    
    /**
     * Check whether this curve contains a given point
     * (i.e. whether that point satisfies the curve equation)
     * 
     * @param   P   the point whose pertinence or not to 
     *              this curve is to be determined
     * 
     * @return  true if this curve contains P, otherwise false
     */
    public boolean contains(EPoint P) {
	if (P.getQ().compareTo(q) != 0) {
	    return false;
	}
        if (P.isZero()) {
            return true; 
	    // the point at infinity does not satisfy the equation 
	    // but is obviously on the curve
        }
        // check the projective equation y^2 == x^3 + a.x.z^4 + b.z^6,
	// i.e. x.x^2 + [a.x + b.z^2].(z^2)^2 - y^2 == 0;
	// the computation below never uses intermediate 
	// values larger than 3q^2:
	BigInteger
	    x  = P.getX(),
	    y  = P.getY(),
	    z  = P.getZ(),
	    x2 = x.multiply(x).mod(q),
	    z2 = z.multiply(z).mod(q),
	    z4 = z2.multiply(z2).mod(q),
	    br = a.multiply(x).add(b.multiply(z2)).mod(q); 
	// bracketed expression [a.x + b.z^2]
	return x.multiply(x2).add(br.multiply(z4)).
	    subtract(y.multiply(y)).mod(q).signum() == 0;
    }
    
    /**
     * Build a standard curve
     * 
     * @param   fieldSize   underlying field size
     * 
     * @return  the desired curve, or null if the field size is not supported
     */
    public static ECurve getStandardCurve(int fieldSize) {
        BigInteger p;
        switch (fieldSize) {
        case 160:
            p = new BigInteger("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7FFFFFFF", 16);
            return new ECurve
		(p, 
		 new BigInteger
		    ("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7FFFFFFC", 16), // a
		 new BigInteger
		     ("1C97BEFC54BD7A8B65ACF89F81D4D4ADC565FA45", 16), // b
		 $1, // h
		 new BigInteger
		     ("0100000000000000000001F4C8F927AED3CA752257", 16), // n
		 new BigInteger
		     ("4A96B5688EF573284664698968C38BB913CBFC82", 16), // x
		 new BigInteger
		     ("23A628553168947D59DCC912042351377AC5FB32", 16)); // y
        case 192:
            p = new BigInteger
		("6277101735386680763835789423207666416083908700390324961279");
            return new ECurve
		(p,
		 BigInteger.valueOf(-3L), // a
		 new BigInteger("64210519e59c80e70fa7e9ab72243049feb8deecc146b9b1", 16), // b
		 $1, // h
		 new BigInteger("6277101735386680763835789423176059013767194773182842284081"), // n
		 new BigInteger("188da80eb03090f67cbf20eb43a18800f4ff0afd82ff1012", 16), // x
		 new BigInteger("07192b95ffc8da78631011ed6b24cdd573f977a11e794811", 16)); // y
        case 224:
            p = new BigInteger("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFE56D", 16);
            return new ECurve
		(p,
		 $0, // a
		 $5, // b
		 $1, // h
		 new BigInteger("010000000000000000000000000001DCE8D2EC6184CAF0A971769FB1F7", 16), // n
		 new BigInteger("A1455B334DF099DF30FC28A169A467E9E47075A90F7E650EB6B7A45C", 16), // x
		 new BigInteger("7E089FED7FBA344282CAFBD6F7E319F7C0B0BD59E2CA4BDB556D61A5", 16)); // y
        case 256:
            p = new BigInteger("115792089210356248762697446949407573530086143415290314195533631308867097853951");
            return new ECurve
		(p,
		 BigInteger.valueOf(-3L), // a
		 new BigInteger("5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604b", 16), // b
		 $1, // h
		 new BigInteger("115792089210356248762697446949407573529996955224135760342422259061068512044369"), // n
		 new BigInteger("6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296", 16), // x
		 new BigInteger("4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5", 16)); // y
        case 384:
            p = new BigInteger("39402006196394479212279040100143613805079739270465446667948293404245721771496870329047266088258938001861606973112319");
            return new ECurve
		(p,
		 BigInteger.valueOf(-3L), // a
		 new BigInteger("b3312fa7e23ee7e4988e056be3f82d19181d9c6efe8141120314088f5013875ac656398d8a2ed19d2a85c8edd3ec2aef", 16), // b
		 $1, // h
		 new BigInteger("39402006196394479212279040100143613805079739270465446667946905279627659399113263569398956308152294913554433653942643"), // n
		 new BigInteger("aa87ca22be8b05378eb1c71ef320ad746e1d3b628ba79b9859f741e082542a385502f25dbf55296c3a545e3872760ab7", 16), // x
		 new BigInteger("3617de4a96262c6f5d9e98bf9292dc29f8f41dbd289a147ce9da3113b5f0b8c00a60b1ce1d7e819d7a431d7c90ea0e5f", 16)); // y
        case 521:
            p = new BigInteger("6864797660130609714981900799081393217269435300143305409394463459185543183397656052122559640661454554977296311391480858037121987999716643812574028291115057151");
            return new ECurve
		(p,
		 BigInteger.valueOf(-3L), // a
		 new BigInteger("051953eb9618e1c9a1f929a21a0b68540eea2da725b99b315f3b8b489918ef109e156193951ec7e937b1652c0bd3bb1bf073573df883d2c34f1ef451fd46b503f00", 16), // b
		 $1, // h
		 new BigInteger("6864797660130609714981900799081393217269435300143305409394463459185543183397655394245057746333217197532963996371363321113864768612440380340372808892707005449"), // n
		 new BigInteger("0c6858e06b70404e9cd9e3ecb662395b4429c648139053fb521f828af606b4d3dbaa14b5e77efe75928fe1dc127a2ffa8de3348b3c1856a429bf97e7e31c2e5bd66", 16), // x
		 new BigInteger("11839296a789a3bc0045c8a5fb42c7d1bd998f54449579b446817afbd17273e662c97ee72995ef42640c550b9013fad0761353c7086a272c24088be94769fd16650", 16)); // y
        default:
            return null;
        }
    }

    /**
     * Compute k*G
     * 
     * @param   k   scalar by which the base point G is to be multiplied
     * 
     * @return  k*G
     */
    public EPoint kG(BigInteger k) {
        /*
         * This method implements the fixed point exponentiation algorithm
         * 
         * References:
         * 
         * Atsuko Miyaji, Takatioshi Ono and Henri Cohen,
	 * "Effecient Elliptic Curve Exponentiation", 
	 * Lecture Notes in Computer Science 1334, ICICS (1997),
	 * Session 9, Section 3.1
	 * 
         */
	k = k.mod(n); // reduce k mod n

	/* Order of the sliding window (2*windowG) */
	int orderG = (n.bitLength()/(2*WINDOWG));

	/* Initialize arrays to contain lookup indices for AG and BG */
	int[] u = new int[WINDOWG];
	int[] v = new int[WINDOWG];	
	for (int j =0; j<WINDOWG; j++) 
	    for (int i=0; i<orderG; i++) {
		// Even windows
		if (k.testBit(WINDOWG*(2*i)+j)) 
		    u[j] += 1<<i;
		// Odd Windows
		if (k.testBit(WINDOWG*(2*i+1)+j)) 
		    v[j] += 1<<i;	
	    }

	/* Perform sliding window multiplication */
	EPoint T = infinity;	    	    
	for (int i=(WINDOWG-1); i>=0; i--) {
	    T = T.twice(1);
	    // Add an even window
	    if (u[i] != 0)
		T = T.add(AG[u[i]]);
	    // Add an odd window
	    if (v[i] != 0)
		T = T.add(BG[v[i]]);
	}
	    
	return T;
	
	// Old Implementation:
	//EPoint A = infinity;
	//	for (int i = k.bitLength() - 1; i >= 0; i--) 
	//	    if (k.testBit(i)) 
	//		A = A.add(p2G[i]);	    	
	//	return A;
    }
    
    /**
     * Size of the underlying finite field GF(q)
     */
    public BigInteger getQ() { return q; }

    /**
     * Coefficient of the elliptic curve equation
     */
    public BigInteger getA() { return a; }

    /**
     * Coefficient of the elliptic curve equation
     */
    public BigInteger getB() { return b; }

    /**
     * Cofactor of the base point (curve order u = h*n)
     */
    public BigInteger getH() { return h; }

    /**
     * Prime order of the base point (curve order u = h*n)
     */
    public BigInteger getN() { return n; }

    /**
     * The base point of large prime order n
     */
    public EPoint getG() { return G; }

    /**
     * The point at infinity
     */
    public EPoint getInfinity() { return infinity; }

    /**
     * Supported bit lengths of standard curves
     *
     * @return Array of supported key sizes
     */
    public static int[] getSupportedSizes() { return supportedSizes; }
}




















