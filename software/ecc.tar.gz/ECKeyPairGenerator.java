import java.security.*;
import java.security.spec.*;
import java.math.BigInteger;
import java.util.Random;

/**
 * Implementation of Elliptic Curve Signatures
 * <BR>
 * Key Generation method Contains code from 
 * Cryptix Elliptix Package:<BR>
 * <BR>
 * Copyright (C) 1995-2000 Systemics Ltd.<BR>
 * on behalf of the Cryptix Development Team. All rights reserved.<BR>
 * <BR>
 * Use, modification, copying and distribution of this software is subject to
 * the terms and conditions of the Cryptix General Licence. You should have 
 * received a copy of the Cryptix General License along with this library; 
 * if not, you can download a copy from http://www.cryptix.org/ . <BR>
 * <BR>
 * @author  Paulo S. L. M. Barreto (pbarreto@cryptix.org)  <BR>
 *          Modifications by Steve Weis (sweis@cs.berkeley.edu)
 */
public class ECKeyPairGenerator 
extends KeyPairGenerator {

// Constants and variables
//............................................................................

    public static final String COPYRIGHT = "Copyright &copy 1995-2000 Systemics Ltd. on behalf of the Cryptix Development Team. All rights reserved. ";
    
    /**
     * A cryptographically secure source of randomness for this key-generator.
     */
    private SecureRandom random;

    /**
     * Underlying elliptic curve which public key resides on
     */ 
    private ECurve curve = null;

    /**
     * The standard name of this algorithm    
     */
    private static final String ALGNAME = "ECDSA/ECNR";

// Constructors
//............................................................................

    /**
     * Constructor needed to extend KeyPairGenerator class
     *
     * @param  algorithm        the standard string name of the algorithm.
     *
     */
    protected ECKeyPairGenerator(String algorithm) {
	super(algorithm);
    }

    public ECKeyPairGenerator() { 
	this(ALGNAME);
    }

// KeyGenerator method implementation
//............................................................................

    /**
     * Implementation of EC keypair generation. 
     * <BR>
     * Each entity A does the following:<
     * 1.Select an elliptic curve E defined over Zp. The number 
     *   of points in E(Zp) should be divisible by a large prime n. <BR>
     * 2.Select a point P E(Zp) of order n. <BR>
     * 3.Select a statistically unique and unpredictable
     *   integer d in the interval [1, n - 1]. <BR>
     * 4.Compute Q = dP. <BR>
     * 5.A's public key is (E, P, n, Q); A's private key is d. <BR>
     *
     * @throws GenericECException
     *
     * @author  Paulo S. L. M. Barreto <pbarreto@cryptix.org>  
     *
     * @return Public/Private EC Keypair
     */
    public KeyPair generateKeyPair() throws GenericECException {
	/*
	 * If the base curve is not defined, throw an exception.
	 * initialize(keysize) must be called.
	 */ 
	if (curve == null) 
	    throw new GenericECException("Key pair generator not initialized");

	BigInteger x;
	
	// generate suitable private key x:
	BigInteger n = this.curve.getN();
	int t = n.bitLength();
	do {
	    x = new BigInteger(t, random);
	    if (x.compareTo(n) >= 0) {
		x = x.subtract(n);
	    }
	    /* invariant: 0 <= x < n */
	} while (x.signum() == 0);
	/* invariant: 0 < x < n */
	// compute the corresponding public key:		
	EPoint Y = this.curve.kG(x).normalize();
	
	return new KeyPair(new ECPublicKey(Y,curve), 
			   new ECPrivateKey(x,curve));
	
    }

    /** 
     * Initializes the key pair generator and selects a curve of 
     * greater or equal to the specified key size, if possible
     *
     * @param keysize - requested keysize associated with underlying curve 
     */
    public void initialize(int keysize) {
	// Just initialize the secure random source
	this.initSecureRandom();
	curve = selectCurve(keysize);
    }
    
    /** 
     * Initializes the key pair generator and selects a curve of 
     * greater or equal to the specified key size, if possible
     *
     * @param keysize - requested keysize associated with underlying curve 
     * @param random - secure PNRG to use for this generator
     */
    public void initialize(int keysize, SecureRandom random) {
	this.random = random;
	curve = selectCurve(keysize);
    }

    /** 
     * Initializes the key pair generator and selects a curve of 
     * greater or equal to the specified key size, if possible
     *
     * @param params - curve parameters for key generation
     */
    public void initialize(AlgorithmParameterSpec params)
	throws InvalidAlgorithmParameterException {
	if (!(params instanceof ECParameterSpec))
	    throw new 
		InvalidAlgorithmParameterException("Non-EC parameter spec");
	this.initSecureRandom();
	curve = ((ECParameterSpec)params).getCurve();
    }

    /** 
     * Initializes the key pair generator and selects a curve of 
     * greater or equal to the specified key size, if possible
     *
     * @param params - curve parameters for key generation
     * @param random - secure PNRG to use for this generator
     */
    public void initialize(AlgorithmParameterSpec params,
			   SecureRandom random)
	throws InvalidAlgorithmParameterException {
	if (!(params instanceof ECParameterSpec))
	    throw new 
		InvalidAlgorithmParameterException("Non-EC parameter spec");
	this.random = random;
	curve = ((ECParameterSpec)params).getCurve();
    }

    /**
     * Returns the standard name of this algorithm
     */
    public String getAlgorithm() { return ALGNAME; }

// Utility Methods
//............................................................................
    private void initSecureRandom() {
	byte[] randSeed = new byte[20];
	(new Random()).nextBytes(randSeed);
        this.random = new SecureRandom(randSeed);
    }

// ECC specific methods
//............................................................................

    /**
     * Chooses a curve appropriate to the given keysize
     *
     * @param   keysize      Selects a curve of this specified size
     * @return               An ECurve of the specified key size
     */
    private ECurve selectCurve(int keysize) {
	ECurve selected = null;
	int sizes[] = ECurve.getSupportedSizes();

	for (int i=0; i<sizes.length; i++) 
	    if (keysize <= sizes[i]) {
		selected = ECurve.getStandardCurve(sizes[i]);	
		break;
	    }
	
	// TODO: Throw an exception here?
	if (selected == null) {
	    selected = ECurve.getStandardCurve(sizes[sizes.length-1]);
	    System.err.println("Specified Elliptic Curve Keysize of " + 
			       keysize +  " is too large. Defaulting to " 
			       + sizes[sizes.length-1]);
	}

	return selected;
    }


}




