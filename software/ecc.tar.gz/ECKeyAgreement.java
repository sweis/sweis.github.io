import java.util.Random;
import java.math.BigInteger;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.KeyAgreementSpi;
import javax.crypto.SecretKey;
import javax.crypto.ShortBufferException;


/**
 * Implemented of Elliptic Curve Diffe-Hellman Key Agreement
 * References: IEEE P1363 (Draft v. 13) Section 7.2.1 (page 37)
 *
 * @author Steve Weis (sweis@cs.berkeley.edu)
 */

public class ECKeyAgreement extends KeyAgreementSpi {
    // NOTE: This class must be public to allow javax.crypto.KeyAgreement 
    // to access it or must be put in that package

// Constants and variables
//............................................................................

   public static final String UC_COPYRIGHT = "Copyright &copy 2000 The Regents of the University of California. All Rights Reserved. ";

    /* A locally known secret value. i.e. A private key */
    private BigInteger secret = null;
    
    /* Currently unused. Will be needed if ECMQV is implemented */
    private int algorithmType;

    /* Contains the secret value (G.u*v1*..*vn).x */
    private EPoint P;
    
    /* Indicates whether this is the last phase of key agreement */
    private boolean finished;
    
// Constructor
//............................................................................

    /**
     * Constructor for use by javax.crypto.KeyAgreement only.
     */
    public ECKeyAgreement()
    {
        super();
    }


// Initialization Methods
//............................................................................

    /**
     * Initialize for key agreement with a private key
     *
     * @param key - private key 
     * @exception InvalidKeyException if !(key instanceof ECPrivateKey)
     */
    protected void engineInit(Key key, SecureRandom unused) 
    	throws InvalidKeyException {
	algorithmType = ECAlgorithm.ECDH;
	
	if (! (key instanceof ECPrivateKey))
	    throw new InvalidKeyException("Key is not an ECPrivateKey");

	this.secret = ((ECPrivateKey)key).getD();
	
	P = null;	
	finished = false;
    }

    /**
     * Initialize for key agreement with a private key and algorithm params
     *
     * @param key - private key 
     * @param unused - Algorithm parameters are currently unimplmented..
     * @exception InvalidKeyException if !(key instanceof ECPrivateKey)
     */
    protected void engineInit(Key key,
			      AlgorithmParameterSpec params,
			      SecureRandom unused)
	throws java.security.InvalidKeyException,
	       java.security.InvalidAlgorithmParameterException {

	// NOTE: Ignoring algorithm params for now
	this.engineInit(key,unused);
    }

// Key Agreement Methods
//............................................................................

    /**
     * Do a phase of key agreement
     *
     * @param key - a public key used to create the shared secret     
     * @param lastPhase - boolean indicating whether this is the last phase
     *
     * @return an ECPublic key with the secret as its x component
     * @exception InvalidKeyException if !(key instanceof ECPublicKey)
     */	       
    protected Key engineDoPhase(Key key, boolean lastPhase) 
	throws InvalidKeyException {
	if (! (key instanceof ECPublicKey))
	    throw new InvalidKeyException("Key is not an ECPublicKey");

	 EPoint Q = ((ECPublicKey)key).getQ();
	
	 /* Check if this is the last phase */
	 //if (!finished) 
	    P = ECAlgorithm.keyAgree(secret,Q,algorithmType);
	 // else
	 // User has already called this method with lastPhase==true 
	 // throw new RuntimeException("Illegal key agreement phase");
	 // NOTE: Just ignoring for now...
	
	finished = (finished || lastPhase);
	return new ECPublicKey(P,P.getE());
	
    }

    /**
     * Generate a secret value 
     *
     * @return a shared secret value
     * @exception IllegalStateException if not in the lastPhase state
     */
    protected  byte[] engineGenerateSecret()
	throws java.lang.IllegalStateException {
	if (!finished)
	    throw new 
		IllegalStateException("Key agreement protocol not completed");

	return P.getX().toByteArray();
    }
    
    /**
     * Generate a secret value 
     *
     * @return a shared secret value
     * @exception IllegalStateException if not in the lastPhase state
     */
    protected  int engineGenerateSecret(byte[] sharedSecret,
					int offset)
	throws java.lang.IllegalStateException,
	       ShortBufferException {

	if (!finished)
	    throw new 
		IllegalStateException("Key agreement protocol not completed");
	
	byte[] temp = P.getX().toByteArray();
	
	if ((sharedSecret.length-offset) < temp.length) 
	    throw new ShortBufferException(temp.length + 
					   " bytes needed for shared secret");

	try {
	    System.arraycopy(temp,0,sharedSecret,offset,temp.length);
	    return temp.length;
	}
	catch (Exception e) {
	    return 0;
	}
    }
    
    /**
     * Generate a secret value 
     *
     * @return a shared secret value
     * @exception IllegalStateException if not in the lastPhase state
     */
    protected SecretKey engineGenerateSecret(java.lang.String algorithm)
	throws java.lang.IllegalStateException,
	       java.security.NoSuchAlgorithmException,
	       java.security.InvalidKeyException 
    {
	throw new NoSuchAlgorithmException("NYI");
    }
    
}
