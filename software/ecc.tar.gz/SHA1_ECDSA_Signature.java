/**
 * A class to digest a message with SHA-1, and sign/verify the
 * resulting hash using the ECDSA digital signature scheme
 *
 * @author Steve Weis (sweis@cs.berkeley.edu)
 */

public class SHA1_ECDSA_Signature
    extends ECSignature {

   public static final String UC_COPYRIGHT = "Copyright &copy 2000 The Regents of the University of California. All Rights Reserved. ";

    public SHA1_ECDSA_Signature() { super("SHA-1/ECDSA"); }
}


