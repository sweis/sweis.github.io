import java.security.*;
import javax.crypto.KeyAgreement;
import java.security.spec.*;
import java.util.Random;
import java.math.BigInteger;

class KeyAgreeTest {
    public static void main(String[] args) {

	/* Dynamically Install dummy ECC Provider */
	ECDummyProvider.install();

//  		Provider[] provs = Security.getProviders();
//  		for (int i=0; i<provs.length; i++) {
//  		    System.out.println(provs[i].getInfo());
//  		    Object[] list = provs[i].values().toArray();
//  		    for (int j=0;j<list.length; j++)
//  			System.out.println(list[j]);
		    
//  		}
	String provider = "ECC";
	KeyPairGenerator kpgen;
	KeyPair kp1, kp2, kp3;
	KeyAgreement ka;
	BigInteger v1, v2;
	byte[] value1, value2;

	try {
	    kpgen = 
		KeyPairGenerator.getInstance("ECDSA",provider);
	    
	    kpgen.initialize(160);

	    /* Test two-party key agreement */
	    kp1 = kpgen.generateKeyPair();
	    kp2 = kpgen.generateKeyPair();
	    ka = KeyAgreement.getInstance("ECDH","ECC");

	    ka.init(kp1.getPrivate());
	    System.out.println(ka.doPhase(kp2.getPublic(),true));
	    value1 = ka.generateSecret();
	    
	    ka.init(kp2.getPrivate());
	    System.out.println(ka.doPhase(kp1.getPublic(),true));
	    value2 = ka.generateSecret();
	    
	    v1 = new BigInteger(value1);
	    v2 = new BigInteger(value2);
	    if (v1.equals(v2))
		System.out.println("Two-Party Secrets are the same");
	    else
		System.out.println("Two-Party Secrets are different");
	}
	
	catch (Exception e) {
	    e.printStackTrace();
            System.out.println(e.toString());
	}
    }
}

