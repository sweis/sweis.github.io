import java.util.Random;
import java.math.BigInteger;

import java.security.*;
import java.security.Signature;
import java.security.MessageDigest;
import javax.crypto.Mac;

import cryptix.provider.*;
import cryptix.provider.cipher.*;
import cryptix.provider.key.*;

import java.security.InvalidKeyException;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;


/**
 * Implements framework for the ECES Scheme<BR>
 * References: "DHAES: An Encryption Scheme Based on 
 * the Diffe-Hellman Problem"<BR>; Adballa, Bellare & Rogaway; Sept. 1998, <BR>
 * Submitted to P1363a<BR>
 * 
 *
 * @author Steve Weis (sweis@cs.berkeley.edu)
 */

class ECES {
   public static final String UC_COPYRIGHT = "Copyright &copy 2000 The Regents of the University of California. All Rights Reserved. ";
    private MessageDigest hash, mac;
 
    private Cipher cipher;
    byte[] encKey;
    //    private int state;

    //    private ECPublicKey pk;
    //    private ECPrivateKey sk;

    byte[] tag;

    public ECES(MessageDigest hash, MessageDigest mac, Cipher cipher) {
	this.hash = hash;
	this.mac = mac;
	this.cipher = cipher;
    }

    public void initEncrypt(ECPublicKey pk, ECPrivateKey sk) 
	throws InvalidKeyException, KeyException  {
	
	BigInteger u = sk.getD();

	EPoint U = sk.getCurve().kG(u);
	EPoint X = pk.getQ().multiply(u);
	this.init(U,X);
	cipher.initEncrypt(new RawSecretKey("ECES",encKey));	    
    }

    public void initDecrypt(ECPublicKey pk, ECPrivateKey sk) 
	throws InvalidKeyException, KeyException {
	EPoint U = pk.getQ();

	EPoint X = U.multiply(sk.getD());
	this.init(U,X);
	cipher.initDecrypt(new RawSecretKey("ECES",encKey));	    
    }

    private void init(EPoint U, EPoint X) 
	throws InvalidKeyException {
	hash.reset();	

	byte[] macKey = hash.digest(U.getX().toByteArray());
	mac.update(macKey);
	//mac.init(new RawSecretKey("ECES",macKey));

	encKey = hash.digest(X.getX().toByteArray());
	System.out.println((new BigInteger(encKey)).toString(16));
    }

    public ECEncryptedMessage encrypt(byte[] message) 
	throws IllegalBlockSizeException, BadPaddingException {	
	byte[] encMess = cipher.doFinal(message);
    	return new ECEncryptedMessage(mac.digest(encMess),encMess);
    }

    public byte[] decrypt(ECEncryptedMessage message) 
	throws Exception {
	
	byte[] tag = message.getTag();
	byte[] encMessage = message.getMessage();
	
	byte[] verTag = mac.digest(encMessage);
	//for (int i=0; i<tag.length; i++) 
	//	    if (tag[i] != verTag[i])
	//		throw new Exception ("Encrypted message does not verify");
	
	return cipher.doFinal(encMessage);
    }
}
