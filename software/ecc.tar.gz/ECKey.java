import java.security.Key;

/**
 * Interface to an EC public or private key
 *
 * @author Steve Weis (sweis@cs.berkeley.edu) 
 */
public interface ECKey extends Key {

   public static final String UC_COPYRIGHT = "Copyright &copy 2000 The Regents of the University of California. All Rights Reserved. ";

    /**
     * Return the curve this key is based upon
     *
     * @returns the curve this key is based upon
     */
    public ECurve getCurve();
    
    public String getAlgorithm();
    public byte[] getEncoded();
}
