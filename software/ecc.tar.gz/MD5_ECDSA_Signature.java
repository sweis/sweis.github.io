/**
 * A class to digest a message with MD5, and sign/verify the
 * resulting hash using the ECDSA digital signature scheme
 *
 * @author Steve Weis (sweis@cs.berkeley.edu)
 */

public class MD5_ECDSA_Signature
    extends ECSignature {

   public static final String UC_COPYRIGHT = "Copyright &copy 2000 The Regents of the University of California. All Rights Reserved. ";

    public MD5_ECDSA_Signature() { super("MD5/ECDSA"); }
}

