/**
 * Wraps messages encrypted with ECES
 *
 * @author Steve Weis (sweis@cs.berkeley.edu)
 */
class ECEncryptedMessage {

// Constants and variables
//............................................................................

   public static final String UC_COPYRIGHT = "Copyright &copy 2000 The Regents of the University of California. All Rights Reserved. ";

    /* MAC/HMAC tag */
    private byte[] tag;
    
    /* Message bytes */
    private byte[] message;
    
// Constructor
//............................................................................

    /**
     * Create a ECEncryptedMessage
     *
     * @param U - ECPublic Key used to encrypt this block
     * @param tag - MAC Tag for hte encrypted message
     * @param encryptedM - Encrypted message data
     */
    public ECEncryptedMessage(byte[] tag, byte[] message) {
	this.tag = tag;
	this.message = message;
    }


// Public Interface
//............................................................................
    
    /**
     * Return the MAC tag for the encrypted block
     *
     * @return the MAC tag for the encrypted block
     */
    public byte[] getTag() { return tag; }

    /**
     * Return the encrypted message
     *
     * @return the encrypted message
     */
    public byte[] getMessage() { return message; }
}
