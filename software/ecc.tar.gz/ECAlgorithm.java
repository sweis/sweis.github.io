/**
 * Implements Elliptic Curve signing, verification and key agreement
 * algorithms <BR>
 * <BR>
 * @author  Steve Weis (sweis@cs.berkeley.edu)<BR>
 * <BR>
 * Signature and Verification Methods contains code from 
 * Cryptix Elliptix Package:<BR>
 * <BR>
 * Copyright (C) 1995-2000 Systemics Ltd.<BR>
 * on behalf of the Cryptix Development Team. All rights reserved.<BR>
 * <BR>
 * Use, modification, copying and distribution of this software is subject to
 * the terms and conditions of the Cryptix General Licence. You should have 
 * received a copy of the Cryptix General License along with this library; 
 * if not, you can download a copy from http://www.cryptix.org/ . <BR>
 * <BR>
 * @author  Paulo S. L. M. Barreto <pbarreto@cryptix.org><BR>
 * <BR>
 */

import java.math.BigInteger;
import java.security.KeyPair;
import java.security.SecureRandom;
import java.security.SignatureException;

class ECAlgorithm {

// Constants and variables
//............................................................................

    public static final String COPYRIGHT = "Copyright &copy 1995-2000 Systemics Ltd. on behalf of the Cryptix Development Team. All rights reserved. ";

   public static final String UC_COPYRIGHT = "Copyright &copy 2000 The Regents of the University of California. All Rights Reserved. ";

    /**
     * Flags for supported algorithms
     */
    public static final int ECDSA	= 0;
    public static final int ECNR	= 1;
    public static final int ECDH	= 2;

// Signature method implementation
//............................................................................

    /**
     * EC signature generation
     *
     * Supports both ECDSA and Nyberg-Rueppel signature generation:
     *
     * @author  Paulo S. L. M. Barreto <pbarreto@cryptix.org>
     */
    public static byte[] sign(ECurve E, BigInteger x, 
			    byte[] d, SecureRandom random, int alg) 
    {
	if (E == null || x == null || random == null) {
	    throw new RuntimeException("invalid argument(s)");
	}

	BigInteger n = E.getN();
	int len = (n.bitLength() + 7)/8;		
	byte[] sig = new byte[2*len];

	BigInteger k, r, s;
	EPoint V;		

	// compute message representative (0 <= m < n):	     
	byte[] h = new byte[1 + d.length];		
	h[0] = 0; 
	// this is necessary to ensure m >= 0		
	System.arraycopy(d, 0, h, 1, d.length);		
	BigInteger m = new BigInteger(h).mod(n);
	
	switch (alg) {
	case ECDSA:
	    /*
	     * ECDSA signature generation:
	     *
	     * k = random() (condition: 1 <= k < n)
	     * V = k*G
	     * r = abscissa(k*G) mod n	     (condition: r != 0)
	     * s = (m + r*x)*k^(-1) mod n     (condition: s != 0)
	     *
	     * The signature is the pair (r, s).
	     */
	    do {
		do {
		    // create volatile key pair	 
		    KeyPair pair = generateKeyPair(E,random);
		    k = ((ECPrivateKey)pair.getPrivate()).getD();
		    V = ((ECPublicKey)pair.getPublic()).getQ();
		    
		    // compute 1st signature component r: 
		    r = V.getX().mod(n);
		} while (r.signum() == 0);
		
		
		// compute 2nd signature component s:		
		s = m.add(r.multiply(x)).multiply(k.modInverse(n)).mod(n);
	    } while (s.signum() == 0);
	    
	    // write signature:
	    h = r.toByteArray();			
	    if (h.length <= len) {	
		for (int i = 0; i < len - h.length; i++) {
		    sig[i] = 0;				}
		System.arraycopy(h, 0, sig, len - h.length, h.length);
	    } else {
		/*
		 * this can only happen if the first octet is negative 
		 * (meaning a negative BigInteger in two's complement),
		 * in which case a zero octet is prepended to the byte array:
		 */
		if (h.length != len + 1 || h[0] != 0) {	 
		    throw new RuntimeException("logic error");
		}				
		System.arraycopy(h, 1, sig, 0, len);			
	    }			
	    h = s.toByteArray();
	    if (h.length <= len) {	
		for (int i = 0; i < len - h.length; i++) {
		    sig[len + i] = 0;	
		}
		System.arraycopy(h, 0, sig, 2*len - h.length, h.length);
	    } else {
		/*
		 * this can only happen if the first octet is negative
		 * (meaning a negative BigInteger in two's complement),	
		 * in which case a zero octet is prepended to the byte array:
		 */
		if (h.length != len + 1 || h[0] != 0) {
		    throw new RuntimeException("logic error");
		}				
		System.arraycopy(h, 1, sig, len, len);
	    }			
	    break;
	    
	case ECNR:
	    /*
	     * Nyberg-Rueppel signature generation:
	     *
	     * k = random()	   (condition: 1 <= k < n)
	     * V = k*G
	     * w = abscissa(V)
	     * r = (m + w) mod n  (condition: r != 0)
	     * s = (k - r*x) mod n
	     *
	     * The signature is the pair (r, s).
	     */
	    do {
	      // create volatile key pair				
		KeyPair pair = generateKeyPair(E,random);
		k = ((ECPrivateKey)pair.getPrivate()).getD();
		V = ((ECPublicKey)pair.getPublic()).getQ();
		// compute 1st signature component r:	
		r = m.add(V.getX()).mod(n);
	    } while (r.signum() == 0);
	    // compute 2nd signature component s:			
	    s = k.subtract(r.multiply(x)).mod(n);	    
	    // write signature:
	    h = r.toByteArray();			
	    if (h.length <= len) {	
		for (int i = 0; i < len - h.length; i++) {
		    sig[i] = 0;	
		}
		System.arraycopy(h, 0, sig, len - h.length, h.length);
	    } else {
		/*
		 * this can only happen if the first octet is negative
		 * (meaning a negative BigInteger in two's complement),
		 * in which case a zero octet is prepended to the byte array:
		 */
		if (h.length != len + 1 || h[0] != 0) {
		    throw new RuntimeException("logic error");
		}	
		System.arraycopy(h, 1, sig, 0, len);			
	    }			
	    h = s.toByteArray();
	    if (h.length <= len) {
		for (int i = 0; i < len - h.length; i++) {
		    sig[len + i] = 0;
		}	       
		System.arraycopy(h, 0, sig, 2*len - h.length, h.length);
	    } else {
		/*
		 * this can only happen if the first octet is negative
		 * (meaning a negative BigInteger in two's complement),
		 * in which case a zero octet is prepended to the byte array:
		 */
		if (h.length != len + 1 || h[0] != 0) {
		    throw new RuntimeException("logic error");
		}				
		System.arraycopy(h, 1, sig, len, len);			
	    }
	    break;		
	default:
	    throw 
		new RuntimeException("algorithm is invalid or not yet implemented");
	}		
	return sig;
    }    

// Verification method implementation
//............................................................................

    /**
     * Verify a signature.
     *
     * Supports both ECDSA and Nyberg-Rueppel signature verification:
     *
     * @author  Paulo S. L. M. Barreto <pbarreto@cryptix.org>
     * 
     * @return	true if the signature is valid, otherwise false.
     */
    public static boolean verify(ECurve E, EPoint Y, byte[] sig,
			    byte[] d, SecureRandom random, int alg) 
    {
  	// TODO: Check if the pos can be passed as an arugment or needs to be
  	int pos =0 ;

	BigInteger n = E.getN();	

	int len = (n.bitLength() + 7)/8;		
	if ((E == null) || 
	    (Y == null) || 
	    (sig == null) || 
	    (pos + 2*len > sig.length)) {
	    throw new RuntimeException("invalid argument(s)");
	}		

  	boolean ret = false;
  	BigInteger r, s, u, v, t;
  	EPoint W;

	// compute message representative (0 <= m < n):		
	byte[] h = new byte[1 + d.length];		
	h[0] = 0; // this is necessary to ensure m >= 0		
	System.arraycopy(d, 0, h, 1, d.length);		
	BigInteger m = new BigInteger(h).mod(n);

	// read signature:		
	h = new byte[1 + len];		
	h[0] = 0;		
	System.arraycopy(sig, pos, h, 1, len);		
	r = new BigInteger(h);
	pos += len;
	System.arraycopy(sig, pos, h, 1, len);		
	s = new BigInteger(h);
	
	switch (alg) {
	case ECDSA:
	    /*
	     * ECDSA signature verification:
	     *
	     * h = s^(-1) mod n	   (condition: 1 <= s < n)
	     * u = m*h mod n
	     * v = r*h mod n	   (condition: 1 <= r < n)
	     * W = u*G + v*Y = s^(-1)*(m + r*x)*G = k*G
	     * t = abscissa(W) mod n
	     *
	     * The signature is accepted <=> t = r.
	     */
	    if (r.signum() <= 0 || r.compareTo(n) >= 0) {
		throw new RuntimeException("Invalid signature component r");
	    }
	    if (s.signum() <= 0 || s.compareTo(n) >= 0) {	
		throw new RuntimeException("Invalid signature component s");
	    }
	    // compute s^(-1) mod n:			
	    s = s.modInverse(n);
	    // compute double exponential:
	    u = m.multiply(s).mod(n);
	    v = r.multiply(s).mod(n);			

	    W = EPoint.generatorSimult(u, v, Y); 
	    //    W = (Y.multiply(v)).add(E.getG().multiply(u)).normalize();
	    //	    W = EPoint.simultaneous(v,Y,u,E.getG());

	    t = W.getX().mod(n);
	    // complete verification:
	    ret = (t.compareTo(r) == 0);
	    break;
		
	case ECNR:
	    /*
	     * Nyberg-Rueppel signature verification:
	     *
	     * W = r*Y + s*G = (s + r*x)*G = k*G  
	     * (condition: 1 <= r < n, 0 <= s < n)
	     * w = abscissa(W)
	     * t = (r - w) mod n
	     *
	     * The signature is accepted <=> t = m.
	     */
	    if (r.signum() <= 0 || r.compareTo(n) >= 0) {	
		throw new RuntimeException("Invalid signature component r");
	    }
	    if (s.signum() <  0 || s.compareTo(n) >= 0) {	
		throw new RuntimeException("Invalid signature component s");
	    }
	    // compute double exponential:
	    W = EPoint.generatorSimult(s,r, Y); //, s, E.getG());
	    t = r.subtract(W.getX()).mod(n);
	    // complete verification:
	    // complete verification:
	    ret = (t.compareTo(m) == 0);
	    break;
	default:
	    throw 
		new RuntimeException("algorithm is invalid or not yet implemented");
	}	
	return ret;
    }    

// Key Agreement
//............................................................................

    /**
     * Generate a shared secret value using one party's private key and 
     * a second party's public key.<BR>
     * Both parties are assumed to share the same curve parameters.<BR>
     *
     * References: IEEE P1363 Section 7.2.1
     *
     * @param s - a large integer private key
     * @param W - a public key of the form W=kG
     *
     * @return the point (s*k*G)
     */
    public static EPoint keyAgree(BigInteger s, EPoint W, int alg) {
	// Note: Returning EPoint instead of byte[] or BigInteger for 
	// flexibility. Either one would suffice.
	//	BigInteger z = null;
	EPoint P = null;

	switch(alg) {
	case ECDH:
	    P = W.multiply(s).normalize();
	    if (P.isZero())
		throw 
		    new RuntimeException("Error occured in key generation");
	    //  BigInteger z = P.getX();	    
	    break;
	}
	//	if (z == null)
	//	    throw 
	//		new RuntimeException("Error occured in key generation");
	//	return z.toByteArray();
	return P;
    }


// Utility methods
//............................................................................

    /* 
     * Generate a volatile key pair for use in signing 
     */   
    private static KeyPair generateKeyPair(ECurve curve, SecureRandom random) 
    {
	BigInteger x;
	
	// generate suitable private key x:
	BigInteger n = curve.getN();
	int t = n.bitLength();
	do {
	    x = new BigInteger(t, random);
	    if (x.compareTo(n) >= 0) {
		x = x.subtract(n);
	    }
	    /* invariant: 0 <= x < n */
	} while (x.signum() == 0);
	/* invariant: 0 < x < n */
	// compute the corresponding public key:		
	EPoint Y = curve.kG(x).normalize();
	
	return new KeyPair(new ECPublicKey(Y,curve), 
			   new ECPrivateKey(x,curve));
    }

}
