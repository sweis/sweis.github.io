import java.math.BigInteger;
import java.util.Random;
import java.security.*;

public class SigTest {
    public static void main(String[] args) {

	/* Dynamically Install dummy ECC Provider */
	ECDummyProvider.install();

	/* If Users specify arguments, run a single test */

	int argCount = args.length;

	if (argCount > 4) {
	    int runs = 20;
	    String digest = "SHA-1", provider = "ECC", algorithm = "ECDSA";
	    int keysize = 160;
	    try {
		provider = args[0];
		digest = args[1];
		algorithm = args[2];
		keysize = Integer.parseInt(args[3]);
		runs = Integer.parseInt(args[4]);
	    }
	    catch (Exception e) {
		System.out.println("Usage - ");
		System.out.println("java SigTest provider " + 
				   "digest algorithm keysize runs");
		System.exit(0);
	    }

	RunTest(provider,digest,algorithm,runs,keysize);
	} else {
	/* otherwise, run a suite of tests */
 	    RunTest("SUN","SHA-1","DSA",25,512);
 	    RunTest("SUN","SHA-1","DSA",25,1024);
 	    RunTest("Cryptix","SHA-1","RSA",25,512);
 	    RunTest("Cryptix","SHA-1","RSA",25,1024);
 	    RunTest("Cryptix","SHA-1","RSA",25,2048);
	    // 	    RunTest("Cryptix","SHA-1","ElGamal",5,512);
	    // 	    RunTest("Cryptix","SHA-1","ElGamal",5,1024);
//  	    RunTest("ECC","SHA-1","ECDSA",5,160);
//  	    RunTest("ECC","SHA-1","ECDSA",5,192);
//  	    RunTest("ECC","SHA-1","ECDSA",5,224);
//  	    RunTest("ECC","SHA-1","ECNR",5,160);
//  	    RunTest("ECC","SHA-1","ECNR",5,192);
//  	    RunTest("ECC","SHA-1","ECNR",5,224);

//   	    RunTest("SUN","MD5","DSA",5,512);
//   	    RunTest("SUN","MD5","DSA",5,1024);
//   	    RunTest("Cryptix","MD5","RSA",5,512);
//   	    RunTest("Cryptix","MD5","RSA",5,1024);
//   	    RunTest("Cryptix","MD5","RSA",5,2048);
//   	    RunTest("Cryptix","MD5","ElGamal",5,512);
//   	    RunTest("Cryptix","MD5","ElGamal",5,1024);
//  	    RunTest("ECC","MD5","ECDSA",5,160);
//  	    RunTest("ECC","MD5","ECDSA",5,192);
//  	    RunTest("ECC","MD5","ECDSA",5,224);
//  	    RunTest("ECC","MD5","ECNR",5,160);
//  	    RunTest("ECC","MD5","ECNR",5,192);
//  	    RunTest("ECC","MD5","ECNR",5,224); 	    
	}
	
    }

    public static KeyPair[] genKeyPairs(int runs, int keysize, 
					String algorithm,
					String provider) 
    throws NoSuchAlgorithmException, NoSuchProviderException {
	long start = System.currentTimeMillis(), elapsed;
	KeyPairGenerator kpgen = 
	    KeyPairGenerator.getInstance(algorithm,provider);
	kpgen.initialize(keysize);
	
	KeyPair[] keypairs = new KeyPair[runs];
	
	System.out.println("\tInitialization time (ms): " + 
			   (System.currentTimeMillis()-start));
	
	start = System.currentTimeMillis();
	for (int j = 0; j<runs; j++) {
	    keypairs[j] = kpgen.generateKeyPair();
	}
	elapsed = System.currentTimeMillis()-start;
	System.out.println("\tKey Gen total ("+ runs+" sigs) (ms): " 
			   + elapsed + " Average: " + 
			   (float)(elapsed/runs));	
	return keypairs;
    }
    
    public static byte[][] genSigs(KeyPair[] keypairs, 
				   Signature sig, 
				   byte[][] data) 
	throws SignatureException, InvalidKeyException
    {
	int runs = keypairs.length;

	byte[][] signatures = new byte[runs][] ;
	long start = System.currentTimeMillis(), elapsed;

	PrivateKey priv;

	for (int j = 0; j<runs; j++) {
	    priv = keypairs[j].getPrivate();
	    sig.initSign(priv);
	    sig.update(data[j]);	
	    signatures[j] = sig.sign();
	}
	
	elapsed = System.currentTimeMillis()-start;
	System.out.println("\tSignature total ("+ runs+" sigs) (ms): " 
			   + elapsed + " Average: " + 
			   (float)(elapsed/runs));

	return signatures;
    }

    public static void verify(KeyPair[] keypairs, 
			      byte[][] signatures,
			      Signature sig,
			      byte[][] data) 
	throws SignatureException, InvalidKeyException
    {
	long start = System.currentTimeMillis(), elapsed;
	int runs = keypairs.length;
	PublicKey pub;
	start = System.currentTimeMillis();
	for (int j = 0; j<runs; j++) {
	    pub = keypairs[j].getPublic();
	    sig.initVerify(pub);
	    sig.update(data[j]);
	    if (!sig.verify(signatures[j])) {
		System.out.println("\tSignature " + j + 
				   " Does not Verify");
	    }
	}
	elapsed = System.currentTimeMillis()-start;
	System.out.println("\tVerification total (" +runs+" sigs) (ms): " 
			   + elapsed + " Average: " + 
			   (float)(elapsed/runs));
    }

    public static byte[][] randData(int runs, int size, SecureRandom rand)
    {
	byte[][] output = new byte[runs][];
	for (int i=0; i<runs; i++) 
	    output[i] = (new BigInteger(size,rand).toByteArray());
	
	return output;
    }

    
    public static void RunTest(String provider, String digest, 
			       String algorithm, int runs, 
			       int keysize) {
	try {
	    byte[] randSeed = new byte[20];
	    (new Random()).nextBytes(randSeed);
	    SecureRandom random = new SecureRandom(randSeed);
	    
	    System.out.println("Testing " +digest  + "/" 
			       + algorithm + " ("
			       + provider+ ") with "
			       + keysize + " bit Keys...");
	    
	    KeyPair[] keypairs = genKeyPairs(runs, keysize, algorithm, provider);
	    
	    Signature sig =
		Signature.getInstance(digest+"/"+algorithm,provider);
	    
	    final byte[][] data = randData(runs,10000,random);

	    final byte[][] signatures = genSigs(keypairs,sig,data);
	
	    // NOTE: Cryptix's RSA will not verify unless this is called again
	    sig =
		Signature.getInstance(digest+"/"+algorithm,provider);

	    verify(keypairs,signatures,sig,data);

        } catch (Exception e) {
	    e.printStackTrace();
            System.out.println(e.toString());
	}
    }
}
