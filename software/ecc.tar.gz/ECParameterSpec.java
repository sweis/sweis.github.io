import java.security.*;
import java.security.spec.*;
import java.math.BigInteger;
/**
 * Elliptic Curve Cryptosystem Paramters<BR>
 * <BR>
 * Conforms to notation used in IEEE P1363 Section 7.1<BR>
 * <BR>
 * @author Steve Weis (sweis@cs.berkeley.edu)
 */

class ECParameterSpec implements AlgorithmParameterSpec {
    /*
     * NOTE: This class does not really have any value except to conform
     * to the java framework. It mirrors the functionality in ECurve.
     *
     * TODO: Place the ECurve interface methods in here and implement
     * the field independent operations in different classes.
     */

// Constants and variables
//............................................................................

   public static final String UC_COPYRIGHT = "Copyright &copy 2000 The Regents of the University of California. All Rights Reserved. ";

    /**
     * Size of the underlying finite field GF(q)<BR>
     * (Part of EC Domain Parameters)
     */
    private BigInteger q;

    /**
     * Coefficient of the elliptic curve equation<BR>
     * (Part of EC Domain Parameters)
     */
    private BigInteger a;

    /**
     * Coefficient of the elliptic curve equation<BR>
     * (Part of EC Domain Parameters)
     */
    private BigInteger b;

    /**
     * Prime order of the base point 
     */
    private BigInteger r;

    /**
     * A curve point generating a subgroup of order r<BR>
     * (Part of EC Domain Parameters)
     */
    private EPoint G;

    /**
     * Bit length of keys associated with these parameters
     * (Not part of IEEE notation)
     */
    private int keysize;

// Constructors 
//............................................................................
    
    /**
     * Creates a new ECParameterSpec with the specified parameter values
     *
     * @param q - size of the underlying finite field GF(q)
     * @param a - coefficient of EC equation
     * @param b - coefficient of EC equation
     * @param r - prime order of base point
     * @param G - subgroup generating curve point 
     * @param keysize - bit length of keys associated with this curve
     */
    public ECParameterSpec(BigInteger q,
			   BigInteger a,
			   BigInteger b,
			   BigInteger r,
			   EPoint G,
			   int keysize) {
	this.q = q;
	this.a = a;
	this.b = b;
	this.G = G;
	this.keysize = keysize;
    }

// Public Methods
//............................................................................

    /**
     * Size of the underlying finite field GF(q)<BR>
     * (Part of EC Domain Parameters)
     *
     * @return   size of underlying field
     */
    public BigInteger getQ() { return q; }
    
    /**
     * Coefficient of the elliptic curve equation<BR>
     * (Part of EC Domain Parameters)
     *
     * @return   coefficient of the elliptic curve equation
     */
    public BigInteger getA() { return a; }

    /**
     * Coefficient of the elliptic curve equation<BR>
     * (Part of EC Domain Parameters)
     *
     * @return   coefficient of the elliptic curve equation
     */
    public BigInteger getB() { return b; }

    /**
     * Prime order of the base point 
     *
     * @return   size of underlying field
     */
    public BigInteger getR() { return r; }

    /**
     * A curve point generating a subgroup of order r<BR>
     * (Part of EC Domain Parameters)
     *
     * @return   curve point generating subgroup of order r
     */
    public EPoint getG() { return G; }

    /** 
     * Generate a curve according to the given parameters
     *
     * @throws  
     * @return  curve based on these parameters
     */
    public ECurve getCurve() throws InvalidAlgorithmParameterException {
	ECurve curve = ECurve.getStandardCurve(keysize);
	if (!this.G.equals(curve.getG()))
	    throw new InvalidAlgorithmParameterException("Invalid EC Arguments");
	return curve;
    }
}
