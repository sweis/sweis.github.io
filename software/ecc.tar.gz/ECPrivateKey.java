import java.security.PrivateKey;
import java.math.BigInteger;

/**
 * Implementation of a Elliptic Curve Private key <BR>
 * <BR>
 * Key is a statistically unique and unpredictable integer d in<BR>
 * the range [1, n-1] where n is the prime order of the underlying curve<BR>
 * <BR>
 * @author Steve Weis (sweis@cs.berkeley.edu) 
 */
public class ECPrivateKey implements ECKey, PrivateKey {

// Constants and variables
//............................................................................

   public static final String UC_COPYRIGHT = "Copyright &copy 2000 The Regents of the University of California. All Rights Reserved. ";

    private BigInteger d;

    private ECurve curve;

    /**
     * The standard name of this algorithm    
     */
    private static final String ALGNAME = "ECDSA/ECNR";

// Constructors 
//............................................................................

    /**
     * Create a new instance of a EC Public Key based on the curve c
     *
     * @param c      the curve this key is based upon
     * @param p      the point on the curve representing this public key
     */
    public ECPrivateKey(BigInteger i, ECurve c) {
	this.d = i;
	curve = c;

	// TODO: Check that i is <= prime order of c?
    }

// Public Methods
//............................................................................

    /** 
     * Return the private key d, an intger in the range [1, n-1]
     * where n is the prime order of the underlying curve
     *
     * @return the large integer d 
     */
    public BigInteger getD() { return d; }

    /** 
     * Return the the curve this public key lies on
     *
     * @return the curve this public key lies on
     */
    public ECurve getCurve() { return curve; }

    /**
     * Convert the point Q to a byte array.
     *
     * @return  this point Q converted to a byte array using
     *          the algorithm defined in section 4.3.6 of ANSI X9.62
     */
    public byte[] getEncoded() { 
	return d.toByteArray();
    }

   public String toString() { return d.toString(); }

// Unimplemented
//............................................................................

    // Need to return a correct algorithm name
    public String getAlgorithm() { return ALGNAME; }

    // Need to return a correct format name
    public String getFormat() { return "ANSI X9.62"; }
   
}













