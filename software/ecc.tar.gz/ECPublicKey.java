import java.security.PublicKey;

/**
 * Implementation of a Elliptic Curve Public key<BR>
 * <BR>
 * Key is a point Q on the underlying elliptic curve of the<BR>
 * form Q = kP, where P is a system paramater of the curve and<BR>
 * k is a statistically unique and unpredictable integer in the <BR>
 * range [1, n-1], where n is the prime order of the curve<BR>
 *<BR>
 * @author Steve Weis (sweis@cs.berkeley.edu) 
 */
public class ECPublicKey implements ECKey, PublicKey {

// Constants and variables
//............................................................................

   public static final String UC_COPYRIGHT = "Copyright &copy 2000 The Regents of the University of California. All Rights Reserved. ";

    private EPoint q;

    private ECurve curve;

    /**
     * The standard name of this algorithm    
     */
    private static final String ALGNAME = "ECDSA/ECNR";


// Constructors 
//............................................................................
    /**
     * Create a new instance of a EC Public Key based on the curve c
     *
     * @param c      the curve this key is based upon
     * @param p      the point on the curve representing this public key
     */
    public ECPublicKey(EPoint p, ECurve c) {
	this.q = p;	
	curve = c;
    }

// Public Methods
//............................................................................

    /** 
     * Return the public key, the point in the curve Q=kP
     *
     * @return the point Q=kP on the curve p
     */
    public EPoint getQ() { return q; }

    /** 
     * Return the the curve this public key lies on
     *
     * @return the curve this public key lies on
     */
    public ECurve getCurve() { return curve; }

    /**
     * Convert the point Q to a byte array.<BR>
     * This is the ANSI X9.62 Point-to-Octet-String Conversion primitive<BR>
     * <BR>
     * @return  this point Q converted to a byte array using
     *          the algorithm defined in section 4.3.6 of ANSI X9.62
     */
    public byte[] getEncoded() { 
	/* Alternate format flags are:
	   (EPoint.COMPRESSED, EPoint.EXPANDED, EPoint.HYBRID)
	*/
	return q.toByteArray(EPoint.COMPRESSED);
    }

    public String toString() { return q.toString(); }

// Unimplemented
//............................................................................

    // Need to return a correct algorithm name
    public String getAlgorithm() { return ALGNAME; }

    // Need to return a correct format name
    public String getFormat() { return "ANSI X9.62"; }
   
}

