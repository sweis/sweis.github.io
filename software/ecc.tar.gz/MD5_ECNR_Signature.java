/**
 * A class to digest a message with MD5, and sign/verify the
 * resulting hash using the EC Nyberg-Rueppel digital signature scheme
 *
 * @author Steve Weis (sweis@cs.berkeley.edu)
 */

public class MD5_ECNR_Signature
    extends ECSignature {

   public static final String UC_COPYRIGHT = "Copyright &copy 2000 The Regents of the University of California. All Rights Reserved. ";

    public MD5_ECNR_Signature() { super("MD5/ECNR"); }
}

